/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BookOpen, FolderHeart, LayoutDashboard, Home, BarChart3, Sun, Moon, Sparkles, Type, MessageSquare, ShieldCheck } from 'lucide-react';
import { PDFBook, Bookmark, BookNote, Highlight, ReadingSession, ReadingStats, Collection, Folder } from './types';
import { 
  initDB, getBooks, saveBook, getBook, deleteBook, updateBookProgress, 
  getBookmarks, saveBookmark, deleteBookmark, 
  getNotes, saveNote, deleteNote, 
  getHighlights, saveHighlight, deleteHighlight, updateHighlightColor,
  logReadingSession, getReadingSessions,
  getCollections, saveCollection, deleteCollection,
  getFolders, saveFolder, deleteFolder,
  triggerAutoBackup
} from './lib/db';
import { generateThumbnail } from './lib/pdf-utils';
import { createStarterSampleBook } from './lib/sample-book';
import Dashboard from './components/Dashboard';
import Library from './components/Library';
import StatsPanel from './components/StatsPanel';
import Reader from './components/Reader';
import { FeedbackSection } from './components/FeedbackSection';
import PageTransitionManager, { springPhysics } from './components/PageTransitionManager';
import DataSafetyModal from './components/DataSafetyModal';

const generateId = () => {
  return crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 11);
};

export default function App() {
  const [currentTab, setCurrentTab] = useState<'dashboard' | 'library' | 'stats' | 'feedback'>('dashboard');
  const [activeBookId, setActiveBookId] = useState<string | null>(null);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const userChosen = localStorage.getItem('theme_user_chosen');
    if (userChosen === 'true') {
      const saved = localStorage.getItem('theme');
      return saved === 'dark' ? 'dark' : 'light';
    }
    return 'light';
  });

  const handleToggleTheme = () => {
    setTheme(prev => {
      const next = prev === 'light' ? 'dark' : 'light';
      localStorage.setItem('theme_user_chosen', 'true');
      return next;
    });
  };
  const [uiFont, setUiFont] = useState<'sans' | 'serif' | 'display' | 'mono'>(() => {
    return (localStorage.getItem('ui_font') as any) || 'sans';
  });
  const [showFontMenu, setShowFontMenu] = useState(false);
  const [showSafetyModal, setShowSafetyModal] = useState(false);

  // Core Data State
  const [books, setBooks] = useState<PDFBook[]>([]);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [notes, setNotes] = useState<BookNote[]>([]);
  const [highlights, setHighlights] = useState<Highlight[]>([]);
  const [sessions, setSessions] = useState<ReadingSession[]>([]);

  const getUiFontClass = (font: string) => {
    return 'font-sans';
  };

  const getUiFontVariables = (font: string) => {
    return {
      '--font-display': 'var(--font-sans)',
      '--font-serif': 'var(--font-sans)',
    };
  };

  const reloadAllData = async () => {
    try {
      const loadedBooks = await getBooks();
      const loadedSessions = await getReadingSessions();
      const loadedCollections = await getCollections();
      const loadedFolders = await getFolders();
      setBooks(loadedBooks);
      setSessions(loadedSessions);
      setCollections(loadedCollections);
      setFolders(loadedFolders);
      if (activeBookId) {
        const loadedBookmarks = await getBookmarks(activeBookId);
        const loadedNotes = await getNotes(activeBookId);
        const loadedHighlights = await getHighlights(activeBookId);
        setBookmarks(loadedBookmarks);
        setNotes(loadedNotes);
        setHighlights(loadedHighlights);
      }
    } catch (e) {
      console.error('Error reloading data after restore:', e);
    }
  };

  // Open DB and Load books & sessions on mount
  useEffect(() => {
    async function loadInitialData() {
      try {
        await initDB();
        let loadedBooks = await getBooks();
        if (loadedBooks.length === 0) {
          const starter = createStarterSampleBook();
          await saveBook(starter);
          loadedBooks = [starter];
        } else {
          // If starter book exists in DB but lost its fileBlob, reattach it
          for (const b of loadedBooks) {
            if (b.id === 'starter-guide-book' && !b.fileBlob) {
              const freshStarter = createStarterSampleBook();
              b.fileBlob = freshStarter.fileBlob;
              await saveBook(b);
            }
          }
        }
        const loadedSessions = await getReadingSessions();
        const loadedCollections = await getCollections();
        const loadedFolders = await getFolders();
        setBooks(loadedBooks);
        setSessions(loadedSessions);
        setCollections(loadedCollections);
        setFolders(loadedFolders);

        const userChosen = localStorage.getItem('theme_user_chosen');
        if (userChosen === 'true') {
          const savedTheme = localStorage.getItem('theme') || 'light';
          setTheme(savedTheme as 'light' | 'dark');
        } else {
          setTheme('light');
        }
      } catch (err) {
        console.error('Error initializing database or loading books', err);
      }
    }
    loadInitialData();
  }, []);

  // Sync sub-records whenever activeBookId changes (when reader is opened)
  useEffect(() => {
    if (activeBookId) {
      async function loadBookData() {
        try {
          const loadedBookmarks = await getBookmarks(activeBookId);
          const loadedNotes = await getNotes(activeBookId);
          const loadedHighlights = await getHighlights(activeBookId);
          
          setBookmarks(loadedBookmarks);
          setNotes(loadedNotes);
          setHighlights(loadedHighlights);
        } catch (err) {
          console.error('Error loading book sub-records', err);
        }
      }
      loadBookData();
    }
  }, [activeBookId]);

  // Sync Tailwind HTML class with theme state
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  // 1. Book Upload handler with automatic author/title detection and non-destructive duplicate detection
  const handleUploadPDF = async (file: File): Promise<{ isDuplicate: boolean; duplicateOf?: string; title: string }> => {
    const pdfjsLib = (window as any).pdfjsLib;

    const lowerName = file.name.toLowerCase();
    const fileFormat: 'pdf' | 'epub' | 'other' = lowerName.endsWith('.pdf') 
      ? 'pdf' 
      : (lowerName.endsWith('.epub') ? 'epub' : 'other');

    let detectedTitle = file.name.replace(/\.[^/.]+$/, '');
    let detectedAuthor: string | undefined = undefined;

    // Detect author patterns: "Author - Title" or "Title by Author"
    if (detectedTitle.includes(' - ')) {
      const parts = detectedTitle.split(' - ');
      if (parts.length === 2 && parts[0].trim() && parts[1].trim()) {
        detectedAuthor = parts[0].trim();
        detectedTitle = parts[1].trim();
      }
    } else if (/\s+by\s+/i.test(detectedTitle)) {
      const parts = detectedTitle.split(/\s+by\s+/i);
      if (parts.length === 2 && parts[0].trim() && parts[1].trim()) {
        detectedTitle = parts[0].trim();
        detectedAuthor = parts[1].trim();
      }
    }

    let numPages = 1;
    let thumbnail: string | undefined = undefined;

    if (fileFormat === 'pdf' && pdfjsLib) {
      try {
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
        const arrayBuffer = await file.arrayBuffer();
        const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
        const pdf = await loadingTask.promise;
        numPages = pdf.numPages;

        // Try extracting metadata if present
        try {
          const metadata = await pdf.getMetadata();
          if (metadata && metadata.info) {
            if (metadata.info.Title && typeof metadata.info.Title === 'string' && metadata.info.Title.trim().length > 2) {
              detectedTitle = metadata.info.Title.trim();
            }
            if (metadata.info.Author && typeof metadata.info.Author === 'string' && metadata.info.Author.trim().length > 1) {
              detectedAuthor = metadata.info.Author.trim();
            }
          }
        } catch {
          // ignore metadata errors
        }

        thumbnail = await generateThumbnail(file);
      } catch (err) {
        console.warn('PDF parsing notice:', err);
      }
    }

    // Non-destructive duplicate detection: check if a book with same file or same title exists
    const existingBooks = await getBooks();
    const duplicateMatch = existingBooks.find(eb => 
      (eb.fileSize === file.size && eb.fileName === file.name) ||
      (eb.title.trim().toLowerCase() === detectedTitle.trim().toLowerCase() && 
       ((!detectedAuthor && !eb.author) || (detectedAuthor && eb.author && detectedAuthor.toLowerCase() === eb.author.toLowerCase())))
    );

    const bookId = generateId();
    const newBook: PDFBook = {
      id: bookId,
      title: detectedTitle,
      author: detectedAuthor,
      fileName: file.name,
      fileSize: file.size,
      fileFormat,
      addedAt: new Date().toISOString(),
      lastOpened: null,
      totalPages: numPages,
      currentPage: 1,
      scrollOffset: 0,
      progressPercent: 0,
      readingStatus: 'unread',
      isNewImport: true,
      fileBlob: file,
      thumbnail
    };

    // Save newly imported book (duplicates are preserved safely without deletion!)
    await saveBook(newBook);
    
    // Reload books
    const updatedBooks = await getBooks();
    setBooks(updatedBooks);

    return {
      isDuplicate: !!duplicateMatch,
      duplicateOf: duplicateMatch?.title,
      title: detectedTitle
    };
  };

  // 2. Open PDF Book
  const handleOpenBook = async (id: string, initialPage?: number) => {
    let bookToOpen = await getBook(id);
    if (!bookToOpen && id === 'starter-guide-book') {
      bookToOpen = createStarterSampleBook();
      await saveBook(bookToOpen);
    } else if (bookToOpen && bookToOpen.id === 'starter-guide-book' && !bookToOpen.fileBlob) {
      const freshStarter = createStarterSampleBook();
      bookToOpen.fileBlob = freshStarter.fileBlob;
      await saveBook(bookToOpen);
    }

    if (bookToOpen) {
      if (initialPage && initialPage > 0) {
        bookToOpen.currentPage = initialPage;
      }
      // Update its last opened date
      bookToOpen.lastOpened = new Date().toISOString();
      await saveBook(bookToOpen);

      // Refresh books state and set active
      const updatedBooks = await getBooks();
      setBooks(updatedBooks);
      setActiveBookId(id);
    }
  };

  // 3. Delete Book
  const handleDeleteBook = async (id: string) => {
    await deleteBook(id);
    const updatedBooks = await getBooks();
    setBooks(updatedBooks);
    
    // If deleted book was active, clear it
    if (activeBookId === id) {
      setActiveBookId(null);
    }
  };

  // 4. Update progress from reader
  const handleUpdateProgress = React.useCallback(async (page: number, scrollOffset: number, progressPercent: number, totalPages?: number) => {
    if (!activeBookId) return;

    await updateBookProgress(activeBookId, page, scrollOffset, progressPercent, totalPages);
    
    // Refresh books state (non-blocking)
    const updatedBooks = await getBooks();
    setBooks(updatedBooks);
  }, [activeBookId]);

  // 5. Bookmarks Management
  const handleAddBookmark = React.useCallback(async (bookmark: Omit<Bookmark, 'id' | 'createdAt'>) => {
    const newBookmark: Bookmark = {
      ...bookmark,
      id: generateId(),
      createdAt: new Date().toISOString()
    };
    await saveBookmark(newBookmark);
    setBookmarks(prev => [...prev, newBookmark].sort((a, b) => a.pageNumber - b.pageNumber));
  }, []);

  const handleDeleteBookmark = React.useCallback(async (id: string) => {
    await deleteBookmark(id);
    setBookmarks(prev => prev.filter(b => b.id !== id));
  }, []);

  // 6. Notes Management
  const handleSaveNote = React.useCallback(async (pageNumber: number, content: string, quote?: string) => {
    if (!activeBookId) return;

    const existingNote = notes.find(n => n.pageNumber === pageNumber);
    const updatedNote: BookNote = existingNote 
      ? {
          ...existingNote,
          content,
          quote: quote !== undefined ? quote : existingNote.quote,
          updatedAt: new Date().toISOString()
        }
      : {
          id: generateId(),
          bookId: activeBookId,
          pageNumber,
          content,
          quote,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };

    await saveNote(updatedNote);
    
    // Refresh notes list
    const loadedNotes = await getNotes(activeBookId);
    setNotes(loadedNotes);
  }, [activeBookId, notes]);

  const handleDeleteNote = React.useCallback(async (id: string) => {
    if (!activeBookId) return;
    await deleteNote(id);
    setNotes(prev => prev.filter(n => n.id !== id));
  }, [activeBookId]);

  // 7. Highlights Management
  const handleAddHighlight = React.useCallback(async (highlight: Omit<Highlight, 'id' | 'createdAt'>) => {
    const newHighlight: Highlight = {
      ...highlight,
      id: generateId(),
      createdAt: new Date().toISOString()
    };
    await saveHighlight(newHighlight);
    setHighlights(prev => [...prev, newHighlight].sort((a, b) => a.pageNumber - b.pageNumber));
  }, []);

  const handleDeleteHighlight = React.useCallback(async (id: string) => {
    await deleteHighlight(id);
    setHighlights(prev => prev.filter(h => h.id !== id));
  }, []);

  const handleUpdateHighlightColor = React.useCallback(async (id: string, color: string) => {
    if (!activeBookId) return;
    await updateHighlightColor(id, color);
    setHighlights(prev => prev.map(h => h.id === id ? { ...h, color } : h));
  }, [activeBookId]);

  // 8. Log Reading Time / Session
  const handleLogReadingTime = React.useCallback(async (durationMs: number, pagesRead: number) => {
    if (!activeBookId) return;
    try {
      await logReadingSession(activeBookId, pagesRead, durationMs);
      const loadedSessions = await getReadingSessions();
      setSessions(loadedSessions);
    } catch (err) {
      console.error('Error logging reading session', err);
    }
  }, [activeBookId]);

  // 9. Book Update (Rename, Favorite, Collections)
  const handleUpdateBook = async (id: string, updates: Partial<PDFBook>) => {
    const book = await getBook(id);
    if (book) {
      const updatedBook = { ...book, ...updates };
      await saveBook(updatedBook);
      const updatedBooks = await getBooks();
      setBooks(updatedBooks);
    }
  };

  // 10. Collection Management
  const handleSaveCollection = async (name: string, id?: string) => {
    const collectionId = id || generateId();
    const existing = id ? collections.find(c => c.id === id) : null;
    const newCollection: Collection = {
      id: collectionId,
      name,
      createdAt: existing?.createdAt || Date.now(),
      updatedAt: Date.now()
    };
    await saveCollection(newCollection);
    const updatedCollections = await getCollections();
    setCollections(updatedCollections);
    return collectionId;
  };

  const handleDeleteCollection = async (id: string) => {
    // Also remove this collection ID from all books
    const booksInCollection = books.filter(b => b.collectionIds?.includes(id));
    
    for (const book of booksInCollection) {
      const newIds = book.collectionIds!.filter(cid => cid !== id);
      await saveBook({ ...book, collectionIds: newIds });
    }
    
    await deleteCollection(id);
    
    // Update local state
    setBooks(prev => prev.map(b => b.collectionIds?.includes(id) 
      ? { ...b, collectionIds: b.collectionIds.filter(cid => cid !== id) } 
      : b
    ));
    
    const updatedCollections = await getCollections();
    setCollections(updatedCollections);
  };

  // 10b. Folder Management (Phase 2)
  const handleSaveFolder = async (name: string, id?: string, color?: string) => {
    const folderId = id || generateId();
    const existing = id ? folders.find(f => f.id === id) : null;
    const newFolder: Folder = {
      id: folderId,
      name: name.trim(),
      color: color || existing?.color || '#ea580c',
      createdAt: existing?.createdAt || Date.now(),
      updatedAt: Date.now()
    };
    await saveFolder(newFolder);
    const updatedFolders = await getFolders();
    setFolders(updatedFolders);
    return folderId;
  };

  const handleDeleteFolder = async (id: string) => {
    // Dissociate books from this folder without deleting books
    const booksInFolder = books.filter(b => b.folderId === id);
    for (const book of booksInFolder) {
      await saveBook({ ...book, folderId: null });
    }
    await deleteFolder(id);

    setBooks(prev => prev.map(b => b.folderId === id ? { ...b, folderId: null } : b));
    const updatedFolders = await getFolders();
    setFolders(updatedFolders);
  };

  // 10. Compute Reading Stats
  const calculateStreak = (sessionsList: ReadingSession[]) => {
    if (sessionsList.length === 0) return 0;
    
    const uniqueDates = Array.from(new Set(sessionsList.map(s => s.date))).sort().reverse();
    if (uniqueDates.length === 0) return 0;

    const todayStr = new Date().toISOString().split('T')[0];
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];

    // If neither today nor yesterday is present, streak is broken (0)
    if (uniqueDates[0] !== todayStr && uniqueDates[0] !== yesterdayStr) {
      return 0;
    }

    let streak = 0;
    let checkDate = new Date(uniqueDates[0]);

    for (let i = 0; i < uniqueDates.length + 10; i++) { // cap recursion loop
      const dStr = checkDate.toISOString().split('T')[0];
      if (uniqueDates.includes(dStr)) {
        streak++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        break;
      }
    }
    return streak;
  };

  const computeStats = (): ReadingStats => {
    const totalBooks = books.length;
    const completedBooks = books.filter(b => b.progressPercent >= 100).length;
    const totalPagesRead = books.reduce((sum, b) => sum + Math.round((b.progressPercent / 100) * b.totalPages), 0);
    const totalReadingTimeMs = sessions.reduce((sum, s) => sum + s.durationMs, 0);
    const streakDays = calculateStreak(sessions);

    return {
      totalBooks,
      completedBooks,
      totalPagesRead,
      totalReadingTimeMs,
      streakDays
    };
  };

  // Find active book structure
  const activeBook = books.find(b => b.id === activeBookId);

  return (
    <div 
      className={`min-h-screen flex flex-col bg-[#F7F6F2] dark:bg-[#0D0D11] text-slate-800 dark:text-[#E0E0E0] relative overflow-x-hidden ${getUiFontClass(uiFont)}`}
      style={getUiFontVariables(uiFont) as React.CSSProperties}
    >
      
      {/* App Header (Only show if reader is NOT open) */}
      <AnimatePresence>
        {!activeBookId && (
          <motion.header 
            initial={{ y: -16, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -16, opacity: 0 }}
            transition={springPhysics}
            className="sticky top-0 z-40 w-full liquid-glass border-b border-black/5 dark:border-white/10"
          >
            <div className="mx-auto flex h-14 sm:h-16 max-w-6xl items-center justify-between px-3 sm:px-6">
              
              {/* Branding */}
              <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                <div className="flex h-8 w-8 sm:h-10 sm:w-10 items-center justify-center rounded-xl sm:rounded-2xl bg-orange-600 text-white shadow-md shadow-orange-600/25 shrink-0">
                  <BookOpen className="h-4 w-4 sm:h-5 sm:w-5" />
                </div>
                <div className="min-w-0">
                  <span className="font-sans text-sm sm:text-lg font-bold tracking-tight text-slate-900 dark:text-white block leading-none truncate">
                    Smart Book Reader
                  </span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
                <button
                  id="header-backup-button"
                  onClick={() => setShowSafetyModal(true)}
                  className="flex items-center gap-1 sm:gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 px-2.5 sm:px-3 py-1.5 text-[9px] font-bold uppercase tracking-wider transition-all cursor-pointer shadow-xs active:scale-95 hover:bg-emerald-500/20"
                  title="Data Safety, Backup & Restore"
                >
                  <ShieldCheck className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span className="hidden sm:inline">Backup</span>
                </button>

                <button
                  id="header-feedback-button"
                  onClick={() => setCurrentTab('feedback')}
                  className={`flex items-center gap-1 sm:gap-1.5 rounded-full border px-2.5 sm:px-3 py-1.5 text-[9px] font-bold uppercase tracking-wider transition-all cursor-pointer shadow-xs active:scale-95 ${
                    currentTab === 'feedback'
                      ? 'border-orange-500 bg-orange-600 text-white shadow-orange-500/20'
                      : 'border-slate-300 dark:border-white/10 bg-white/80 dark:bg-white/5 text-slate-700 dark:text-[#E0E0E0] hover:bg-slate-50 dark:hover:bg-white/10'
                  }`}
                  title="Feedback"
                >
                  <MessageSquare className="h-3.5 w-3.5" />
                  <span>Feedback</span>
                </button>

                <button
                  id="header-theme-toggle"
                  onClick={handleToggleTheme}
                  className="flex items-center gap-1 sm:gap-1.5 rounded-full border border-slate-300 dark:border-white/10 bg-white/80 dark:bg-white/5 p-1 sm:p-1.5 pr-2.5 sm:pr-3 text-[9px] font-bold uppercase tracking-wider text-slate-700 dark:text-[#E0E0E0] hover:bg-slate-50 dark:hover:bg-white/10 transition-all cursor-pointer shadow-xs active:scale-95"
                  title="Toggle Theme"
                >
                  <div className={`flex h-5 w-5 items-center justify-center rounded-full transition-all ${theme === 'light' ? 'bg-orange-100 text-orange-600' : 'bg-slate-800 text-orange-400'}`}>
                    {theme === 'light' ? <Sun className="h-3 w-3" /> : <Moon className="h-3 w-3" />}
                  </div>
                  <span className="hidden sm:inline">{theme === 'light' ? 'Light' : 'Dark'}</span>
                </button>
              </div>
            </div>
          </motion.header>
        )}
      </AnimatePresence>

      {/* Global Page Transition Manager */}
      <PageTransitionManager viewKey={activeBookId ? 'reader' : currentTab} className="flex-1 flex flex-col">
        {!activeBookId ? (
          <main className="flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 py-6 pb-36 overflow-x-hidden">
            {currentTab === 'dashboard' && (
              <Dashboard 
                books={books}
                collections={collections}
                stats={computeStats()}
                recentSessions={sessions}
                onOpenBook={handleOpenBook}
                onViewLibrary={() => setCurrentTab('library')}
                onOpenDataSafety={() => setShowSafetyModal(true)}
              />
            )}

            {currentTab === 'library' && (
              <Library 
                books={books}
                collections={collections}
                folders={folders}
                onUpload={handleUploadPDF}
                onOpenBook={handleOpenBook}
                onDeleteBook={handleDeleteBook}
                onUpdateBook={handleUpdateBook}
                onSaveCollection={handleSaveCollection}
                onDeleteCollection={handleDeleteCollection}
                onSaveFolder={handleSaveFolder}
                onDeleteFolder={handleDeleteFolder}
                onOpenDataSafety={() => setShowSafetyModal(true)}
              />
            )}

            {currentTab === 'stats' && (
              <StatsPanel 
                books={books}
                stats={computeStats()}
                sessions={sessions}
              />
            )}

            {currentTab === 'feedback' && (
              <FeedbackSection />
            )}
          </main>
        ) : (
          /* PDF Reader full-screen view */
          activeBook && (
            <Reader 
              book={activeBook}
              bookmarks={bookmarks}
              notes={notes}
              highlights={highlights}
              theme={theme}
              onBack={() => setActiveBookId(null)}
              onToggleTheme={handleToggleTheme}
              onUpdateProgress={handleUpdateProgress}
              onAddBookmark={handleAddBookmark}
              onDeleteBookmark={handleDeleteBookmark}
              onSaveNote={handleSaveNote}
              onDeleteNote={handleDeleteNote}
              onAddHighlight={handleAddHighlight}
              onDeleteHighlight={handleDeleteHighlight}
              onUpdateHighlightColor={handleUpdateHighlightColor}
              onLogReadingTime={handleLogReadingTime}
            />
          )
        )}
      </PageTransitionManager>

      {/* Floating Island Solid High-Contrast Bottom Dock */}
      <AnimatePresence>
        {!activeBookId && (
          <motion.div 
            initial={{ y: 24, opacity: 0, scale: 0.96 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 24, opacity: 0, scale: 0.96 }}
            transition={springPhysics}
            className="fixed bottom-2 sm:bottom-6 inset-x-0 z-50 flex justify-center pointer-events-none px-3"
          >
            <nav 
              className="pointer-events-auto rounded-2xl sm:rounded-full p-1 sm:p-1.5 shadow-2xl border-2 border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 shadow-slate-900/25 dark:shadow-black/90 w-full max-w-[390px] sm:max-w-none sm:w-auto"
              style={{ backgroundColor: theme === 'dark' ? '#18181b' : '#ffffff' }}
              aria-label="Main Navigation"
            >
              <div className="grid grid-cols-4 sm:flex items-center gap-1 sm:gap-2 w-full">
                {[
                  { id: 'dashboard', label: 'Home', icon: Home },
                  { id: 'library', label: 'Library', icon: BookOpen },
                  { id: 'stats', label: 'Insights', icon: BarChart3 },
                  { id: 'feedback', label: 'Feedback', icon: MessageSquare },
                ].map((tab) => {
                  const isActive = currentTab === tab.id;
                  const Icon = tab.icon;
                  const activeColor = '#ffffff';
                  const inactiveColor = theme === 'dark' ? '#f4f4f5' : '#0f172a';

                  return (
                    <button
                      key={tab.id}
                      id={`tab-${tab.id}`}
                      onClick={() => setCurrentTab(tab.id as any)}
                      style={{
                        backgroundColor: isActive ? '#ea580c' : 'transparent',
                      }}
                      className={`relative flex flex-col sm:flex-row items-center justify-center gap-0.5 sm:gap-2 py-1.5 sm:py-2 px-2 sm:px-4 rounded-xl sm:rounded-full transition-all cursor-pointer select-none font-bold text-xs ${
                        isActive
                          ? 'bg-orange-600 !text-white shadow-md shadow-orange-600/40 ring-1 ring-orange-500/50 active:scale-95'
                          : 'hover:text-orange-600 hover:bg-slate-100 dark:hover:bg-zinc-800/80 active:scale-95'
                      }`}
                    >
                      <Icon 
                        style={{
                          color: isActive ? activeColor : inactiveColor,
                          stroke: isActive ? activeColor : inactiveColor,
                        }}
                        className={`h-5 w-5 sm:h-4.5 sm:w-4.5 shrink-0 transition-transform ${
                          isActive 
                            ? 'scale-110 !text-white stroke-[2.5]' 
                            : 'stroke-[2.2]'
                        }`} 
                      />
                      <span 
                        style={{
                          color: isActive ? activeColor : inactiveColor,
                        }}
                        className={`text-[9.5px] sm:text-xs font-bold uppercase tracking-tight sm:tracking-wider leading-tight text-center ${
                          isActive ? '!text-white' : ''
                        }`}
                      >
                        {tab.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Data Safety & Backup Modal (Phase 1) */}
      <DataSafetyModal 
        isOpen={showSafetyModal} 
        onClose={() => setShowSafetyModal(false)} 
        onDataRestored={reloadAllData} 
      />
    </div>
  );
}

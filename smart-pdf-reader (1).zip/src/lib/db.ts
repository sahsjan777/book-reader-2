/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  PDFBook, Bookmark, BookNote, Highlight, ReadingSession, Collection, Folder,
  SavedHinglish, BackupData, AutoBackupSnapshot, DataSafetyStats 
} from '../types';

const DB_NAME = 'SmartPDFReaderDB';
const DB_VERSION = 4;

export function initDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => {
      console.error('Failed to open database');
      reject(request.error);
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onupgradeneeded = (event) => {
      const db = request.result;

      // 1. Books store
      if (!db.objectStoreNames.contains('books')) {
        db.createObjectStore('books', { keyPath: 'id' });
      }

      // 2. Bookmarks store
      if (!db.objectStoreNames.contains('bookmarks')) {
        const bookmarkStore = db.createObjectStore('bookmarks', { keyPath: 'id' });
        bookmarkStore.createIndex('bookId', 'bookId', { unique: false });
      }

      // 3. Notes store
      if (!db.objectStoreNames.contains('notes')) {
        const noteStore = db.createObjectStore('notes', { keyPath: 'id' });
        noteStore.createIndex('bookId', 'bookId', { unique: false });
      }

      // 4. Highlights store
      if (!db.objectStoreNames.contains('highlights')) {
        const highlightStore = db.createObjectStore('highlights', { keyPath: 'id' });
        highlightStore.createIndex('bookId', 'bookId', { unique: false });
      }

      // 5. Reading sessions store for analytics
      if (!db.objectStoreNames.contains('sessions')) {
        const sessionStore = db.createObjectStore('sessions', { keyPath: 'id', autoIncrement: true });
        sessionStore.createIndex('bookId', 'bookId', { unique: false });
        sessionStore.createIndex('date', 'date', { unique: false });
      }

      // 6. Collections store
      if (!db.objectStoreNames.contains('collections')) {
        db.createObjectStore('collections', { keyPath: 'id' });
      }

      // 7. Hinglish Explanations / Summaries store (Phase 1 Protection)
      if (!db.objectStoreNames.contains('hinglish')) {
        const hinglishStore = db.createObjectStore('hinglish', { keyPath: 'id' });
        hinglishStore.createIndex('bookId', 'bookId', { unique: false });
        hinglishStore.createIndex('pageNumber', 'pageNumber', { unique: false });
      }

      // 8. Automatic & Manual Backups store (Phase 1 Protection)
      if (!db.objectStoreNames.contains('backups')) {
        const backupStore = db.createObjectStore('backups', { keyPath: 'id' });
        backupStore.createIndex('createdAt', 'createdAt', { unique: false });
      }

      // 9. Folders store (Phase 2 Advanced Library)
      if (!db.objectStoreNames.contains('folders')) {
        db.createObjectStore('folders', { keyPath: 'id' });
      }
    };
  });
}

// Helper to run transactions
function getStore(storeName: string, mode: IDBTransactionMode = 'readonly'): Promise<{ store: IDBObjectStore, transaction: IDBTransaction }> {
  return initDB().then((db) => {
    const transaction = db.transaction(storeName, mode);
    const store = transaction.objectStore(storeName);
    return { store, transaction };
  });
}

// Generic helper to get all items from an object store
async function getAllFromStore<T>(storeName: string): Promise<T[]> {
  try {
    const { store } = await getStore(storeName, 'readonly');
    return new Promise((resolve) => {
      const request = store.getAll();
      request.onsuccess = () => resolve((request.result as T[]) || []);
      request.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
}

// ----------------- BOOK OPERATIONS -----------------

export async function saveBook(book: PDFBook): Promise<void> {
  const { store } = await getStore('books', 'readwrite');
  return new Promise((resolve, reject) => {
    const request = store.put(book);
    request.onsuccess = () => {
      triggerAutoBackup();
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}

export async function getBooks(): Promise<PDFBook[]> {
  const { store } = await getStore('books', 'readonly');
  return new Promise((resolve, reject) => {
    const request = store.getAll();
    request.onsuccess = () => {
      const books = request.result as PDFBook[];
      books.sort((a, b) => {
        const timeA = a.lastOpened ? new Date(a.lastOpened).getTime() : 0;
        const timeB = b.lastOpened ? new Date(b.lastOpened).getTime() : 0;
        if (timeA !== timeB) return timeB - timeA;
        return new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime();
      });
      resolve(books);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function getBook(id: string): Promise<PDFBook | null> {
  const { store } = await getStore('books', 'readonly');
  return new Promise((resolve, reject) => {
    const request = store.get(id);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}

export async function deleteBook(id: string): Promise<void> {
  // Safe delete with safety snapshot before deletion
  await createLocalAutoBackup(`Pre-Delete Book Snapshot (${id})`);

  const db = await initDB();
  return new Promise<void>((resolve, reject) => {
    const transaction = db.transaction(['books', 'bookmarks', 'notes', 'highlights', 'sessions', 'hinglish'], 'readwrite');
    
    transaction.oncomplete = () => {
      triggerAutoBackup();
      resolve();
    };
    transaction.onerror = () => reject(transaction.error);
    
    // Delete book itself
    transaction.objectStore('books').delete(id);
    
    // Delete bookmarks
    const bookmarkStore = transaction.objectStore('bookmarks');
    const bookmarkIndex = bookmarkStore.index('bookId');
    const bReq = bookmarkIndex.openCursor(IDBKeyRange.only(id));
    bReq.onsuccess = (e) => {
      const cursor = (e.target as IDBRequest<IDBCursorWithValue | null>).result;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      }
    };

    // Delete notes
    const noteStore = transaction.objectStore('notes');
    const noteIndex = noteStore.index('bookId');
    const nReq = noteIndex.openCursor(IDBKeyRange.only(id));
    nReq.onsuccess = (e) => {
      const cursor = (e.target as IDBRequest<IDBCursorWithValue | null>).result;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      }
    };

    // Delete highlights
    const highlightStore = transaction.objectStore('highlights');
    const highlightIndex = highlightStore.index('bookId');
    const hReq = highlightIndex.openCursor(IDBKeyRange.only(id));
    hReq.onsuccess = (e) => {
      const cursor = (e.target as IDBRequest<IDBCursorWithValue | null>).result;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      }
    };

    // Delete sessions
    const sessionStore = transaction.objectStore('sessions');
    const sessionIndex = sessionStore.index('bookId');
    const sReq = sessionIndex.openCursor(IDBKeyRange.only(id));
    sReq.onsuccess = (e) => {
      const cursor = (e.target as IDBRequest<IDBCursorWithValue | null>).result;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      }
    };

    // Delete hinglish
    if (transaction.objectStoreNames.contains('hinglish')) {
      const hinglishStore = transaction.objectStore('hinglish');
      const hinglishIndex = hinglishStore.index('bookId');
      const gReq = hinglishIndex.openCursor(IDBKeyRange.only(id));
      gReq.onsuccess = (e) => {
        const cursor = (e.target as IDBRequest<IDBCursorWithValue | null>).result;
        if (cursor) {
          cursor.delete();
          cursor.continue();
        }
      };
    }
  });
}

// Crash-safe reading progress updater with localStorage fallback
export async function updateBookProgress(
  id: string,
  currentPage: number,
  scrollOffset: number,
  progressPercent: number,
  totalPages?: number
): Promise<void> {
  const book = await getBook(id);
  if (!book) return;

  book.currentPage = Math.max(1, currentPage);
  book.scrollOffset = scrollOffset;
  book.progressPercent = Math.max(book.progressPercent || 0, Math.min(100, progressPercent));
  if (totalPages && totalPages > 0) {
    book.totalPages = totalPages;
  }
  book.lastOpened = new Date().toISOString();

  await saveBook(book);

  // Crash-safe emergency mirror in localStorage
  try {
    const miniState = {
      bookId: id,
      currentPage: book.currentPage,
      progressPercent: book.progressPercent,
      lastOpened: book.lastOpened
    };
    localStorage.setItem(`smart_pdf_last_pos_${id}`, JSON.stringify(miniState));
    localStorage.setItem('smart_pdf_last_active_book', id);
  } catch {
    // ignore quota
  }

  triggerAutoBackup();
}

// ----------------- BOOKMARKS (With Duplicate Protection) -----------------

export async function getBookmarks(bookId: string): Promise<Bookmark[]> {
  const { store } = await getStore('bookmarks', 'readonly');
  const index = store.index('bookId');
  return new Promise((resolve, reject) => {
    const request = index.getAll(IDBKeyRange.only(bookId));
    request.onsuccess = () => {
      const bookmarks = request.result as Bookmark[];
      bookmarks.sort((a, b) => a.pageNumber - b.pageNumber);
      resolve(bookmarks);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function saveBookmark(bookmark: Bookmark): Promise<void> {
  const { store } = await getStore('bookmarks', 'readwrite');
  return new Promise((resolve, reject) => {
    try {
      const index = store.index('bookId');
      const req = index.getAll(IDBKeyRange.only(bookmark.bookId));
      req.onsuccess = () => {
        const existingList = req.result as Bookmark[];
        // Duplicate protection: if bookmark on this page already exists, update its label
        const existing = existingList.find(b => b.pageNumber === bookmark.pageNumber);
        if (existing) {
          existing.label = bookmark.label || existing.label;
          const putReq = store.put(existing);
          putReq.onsuccess = () => {
            triggerAutoBackup();
            resolve();
          };
          putReq.onerror = () => reject(putReq.error);
        } else {
          const putReq = store.put(bookmark);
          putReq.onsuccess = () => {
            triggerAutoBackup();
            resolve();
          };
          putReq.onerror = () => reject(putReq.error);
        }
      };
      req.onerror = () => {
        const putReq = store.put(bookmark);
        putReq.onsuccess = () => {
          triggerAutoBackup();
          resolve();
        };
        putReq.onerror = () => reject(putReq.error);
      };
    } catch (err) {
      reject(err);
    }
  });
}

export async function deleteBookmark(id: string): Promise<void> {
  const { store } = await getStore('bookmarks', 'readwrite');
  return new Promise((resolve, reject) => {
    const request = store.delete(id);
    request.onsuccess = () => {
      triggerAutoBackup();
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}

// ----------------- NOTES (With Duplicate Protection) -----------------

export async function getNotes(bookId: string): Promise<BookNote[]> {
  const { store } = await getStore('notes', 'readonly');
  const index = store.index('bookId');
  return new Promise((resolve, reject) => {
    const request = index.getAll(IDBKeyRange.only(bookId));
    request.onsuccess = () => {
      const notes = request.result as BookNote[];
      notes.sort((a, b) => a.pageNumber - b.pageNumber);
      resolve(notes);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function saveNote(note: BookNote): Promise<void> {
  const { store } = await getStore('notes', 'readwrite');
  return new Promise((resolve, reject) => {
    try {
      const index = store.index('bookId');
      const req = index.getAll(IDBKeyRange.only(note.bookId));
      req.onsuccess = () => {
        const existingList = req.result as BookNote[];
        // Duplicate protection: if note on this page already exists, update its content & timestamp
        const existing = existingList.find(n => n.pageNumber === note.pageNumber);
        if (existing) {
          existing.content = note.content;
          existing.updatedAt = new Date().toISOString();
          const putReq = store.put(existing);
          putReq.onsuccess = () => {
            triggerAutoBackup();
            resolve();
          };
          putReq.onerror = () => reject(putReq.error);
        } else {
          const putReq = store.put(note);
          putReq.onsuccess = () => {
            triggerAutoBackup();
            resolve();
          };
          putReq.onerror = () => reject(putReq.error);
        }
      };
      req.onerror = () => {
        const putReq = store.put(note);
        putReq.onsuccess = () => {
          triggerAutoBackup();
          resolve();
        };
        putReq.onerror = () => reject(putReq.error);
      };
    } catch (err) {
      reject(err);
    }
  });
}

export async function deleteNote(id: string): Promise<void> {
  const { store } = await getStore('notes', 'readwrite');
  return new Promise((resolve, reject) => {
    const request = store.delete(id);
    request.onsuccess = () => {
      triggerAutoBackup();
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}

// ----------------- HIGHLIGHTS (With Duplicate Protection) -----------------

export async function getHighlights(bookId: string): Promise<Highlight[]> {
  const { store } = await getStore('highlights', 'readonly');
  const index = store.index('bookId');
  return new Promise((resolve, reject) => {
    const request = index.getAll(IDBKeyRange.only(bookId));
    request.onsuccess = () => {
      const highlights = request.result as Highlight[];
      highlights.sort((a, b) => a.pageNumber - b.pageNumber);
      resolve(highlights);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function saveHighlight(highlight: Highlight): Promise<void> {
  const { store } = await getStore('highlights', 'readwrite');
  return new Promise((resolve, reject) => {
    try {
      const index = store.index('bookId');
      const req = index.getAll(IDBKeyRange.only(highlight.bookId));
      req.onsuccess = () => {
        const list = req.result as Highlight[];
        // Duplicate protection: if exact same text & page already highlighted, update color
        const duplicate = list.find(h => 
          h.pageNumber === highlight.pageNumber && 
          h.text.trim() === highlight.text.trim() &&
          (h.startIndex === highlight.startIndex || Math.abs((h.rects[0]?.left || 0) - (highlight.rects[0]?.left || 0)) < 1)
        );
        if (duplicate) {
          duplicate.color = highlight.color;
          const putReq = store.put(duplicate);
          putReq.onsuccess = () => {
            triggerAutoBackup();
            resolve();
          };
          putReq.onerror = () => reject(putReq.error);
        } else {
          const putReq = store.put(highlight);
          putReq.onsuccess = () => {
            triggerAutoBackup();
            resolve();
          };
          putReq.onerror = () => reject(putReq.error);
        }
      };
      req.onerror = () => {
        const putReq = store.put(highlight);
        putReq.onsuccess = () => {
          triggerAutoBackup();
          resolve();
        };
        putReq.onerror = () => reject(putReq.error);
      };
    } catch (err) {
      reject(err);
    }
  });
}

export async function deleteHighlight(id: string): Promise<void> {
  const { store } = await getStore('highlights', 'readwrite');
  return new Promise((resolve, reject) => {
    const request = store.delete(id);
    request.onsuccess = () => {
      triggerAutoBackup();
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}

export async function updateHighlightColor(id: string, color: string): Promise<void> {
  const { store } = await getStore('highlights', 'readwrite');
  return new Promise((resolve, reject) => {
    const getReq = store.get(id);
    getReq.onsuccess = () => {
      const highlight = getReq.result as Highlight;
      if (highlight) {
        highlight.color = color;
        const putReq = store.put(highlight);
        putReq.onsuccess = () => {
          triggerAutoBackup();
          resolve();
        };
        putReq.onerror = () => reject(putReq.error);
      } else {
        resolve();
      }
    };
    getReq.onerror = () => reject(getReq.error);
  });
}

export async function getAllNotes(): Promise<BookNote[]> {
  return getAllFromStore<BookNote>('notes');
}

export async function getAllHighlights(): Promise<Highlight[]> {
  return getAllFromStore<Highlight>('highlights');
}

// ----------------- READING SESSIONS -----------------

export async function logReadingSession(bookId: string, pagesRead: number, durationMs: number): Promise<void> {
  const { store } = await getStore('sessions', 'readwrite');
  const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
  const session: ReadingSession = {
    bookId,
    date: today,
    pagesRead,
    durationMs
  };
  return new Promise((resolve, reject) => {
    const request = store.add(session);
    request.onsuccess = () => {
      triggerAutoBackup();
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}

export async function getReadingSessions(): Promise<ReadingSession[]> {
  const { store } = await getStore('sessions', 'readonly');
  return new Promise((resolve, reject) => {
    const request = store.getAll();
    request.onsuccess = () => resolve(request.result as ReadingSession[]);
    request.onerror = () => reject(request.error);
  });
}

// ----------------- COLLECTIONS -----------------

export async function getCollections(): Promise<Collection[]> {
  const { store } = await getStore('collections', 'readonly');
  return new Promise((resolve, reject) => {
    const request = store.getAll();
    request.onsuccess = () => {
      const collections = request.result as Collection[];
      collections.sort((a, b) => b.createdAt - a.createdAt);
      resolve(collections);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function saveCollection(collection: Collection): Promise<void> {
  const { store } = await getStore('collections', 'readwrite');
  return new Promise((resolve, reject) => {
    const request = store.put(collection);
    request.onsuccess = () => {
      triggerAutoBackup();
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}

export async function deleteCollection(id: string): Promise<void> {
  const { store } = await getStore('collections', 'readwrite');
  return new Promise((resolve, reject) => {
    const request = store.delete(id);
    request.onsuccess = () => {
      triggerAutoBackup();
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}

// ----------------- FOLDERS (Phase 2) -----------------

export async function getFolders(): Promise<Folder[]> {
  try {
    const { store } = await getStore('folders', 'readonly');
    return new Promise((resolve) => {
      const request = store.getAll();
      request.onsuccess = () => {
        const folders = (request.result as Folder[]) || [];
        folders.sort((a, b) => b.createdAt - a.createdAt);
        resolve(folders);
      };
      request.onerror = () => {
        const saved = localStorage.getItem('smart_reader_folders');
        resolve(saved ? JSON.parse(saved) : []);
      };
    });
  } catch {
    const saved = localStorage.getItem('smart_reader_folders');
    return saved ? JSON.parse(saved) : [];
  }
}

export async function saveFolder(folder: Folder): Promise<void> {
  try {
    const saved = localStorage.getItem('smart_reader_folders');
    const folders: Folder[] = saved ? JSON.parse(saved) : [];
    const idx = folders.findIndex(f => f.id === folder.id);
    if (idx >= 0) folders[idx] = folder;
    else folders.push(folder);
    localStorage.setItem('smart_reader_folders', JSON.stringify(folders));
  } catch (e) {
    console.warn('Folder localStorage fallback error', e);
  }

  try {
    const { store } = await getStore('folders', 'readwrite');
    return new Promise((resolve, reject) => {
      const request = store.put(folder);
      request.onsuccess = () => {
        triggerAutoBackup();
        resolve();
      };
      request.onerror = () => reject(request.error);
    });
  } catch {
    triggerAutoBackup();
  }
}

export async function deleteFolder(id: string): Promise<void> {
  try {
    const saved = localStorage.getItem('smart_reader_folders');
    if (saved) {
      const folders: Folder[] = JSON.parse(saved);
      const filtered = folders.filter(f => f.id !== id);
      localStorage.setItem('smart_reader_folders', JSON.stringify(filtered));
    }
  } catch (e) {
    console.warn('Folder delete localStorage notice', e);
  }

  try {
    const { store } = await getStore('folders', 'readwrite');
    return new Promise((resolve, reject) => {
      const request = store.delete(id);
      request.onsuccess = () => {
        triggerAutoBackup();
        resolve();
      };
      request.onerror = () => reject(request.error);
    });
  } catch {
    triggerAutoBackup();
  }
}

// ----------------- HINGLISH EXPLANATIONS STORAGE -----------------

export async function saveHinglish(item: SavedHinglish): Promise<void> {
  const { store } = await getStore('hinglish', 'readwrite');
  return new Promise((resolve, reject) => {
    const request = store.put(item);
    request.onsuccess = () => {
      triggerAutoBackup();
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}

export async function getHinglishForBook(bookId: string): Promise<SavedHinglish[]> {
  try {
    const { store } = await getStore('hinglish', 'readonly');
    const index = store.index('bookId');
    return new Promise((resolve) => {
      const request = index.getAll(IDBKeyRange.only(bookId));
      request.onsuccess = () => {
        const list = request.result as SavedHinglish[];
        list.sort((a, b) => a.pageNumber - b.pageNumber);
        resolve(list);
      };
      request.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
}

// ----------------- PHASE 1: AUTOMATIC LOCAL BACKUP & EXPORT/IMPORT -----------------

export async function getAllBackupData(): Promise<BackupData> {
  const books = await getBooks();
  const collections = await getCollections();
  const folders = await getFolders();
  const sessions = await getReadingSessions();
  const bookmarks = await getAllFromStore<Bookmark>('bookmarks');
  const notes = await getAllFromStore<BookNote>('notes');
  const highlights = await getAllFromStore<Highlight>('highlights');
  let savedHinglish: SavedHinglish[] = [];
  try {
    savedHinglish = await getAllFromStore<SavedHinglish>('hinglish');
  } catch {
    // optional store
  }

  // Strip huge binary blobs so export/backup is fast, clean, and portable
  const serializedBooks = books.map(b => {
    const { fileBlob, ...rest } = b;
    return rest;
  });

  const settings: Record<string, any> = {};
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith('smart_') || key.startsWith('reader_') || key.includes('theme') || key === 'ui_font')) {
        settings[key] = localStorage.getItem(key);
      }
    }
  } catch {
    // ignore
  }

  return {
    version: 1,
    exportedAt: new Date().toISOString(),
    appName: 'Smart Book Reader',
    books: serializedBooks,
    bookmarks,
    notes,
    highlights,
    sessions,
    collections,
    folders,
    savedHinglish,
    settings
  };
}

let autoBackupTimer: any = null;
export function triggerAutoBackup(): void {
  if (autoBackupTimer) clearTimeout(autoBackupTimer);
  autoBackupTimer = setTimeout(() => {
    createLocalAutoBackup().catch(e => console.warn('Auto backup skipped:', e));
  }, 1500);
}

export async function createLocalAutoBackup(label?: string): Promise<AutoBackupSnapshot> {
  const data = await getAllBackupData();
  const id = `backup-${Date.now()}`;
  const snapshot: AutoBackupSnapshot = {
    id,
    createdAt: new Date().toISOString(),
    label: label || 'Automatic Local Backup',
    itemCount: {
      books: data.books.length,
      bookmarks: data.bookmarks.length,
      notes: data.notes.length,
      highlights: data.highlights.length,
      sessions: data.sessions.length
    },
    data
  };

  try {
    const { store } = await getStore('backups', 'readwrite');
    store.put(snapshot);

    // Keep the latest 10 snapshots to save disk space
    const all = store.getAll();
    all.onsuccess = () => {
      const list = all.result as AutoBackupSnapshot[];
      if (list && list.length > 10) {
        list.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
        const toDelete = list.slice(0, list.length - 10);
        for (const item of toDelete) {
          store.delete(item.id);
        }
      }
    };
  } catch (e) {
    console.warn('Could not write snapshot to IndexedDB, fallback to localStorage', e);
  }

  // Always mirror emergency snapshot in localStorage
  try {
    const emergencyPayload = JSON.stringify({
      savedAt: snapshot.createdAt,
      itemCount: snapshot.itemCount,
      bookmarks: data.bookmarks,
      notes: data.notes,
      highlights: data.highlights,
      booksProgress: data.books.map(b => ({ id: b.id, page: b.currentPage, progress: b.progressPercent }))
    });
    localStorage.setItem('smart_pdf_emergency_backup', emergencyPayload);
    localStorage.setItem('smart_pdf_last_backup_time', snapshot.createdAt);
  } catch {
    // ignore quota
  }

  return snapshot;
}

export async function getLocalSnapshots(): Promise<AutoBackupSnapshot[]> {
  try {
    const { store } = await getStore('backups', 'readonly');
    return new Promise((resolve) => {
      const req = store.getAll();
      req.onsuccess = () => {
        const list = req.result as AutoBackupSnapshot[];
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        resolve(list);
      };
      req.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
}

export async function exportBackupJSON(): Promise<void> {
  const data = await getAllBackupData();
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const dateStr = new Date().toISOString().split('T')[0];
  a.href = url;
  a.download = `smart-pdf-reader-backup-${dateStr}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function importBackupJSON(jsonString: string): Promise<{
  success: boolean;
  imported: {
    books: number;
    bookmarks: number;
    notes: number;
    highlights: number;
    collections: number;
  };
  error?: string;
}> {
  try {
    const data: BackupData = JSON.parse(jsonString);
    if (!data || (!data.bookmarks && !data.notes && !data.highlights && !data.books)) {
      throw new Error('Invalid backup file format.');
    }

    // 1. Create a pre-restore safety snapshot of current data before merging!
    await createLocalAutoBackup('Pre-Restore Safety Snapshot');

    let importedBooksCount = 0;
    let importedBookmarksCount = 0;
    let importedNotesCount = 0;
    let importedHighlightsCount = 0;
    let importedCollectionsCount = 0;

    // 2. Safe merge Books: update reading progress for existing books
    const existingBooks = await getBooks();
    if (data.books && Array.isArray(data.books)) {
      for (const b of data.books) {
        const found = existingBooks.find(eb => eb.id === b.id || eb.fileName === b.fileName);
        if (found) {
          found.currentPage = Math.max(found.currentPage, b.currentPage || 1);
          found.progressPercent = Math.max(found.progressPercent, b.progressPercent || 0);
          found.lastOpened = b.lastOpened || found.lastOpened;
          found.isFavorite = b.isFavorite !== undefined ? b.isFavorite : found.isFavorite;
          if (b.collectionIds) {
            found.collectionIds = Array.from(new Set([...(found.collectionIds || []), ...b.collectionIds]));
          }
          await saveBook(found);
          importedBooksCount++;
        }
      }
    }

    // 3. Safe merge Bookmarks with duplicate protection
    if (data.bookmarks && Array.isArray(data.bookmarks)) {
      for (const bm of data.bookmarks) {
        await saveBookmark(bm);
        importedBookmarksCount++;
      }
    }

    // 4. Safe merge Notes
    if (data.notes && Array.isArray(data.notes)) {
      for (const n of data.notes) {
        await saveNote(n);
        importedNotesCount++;
      }
    }

    // 5. Safe merge Highlights
    if (data.highlights && Array.isArray(data.highlights)) {
      for (const h of data.highlights) {
        await saveHighlight(h);
        importedHighlightsCount++;
      }
    }

    // 6. Safe merge Collections
    if (data.collections && Array.isArray(data.collections)) {
      for (const c of data.collections) {
        await saveCollection(c);
        importedCollectionsCount++;
      }
    }

    // 6b. Safe merge Folders
    if (data.folders && Array.isArray(data.folders)) {
      for (const f of data.folders) {
        await saveFolder(f);
      }
    }

    // 7. Safe merge Hinglish
    if (data.savedHinglish && Array.isArray(data.savedHinglish)) {
      for (const sh of data.savedHinglish) {
        await saveHinglish(sh);
      }
    }

    // 8. Restore reader settings if present
    if (data.settings && typeof data.settings === 'object') {
      for (const [k, v] of Object.entries(data.settings)) {
        if (typeof v === 'string') {
          localStorage.setItem(k, v);
        }
      }
    }

    // Post-restore auto snapshot
    await createLocalAutoBackup('Post-Restore Snapshot');

    return {
      success: true,
      imported: {
        books: importedBooksCount,
        bookmarks: importedBookmarksCount,
        notes: importedNotesCount,
        highlights: importedHighlightsCount,
        collections: importedCollectionsCount
      }
    };
  } catch (err: any) {
    console.error('Failed to import backup:', err);
    return {
      success: false,
      imported: { books: 0, bookmarks: 0, notes: 0, highlights: 0, collections: 0 },
      error: err.message || 'Failed to read backup file.'
    };
  }
}

export async function restoreLocalSnapshot(snapshotId: string): Promise<boolean> {
  const snapshots = await getLocalSnapshots();
  const snapshot = snapshots.find(s => s.id === snapshotId);
  if (!snapshot) return false;

  const res = await importBackupJSON(JSON.stringify(snapshot.data));
  return res.success;
}

export async function getDataSafetyStats(): Promise<DataSafetyStats> {
  const books = await getBooks();
  const bookmarks = await getAllFromStore<Bookmark>('bookmarks');
  const notes = await getAllFromStore<BookNote>('notes');
  const highlights = await getAllFromStore<Highlight>('highlights');
  const snapshots = await getLocalSnapshots();
  const lastTime = localStorage.getItem('smart_pdf_last_backup_time');

  return {
    lastBackupAt: lastTime || (snapshots[0]?.createdAt ?? null),
    autoBackupActive: true,
    totalSnapshots: snapshots.length,
    protectedCounts: {
      books: books.length,
      bookmarks: bookmarks.length,
      notes: notes.length,
      highlights: highlights.length
    }
  };
}

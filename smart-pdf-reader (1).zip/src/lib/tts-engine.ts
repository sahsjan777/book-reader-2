/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Smart TTS Engine for English and Hinglish (Mixed English + Roman Hindi).
 * 
 * Features:
 * 1. Automatic language classification (English vs Hinglish vs Hindi).
 * 2. Intelligent Hinglish segmentation (grouping consecutive English vs Roman Hindi words).
 * 3. High-fidelity Roman-to-Devanagari transliteration for browser Hindi TTS voices.
 * 4. Punctuation handling without literal symbol speech.
 * 5. Device voice discovery and classification (en-US, en-GB, hi-IN, en-IN).
 * 6. Graceful fallbacks and phonetic approximations when native Hindi voices are unavailable.
 */

export type TTSLanguage = 'english' | 'hinglish' | 'hindi' | 'urdu';

export interface TTSVoiceOption {
  voiceURI: string;
  name: string;
  lang: string;
  category: 'en-US' | 'en-GB' | 'hi-IN' | 'ur-PK' | 'en-IN' | 'other';
  isDefault?: boolean;
}

export interface TTSSegment {
  text: string;
  language: 'english' | 'hindi' | 'urdu';
  devanagariText?: string;
}

// -------------------------------------------------------------
// 1. ROMAN HINDI VOCABULARY & DICTIONARY
// -------------------------------------------------------------

// Common Roman Hindi words mapped directly to their correct Devanagari representation.
// This guarantees 100% authentic pronunciation when fed into native hi-IN speech synthesis.
export const ROMAN_HINDI_TO_DEVANAGARI_MAP: Record<string, string> = {
  // Pronouns & Demonstratives
  'ye': 'ये',
  'yeh': 'यह',
  'wo': 'वो',
  'woh': 'वह',
  'mai': 'मैं',
  'main': 'मैं',
  'mera': 'मेरा',
  'meri': 'मेरी',
  'mere': 'मेरे',
  'mujhe': 'मुझे',
  'mujhko': 'मुझको',
  'hum': 'हम',
  'ham': 'हम',
  'humara': 'हमारा',
  'hamara': 'हमारा',
  'humare': 'हमारे',
  'hamare': 'हमारे',
  'humari': 'हमारी',
  'hamari': 'हमारी',
  'humein': 'हमें',
  'hamein': 'हमें',
  'humko': 'हमको',
  'aap': 'आप',
  'aapka': 'आपका',
  'aapke': 'आपके',
  'aapki': 'आपकी',
  'aapko': 'आपको',
  'tum': 'तुम',
  'tumhara': 'तुम्हारा',
  'tumhare': 'तुम्हारे',
  'tumhari': 'तुम्हारी',
  'tumhe': 'तुम्हें',
  'tumko': 'तुमको',
  'apna': 'अपना',
  'apne': 'अपने',
  'apni': 'अपनी',
  'isko': 'इसको',
  'iska': 'इसका',
  'iske': 'इसके',
  'iski': 'इसकी',
  'isme': 'इसमें',
  'ismein': 'इसमें',
  'usko': 'उसको',
  'uska': 'उसका',
  'uske': 'उसके',
  'uski': 'उसकी',
  'usme': 'उसमें',
  'usmein': 'उसमें',
  'inhe': 'इन्हें',
  'unhe': 'उन्हें',
  'inka': 'इनका',
  'unka': 'उनका',

  // Auxiliaries & Copulas
  'hai': 'है',
  'hain': 'हैं',
  'ho': 'हो',
  'hoon': 'हूँ',
  'hun': 'हूँ',
  'tha': 'था',
  'thi': 'थी',
  'the': 'थे',
  'hoga': 'होगा',
  'hogi': 'होगी',
  'honge': 'होंगे',
  'hona': 'होना',
  'hota': 'होता',
  'hoti': 'होती',
  'hote': 'होते',
  'huye': 'हुए',
  'hua': 'हुआ',
  'hui': 'हुई',

  // Postpositions & Prepositions
  'ka': 'का',
  'ki': 'की',
  'ke': 'के',
  'ko': 'को',
  'se': 'से',
  'mein': 'में',
  'me': 'में',
  'par': 'पर',
  'pe': 'पे',
  'tak': 'तक',
  'liye': 'लिए',
  'ke liye': 'के लिए',
  'saath': 'साथ',
  'sath': 'साथ',
  'bina': 'बिना',
  'paas': 'पास',
  'door': 'दूर',
  'andar': 'अंदर',
  'bahar': 'बाहर',
  'upar': 'ऊपर',
  'neeche': 'नीचे',
  'aage': 'आगे',
  'peeche': 'पीछे',

  // Conjunctions & Particles
  'aur': 'और',
  'ya': 'या',
  'lekin': 'लेकिन',
  'magar': 'मगर',
  'parantu': 'परंतु',
  'balki': 'बल्कि',
  'kyunki': 'क्योंकि',
  'kyonki': 'क्योंकि',
  'isliye': 'इसलिए',
  'bhi': 'भी',
  'to': 'तो',
  'toh': 'तो',
  'hi': 'ही',
  'na': 'ना',
  'nahi': 'नहीं',
  'nahin': 'नहीं',
  'mat': 'मत',

  // Question words
  'kya': 'क्या',
  'kyun': 'क्यों',
  'kyon': 'क्यों',
  'kaise': 'कैसे',
  'kahan': 'कहाँ',
  'kidhar': 'किधर',
  'kab': 'कब',
  'kis': 'किस',
  'kisi': 'किसी',
  'kisko': 'किसको',
  'kaun': 'कौन',
  'kitna': 'कितना',
  'kitne': 'कितने',
  'kitni': 'कितनी',

  // Common Verbs & Adjectives
  'padhna': 'पढ़ना',
  'padho': 'पढ़ो',
  'padh': 'पढ़',
  'padhte': 'पढ़ते',
  'padhti': 'पढ़ती',
  'padhta': 'पढ़ता',
  'padhkar': 'पढ़कर',
  'karna': 'करना',
  'karo': 'करो',
  'karein': 'करें',
  'kar': 'कर',
  'karke': 'करके',
  'karta': 'करता',
  'karti': 'करती',
  'karte': 'करते',
  'karne': 'करने',
  'raha': 'रहा',
  'rahi': 'रही',
  'rahe': 'रहे',
  'rahein': 'रहें',
  'sakta': 'सकता',
  'sakti': 'सकती',
  'sakte': 'सकते',
  'chahta': 'चाहता',
  'chahti': 'चाहती',
  'chahte': 'चाहते',
  'chahiye': 'चाहिए',
  'samajh': 'समझ',
  'samajhna': 'समझना',
  'samajhte': 'समझते',
  'samjho': 'समझो',
  'sochna': 'सोचना',
  'soch': 'सोच',
  'socho': 'सोचो',
  'dekhna': 'देखना',
  'dekho': 'देखो',
  'dekh': 'देख',
  'sunna': 'सुनना',
  'suno': 'सुनो',
  'bolna': 'बोलना',
  'bolo': 'बोलो',
  'likhna': 'लिखना',
  'likho': 'लिखो',
  'chalna': 'चलना',
  'chalo': 'चलो',
  'rukna': 'रुकना',
  'ruko': 'रुको',
  'bataya': 'बताया',
  'batana': 'बताना',
  'batao': 'बताओ',
  'aana': 'आना',
  'aao': 'आओ',
  'jaana': 'जाना',
  'jaao': 'जाओ',
  'gaya': 'गया',
  'gayi': 'गई',
  'gaye': 'गए',

  // Descriptives & Nouns
  'bahut': 'बहुत',
  'bohot': 'बहुत',
  'achha': 'अच्छा',
  'acha': 'अच्छा',
  'achhi': 'अच्छी',
  'achi': 'अच्छी',
  'achhe': 'अच्छे',
  'ache': 'अच्छे',
  'bura': 'बुरा',
  'buri': 'बुरी',
  'bure': 'बुरे',
  'aasan': 'आसान',
  'mushkil': 'मुश्किल',
  'zaroori': 'ज़रूरी',
  'zaruri': 'ज़रूरी',
  'zarurat': 'ज़रूरत',
  'faida': 'फ़ायदा',
  'fayda': 'फ़ायदा',
  'nuksan': 'नुक़सान',
  'kamyabi': 'कामयाबी',
  'zindagi': 'ज़िंदगी',
  'dost': 'दोस्त',
  'doston': 'दोस्तों',
  'baat': 'बात',
  'baatein': 'बातें',
  'kaam': 'काम',
  'waqt': 'वक़्त',
  'samay': 'समय',
  'log': 'लोग',
  'logon': 'लोगों',
  'sirf': 'सिर्फ़',
  'sab': 'सब',
  'sabhi': 'सभी',
  'hamesha': 'हमेशा',
  'kabhi': 'कभी',
  'roz': 'रोज़',
  'rozana': 'रोज़ाना',
  'pehle': 'पहले',
  'baad': 'बाद',
  'safha': 'सफ़हा',
  'shuru': 'शुरू',
  'khatam': 'ख़त्म',
  'matlab': 'मतलब',
  'arth': 'अर्थ',
  'seekh': 'सीख',
  'khulasa': 'ख़ुलासा',
  'tarjuma': 'तरजुमा'
};

// Fast lookup set of Roman Hindi words (lowercase)
const ROMAN_HINDI_SET = new Set(Object.keys(ROMAN_HINDI_TO_DEVANAGARI_MAP));

// Common English words frequently present in Hinglish sentences that MUST retain English voice
const COMMON_ENGLISH_WORDS = new Set([
  'a', 'an', 'the', 'book', 'books', 'beginner', 'beginners', 'reading', 'read', 'reader', 'readers',
  'useful', 'pdf', 'progress', 'save', 'regular', 'regularly', 'improve', 'improves', 'improved',
  'concentration', 'memory', 'help', 'helps', 'helped', 'start', 'starter', 'guide', 'guidelines',
  'page', 'pages', 'chapter', 'chapters', 'font', 'fonts', 'text', 'audio', 'sound', 'player',
  'library', 'note', 'notes', 'highlight', 'highlights', 'settings', 'bookmark', 'bookmarks',
  'screen', 'clear', 'natural', 'voice', 'voices', 'sentence', 'sentences', 'word', 'words',
  'line', 'lines', 'paragraph', 'paragraphs', 'explain', 'explanation', 'summary', 'translation',
  'study', 'student', 'students', 'daily', 'habit', 'habits', 'time', 'life', 'mind', 'power',
  'rules', 'focus', 'practice', 'skill', 'skills', 'learn', 'learning', 'smart', 'easy', 'fast',
  'slow', 'stop', 'play', 'pause', 'resume', 'reset', 'level', 'mode', 'system', 'app', 'feature',
  'options', 'view', 'dark', 'light', 'sepia', 'fit', 'width', 'zoom', 'online', 'offline',
  'device', 'mobile', 'desktop', 'table', 'content', 'index', 'next', 'previous', 'search',
  'find', 'button', 'speed', 'rate', 'language', 'quality', 'test', 'example', 'done', 'cancel',
  'title', 'author', 'volume', 'status', 'document', 'file', 'percent', 'percentage', 'session',
  'routine', 'goal', 'goals', 'target', 'energy', 'strategy', 'psychology', 'mindset', 'confidence'
]);

// -------------------------------------------------------------
// 2. LANGUAGE DETECTION
// -------------------------------------------------------------

/**
 * Detects whether the given text is English, Hinglish, or Devanagari Hindi.
 */
export function detectLanguage(text: string, hint?: TTSLanguage): TTSLanguage {
  if (hint) return hint;
  if (!text || text.trim().length === 0) return 'english';

  const clean = text.trim();

  // 1. If text contains Urdu/Arabic characters, it is strictly Urdu script
  if (/[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/.test(clean)) {
    return 'urdu';
  }

  // 2. If text contains Devanagari characters, it is strictly Hindi script
  if (/[\u0900-\u097F]/.test(clean)) {
    return 'hindi';
  }

  // 2. Tokenize words for Roman Hindi vs English analysis
  const words = clean
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 0);

  if (words.length === 0) return 'english';

  let romanHindiScore = 0;

  for (const word of words) {
    if (ROMAN_HINDI_SET.has(word)) {
      romanHindiScore++;
    } else if (
      // Verb conjugation heuristics in Roman Hindi
      word.endsWith('raha') || word.endsWith('rahi') || word.endsWith('rahe') ||
      word.endsWith('karna') || word.endsWith('karo') || word.endsWith('padhna') ||
      word.endsWith('sakta') || word.endsWith('sakti') || word.endsWith('sakte')
    ) {
      romanHindiScore++;
    }
  }

  const ratio = romanHindiScore / words.length;

  // If there are distinct Roman Hindi marker words present, classify as Hinglish
  if (romanHindiScore >= 2 || (words.length <= 4 && romanHindiScore >= 1) || ratio >= 0.12) {
    return 'hinglish';
  }

  return 'english';
}

// -------------------------------------------------------------
// 3. SMART HINGLISH SEGMENTATION (Requirements 2, 3, 4, 5, 6)
// -------------------------------------------------------------

/**
 * Splits a Hinglish sentence into grouped language segments:
 * Consecutive Hindi words are grouped into a Hindi segment.
 * Consecutive English words are grouped into an English segment.
 * Avoids robotic word-by-word fragmentation.
 */
export function segmentHinglishSentence(sentence: string): TTSSegment[] {
  if (!sentence || sentence.trim().length === 0) return [];

  // Match words and preserved punctuation
  const tokens = sentence.split(/(\s+|[,;:.!?])/).filter(t => t.length > 0);
  
  interface TokenMeta {
    text: string;
    lang: 'english' | 'hindi';
    isPunctuationOrSpace: boolean;
  }

  const analyzedTokens: TokenMeta[] = [];

  for (const token of tokens) {
    const trimmed = token.trim();
    if (!trimmed || /^[,;:.!?]+$/.test(trimmed)) {
      analyzedTokens.push({ text: token, lang: 'english', isPunctuationOrSpace: true });
      continue;
    }

    const cleanWord = trimmed.toLowerCase().replace(/[^\w]/g, '');

    // Classification:
    // If it's explicitly a known Roman Hindi word -> hindi
    // If it's explicitly a known common English word -> english
    // Heuristics:
    let isHindi = ROMAN_HINDI_SET.has(cleanWord);
    if (!isHindi && !COMMON_ENGLISH_WORDS.has(cleanWord)) {
      // Check for Roman Hindi verb and structural patterns
      if (
        cleanWord.endsWith('raha') || cleanWord.endsWith('rahi') || cleanWord.endsWith('rahe') ||
        cleanWord.endsWith('karne') || cleanWord.endsWith('karte') || cleanWord.endsWith('karti') ||
        cleanWord.endsWith('sakte') || cleanWord.endsWith('sakti') || cleanWord.endsWith('sachta') ||
        cleanWord.endsWith('wale') || cleanWord.endsWith('wali') || cleanWord.endsWith('wala')
      ) {
        isHindi = true;
      }
    }

    analyzedTokens.push({
      text: token,
      lang: isHindi ? 'hindi' : 'english',
      isPunctuationOrSpace: false
    });
  }

  // Merge adjacent tokens into coherent segments
  const segments: TTSSegment[] = [];
  let currentLang: 'english' | 'hindi' | null = null;
  let currentBuffer = '';

  for (const token of analyzedTokens) {
    if (token.isPunctuationOrSpace) {
      currentBuffer += token.text;
      continue;
    }

    if (currentLang === null) {
      currentLang = token.lang;
      currentBuffer += token.text;
    } else if (currentLang === token.lang) {
      currentBuffer += token.text;
    } else {
      // Language switch: push current segment
      if (currentBuffer.trim().length > 0) {
        segments.push(createSegment(currentBuffer, currentLang));
      }
      currentLang = token.lang;
      currentBuffer = token.text;
    }
  }

  if (currentBuffer.trim().length > 0 && currentLang !== null) {
    segments.push(createSegment(currentBuffer, currentLang));
  }

  return segments.length > 0 ? segments : [{ text: sentence, language: 'english' }];
}

function createSegment(text: string, language: 'english' | 'hindi'): TTSSegment {
  if (language === 'hindi') {
    const devanagari = transliterateRomanHindiToDevanagari(text);
    return {
      text,
      language: 'hindi',
      devanagariText: devanagari
    };
  }
  return {
    text,
    language: 'english'
  };
}

/**
 * Transliterates Roman Hindi phrases into Devanagari script so that native browser hi-IN voices
 * speak them with authentic Hindi inflection and clear pronunciation.
 */
export function transliterateRomanHindiToDevanagari(phrase: string): string {
  // Preserve punctuation and spaces while replacing words
  return phrase.replace(/\b[a-zA-Z]+\b/g, (match) => {
    const lower = match.toLowerCase();
    if (ROMAN_HINDI_TO_DEVANAGARI_MAP[lower]) {
      return ROMAN_HINDI_TO_DEVANAGARI_MAP[lower];
    }
    // If not found in dictionary, return word as is
    return match;
  });
}

// Common Urdu words mapped to Devanagari for natural pronunciation when using Hindi voice engine
export const URDU_TO_DEVANAGARI_WORD_MAP: Record<string, string> = {
  'یہ': 'यह',
  'وہ': 'वह',
  'ہے': 'है',
  'ہیں': 'हैं',
  'تھا': 'था',
  'تھی': 'थी',
  'تھے': 'थे',
  'کا': 'का',
  'کی': 'की',
  'کے': 'के',
  'کو': 'को',
  'میں': 'में',
  'سے': 'से',
  'پر': 'पर',
  'اور': 'और',
  'یا': 'या',
  'نہیں': 'नहीं',
  'نہ': 'ना',
  'بھی': 'भी',
  'تو': 'तो',
  'کہ': 'कि',
  'جو': 'जो',
  'آپ': 'आप',
  'تم': 'तुम',
  'ہم': 'हम',
  'میرا': 'मेरा',
  'मेरी': 'मेरी',
  'میرے': 'मेरे',
  'ہمارا': 'हमारा',
  'ہماری': 'हमारी',
  'ہمارے': 'हमारे',
  'انکا': 'उनका',
  'انکی': 'उनकी',
  'انکے': 'उनके',
  'اسکا': 'उसका',
  'اسکی': 'उसकी',
  'اسکے': 'उसके',
  'اس': 'इस',
  'ان': 'इन',
  'بہت': 'बहुत',
  'اچھا': 'अच्छा',
  'اچھی': 'अच्छी',
  'اچھے': 'अच्छे',
  'کتاب': 'किताब',
  'صفحہ': 'सफ़हा',
  'سبق': 'सबक',
  'بات': 'बात',
  'کام': 'काम',
  'وقت': 'वक़्त',
  'دن': 'दिन',
  'رات': 'रात',
  'لوگ': 'लोग',
  'زندگی': 'ज़िंदगी',
  'علم': 'इल्म',
  'پڑھنا': 'पढ़ना',
  'پڑھو': 'पढ़ो',
  'پڑھ': 'पढ़',
  'سمجھنا': 'समझना',
  'سمجھ': 'समझ',
  'کرنا': 'करना',
  'کرو': 'करो',
  'کریں': 'करें',
  'ہونا': 'होना',
  'ہو': 'हो',
  'گیا': 'गया',
  'گئی': 'गई',
  'گئے': 'गए',
  'سکتا': 'सकता',
  'سکتی': 'सकती',
  'سکتے': 'सकते',
  'چاہیے': 'चाहिए',
  'مرکزی': 'मरकज़ी',
  'خیال': 'ख़याल',
  'اہم': 'अहम',
  'نکات': 'नुकात',
  'نکتہ': 'नुक्ता',
  'نتیجہ': 'नतीजा',
  'خلاصہ': 'ख़ुलासा',
  'تشریح': 'तशरीह',
  'وضاحت': 'वज़ाहत',
  'سب': 'सब',
  'کچھ': 'कुछ',
  'کوئی': 'कोई',
  'جب': 'जब',
  'تب': 'तब',
  'اب': 'अब',
  'کب': 'कब',
  'کیوں': 'क्यों',
  'کیسے': 'कैसे',
  'کہاں': 'कहाँ',
  'کون': 'कौन',
  'کتنا': 'कितना',
  'کتنے': 'कितने',
  'کتنی': 'कितनी'
};

const URDU_COMPOUND_PHONETICS: [string, string][] = [
  ['بھ', 'भ'],
  ['پھ', 'फ'],
  ['تھ', 'थ'],
  ['ٹھ', 'ठ'],
  ['جھ', 'झ'],
  ['چھ', 'छ'],
  ['دھ', 'ध'],
  ['ڈھ', 'ढ'],
  ['کھ', 'ख'],
  ['گھ', 'घ'],
  ['لھ', 'ल्ह'],
  ['مھ', 'म्ह'],
  ['نھ', 'न्ह'],
  ['وھ', 'व्ह'],
  ['یھ', 'यह']
];

const URDU_LETTER_PHONETICS: Record<string, string> = {
  'آ': 'आ',
  'ا': 'अ',
  'أ': 'अ',
  'إ': 'इ',
  'ب': 'ब',
  'پ': 'प',
  'ت': 'त',
  'ٹ': 'ट',
  'ث': 'स',
  'ج': 'ज',
  'چ': 'च',
  'ح': 'ह',
  'خ': 'ख़',
  'د': 'द',
  'ڈ': 'ड',
  'ذ': 'ज़',
  'ر': 'र',
  'ڑ': 'ड़',
  'ز': 'ज़',
  'ژ': 'ज़',
  'س': 'स',
  'ش': 'श',
  'ص': 'स',
  'ض': 'ज़',
  'ط': 'त',
  'ظ': 'ज़',
  'ع': 'अ',
  'غ': 'ग़',
  'ف': 'फ़',
  'ق': 'क़',
  'ک': 'क',
  'گ': 'ग',
  'ل': 'ल',
  'م': 'म',
  'ن': 'न',
  'ں': 'ँ',
  'و': 'व',
  'ہ': 'ह',
  'ۂ': 'ह',
  'ۃ': 'त',
  'ھ': 'ह',
  'ی': 'य',
  'ے': 'े',
  'ئ': 'इ',
  'ء': '',
  '۔': '.',
  '،': ',',
  '؛': ';',
  '؟': '?'
};

/**
 * Converts Urdu script into Devanagari script phonetically so that devices without a native
 * Urdu voice installed can speak the text with natural Hindustani pronunciation using the Hindi voice.
 */
export function transliterateUrduToDevanagari(text: string): string {
  if (!text || text.trim().length === 0) return '';
  if (!/[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/.test(text)) {
    return text;
  }

  const tokens = text.split(/(\s+|[.,!?:;۔،؟"'\-()[\]{}]+)/);
  const result: string[] = [];

  for (const token of tokens) {
    if (!token) continue;
    if (/^(\s+|[.,!?:;۔،؟"'\-()[\]{}]+)$/.test(token)) {
      result.push(token.replace(/۔/g, '.').replace(/،/g, ',').replace(/؟/g, '?'));
      continue;
    }

    const trimmed = token.trim();
    if (URDU_TO_DEVANAGARI_WORD_MAP[trimmed]) {
      result.push(URDU_TO_DEVANAGARI_WORD_MAP[trimmed]);
      continue;
    }

    let converted = trimmed;
    for (const [urduComp, devComp] of URDU_COMPOUND_PHONETICS) {
      converted = converted.split(urduComp).join(devComp);
    }

    let devanagariWord = '';
    for (const char of converted) {
      devanagariWord += URDU_LETTER_PHONETICS[char] || char;
    }

    result.push(devanagariWord || token);
  }

  return result.join('');
}

// -------------------------------------------------------------
// DEVANAGARI TO ROMAN HINDI TRANSLITERATION (High-Fidelity)
// -------------------------------------------------------------
// Enables devices without native Hindi voices (or with Indian English / default voices)
// to speak Hindi text with authentic Hindustani pronunciation without choking on Devanagari script.

export const DEVANAGARI_TO_ROMAN_WORD_MAP: Record<string, string> = {
  'मुख्य': 'mukhya',
  'विचार': 'vichar',
  'पृष्ठ': 'prishth',
  'निष्कर्ष': 'nishkarsh',
  'बिंदु': 'bindu',
  'बिन्दु': 'bindu',
  'महत्वपूर्ण': 'mahatvapurna',
  'तथ्य': 'tathya',
  'विस्तार': 'vistar',
  'विवरण': 'vivaran',
  'किताब': 'kitaab',
  'पुस्तक': 'pustak',
  'अध्याय': 'adhyay',
  'लेखक': 'lekhak',
  'सबक': 'sabak',
  'सीख': 'seekh',
  'अर्थ': 'arth',
  'मतलब': 'matlab',
  'यह': 'yeh',
  'वह': 'woh',
  'ये': 'ye',
  'वे': 've',
  'है': 'hai',
  'हैं': 'hain',
  'था': 'tha',
  'थी': 'thi',
  'थे': 'the',
  'होगा': 'hoga',
  'होगी': 'hogi',
  'होंगे': 'honge',
  'का': 'ka',
  'की': 'ki',
  'के': 'ke',
  'को': 'ko',
  'में': 'mein',
  'से': 'se',
  'पर': 'par',
  'और': 'aur',
  'या': 'ya',
  'नहीं': 'nahi',
  'ना': 'na',
  'भी': 'bhi',
  'तो': 'toh',
  'कि': 'ki',
  'जो': 'jo',
  'आप': 'aap',
  'तुम': 'tum',
  'हम': 'hum',
  'मैं': 'main',
  'मेरा': 'mera',
  'मेरी': 'meri',
  'मेरे': 'mere',
  'हमारा': 'hamara',
  'हमारी': 'hamari',
  'हमारे': 'hamare',
  'उनका': 'unka',
  'उनकी': 'unki',
  'उनके': 'unke',
  'उसका': 'uska',
  'उसकी': 'uski',
  'उसके': 'uske',
  'इस': 'is',
  'उस': 'us',
  'इन': 'in',
  'उन': 'un',
  'बहुत': 'bahut',
  'अच्छा': 'achha',
  'अच्छी': 'achhi',
  'अच्छे': 'achhe',
  'बात': 'baat',
  'काम': 'kaam',
  'वक़्त': 'waqt',
  'वक्त': 'waqt',
  'समय': 'samay',
  'दिन': 'din',
  'रात': 'raat',
  'लोग': 'log',
  'ज़िंदगी': 'zindagi',
  'जिंदगी': 'zindagi',
  'जीवन': 'jeevan',
  'ज्ञान': 'gyan',
  'ज्ञानवर्धक': 'gyanvardhak',
  'पढ़ना': 'padhna',
  'पढ़ो': 'padho',
  'पढ़ें': 'padhein',
  'समझना': 'samajhna',
  'समझो': 'samjho',
  'समझें': 'samjhein',
  'करना': 'karna',
  'करो': 'karo',
  'करें': 'karein',
  'होना': 'hona',
  'हो': 'ho',
  'गया': 'gaya',
  'गई': 'gayi',
  'गए': 'gaye',
  'सकता': 'sakta',
  'सकती': 'sakti',
  'सकते': 'sakte',
  'चाहिए': 'chahiye',
  'नियम': 'niyam',
  'शक्ति': 'shakti',
  'सफलता': 'safalta',
  'हमेशा': 'hamesha',
  'कदापि': 'kadapi',
  'कभी': 'kabhi',
  'ज्यादा': 'zyada',
  'कम': 'kam',
  'पहले': 'pehle',
  'बाद': 'baad',
  'क्योंकि': 'kyunki',
  'लेकिन': 'lekin',
  'मगर': 'magar',
  'परंतु': 'parantu',
  'अगर': 'agar',
  'यदि': 'yadi',
  'सरल': 'saral',
  'व्याख्या': 'vyakhya'
};

const DEV_VOWELS: Record<string, string> = {
  '\u0905': 'a', '\u0906': 'aa', '\u0907': 'i', '\u0908': 'ee', '\u0909': 'u', '\u090A': 'oo',
  '\u090B': 'ri', '\u090F': 'e', '\u0910': 'ai', '\u0913': 'o', '\u0914': 'au'
};
const DEV_MATRAS: Record<string, string> = {
  '\u093E': 'aa', '\u093F': 'i', '\u0940': 'ee', '\u0941': 'u', '\u0942': 'oo',
  '\u0943': 'ri', '\u0947': 'e', '\u0948': 'ai', '\u094B': 'o', '\u094C': 'au'
};
const DEV_CONSONANTS: Record<string, string> = {
  '\u0915': 'k', '\u0916': 'kh', '\u0917': 'g', '\u0918': 'gh', '\u0919': 'ng',
  '\u091A': 'ch', '\u091B': 'chh', '\u091C': 'j', '\u091D': 'jh', '\u091E': 'ny',
  '\u091F': 't', '\u0920': 'th', '\u0921': 'd', '\u0922': 'dh', '\u0923': 'n',
  '\u0924': 't', '\u0925': 'th', '\u0926': 'd', '\u0927': 'dh', '\u0928': 'n',
  '\u092A': 'p', '\u092B': 'ph', '\u092C': 'b', '\u092D': 'bh', '\u092E': 'm',
  '\u092F': 'y', '\u0930': 'r', '\u0932': 'l', '\u0935': 'v', '\u0936': 'sh',
  '\u0937': 'sh', '\u0938': 's', '\u0939': 'h'
};
const DEV_HALANT = '\u094D';
const DEV_ANUSVARA = '\u0902';
const DEV_CHANDRABINDU = '\u0901';
const DEV_VISARGA = '\u0903';
const DEV_NUQTA = '\u093C';

/**
 * Converts Devanagari script into high-accuracy Roman Hindi phonetics so that any browser
 * or device voice engine (including Indian English and default system voices) can speak
 * Hindi text fluently out loud without skipping or falling silent.
 */
export function transliterateDevanagariToRoman(text: string): string {
  if (!text || text.trim().length === 0) return '';
  if (!/[\u0900-\u097F]/.test(text)) return text;

  const tokens = text.split(/(\s+|[.,!?:;۔،؟।॥"'\-()[\]{}|]+)/);
  const result: string[] = [];

  for (const token of tokens) {
    if (!token) continue;
    if (/^(\s+|[.,!?:;۔،؟"'\-()[\]{}|]+)$/.test(token)) {
      result.push(token.replace(/।|॥/g, '.'));
      continue;
    }

    const trimmed = token.trim();
    if (DEVANAGARI_TO_ROMAN_WORD_MAP[trimmed]) {
      result.push(DEVANAGARI_TO_ROMAN_WORD_MAP[trimmed]);
      continue;
    }

    // Character-level phonetic conversion
    let converted = '';
    for (let i = 0; i < trimmed.length; i++) {
      const ch = trimmed[i];
      const next = trimmed[i + 1];

      if (DEV_VOWELS[ch]) {
        converted += DEV_VOWELS[ch];
      } else if (DEV_CONSONANTS[ch]) {
        let c = DEV_CONSONANTS[ch];
        if (next === DEV_NUQTA) {
          if (ch === '\u0915') c = 'q';
          else if (ch === '\u0916') c = 'kh';
          else if (ch === '\u0917') c = 'gh';
          else if (ch === '\u091C') c = 'z';
          else if (ch === '\u0921') c = 'r';
          else if (ch === '\u0922') c = 'rh';
          else if (ch === '\u092B') c = 'f';
          i++;
        }
        const afterC = trimmed[i + 1];
        if (afterC === DEV_HALANT) {
          converted += c;
          i++; // Skip halant
        } else if (afterC && DEV_MATRAS[afterC]) {
          converted += c + DEV_MATRAS[afterC];
          i++; // Skip matra
        } else if (afterC && DEV_CONSONANTS[afterC]) {
          converted += c + 'a';
        } else if (afterC && DEV_VOWELS[afterC]) {
          converted += c + 'a';
        } else {
          // End of word or syllable (Hindi schwa deletion)
          converted += c;
        }
      } else if (DEV_MATRAS[ch]) {
        converted += DEV_MATRAS[ch];
      } else if (ch === DEV_ANUSVARA || ch === DEV_CHANDRABINDU) {
        converted += 'n';
      } else if (ch === DEV_VISARGA) {
        converted += 'h';
      } else if (ch === '।') {
        converted += '.';
      } else if (ch === '॥') {
        converted += '.';
      } else {
        converted += ch;
      }
    }

    result.push(converted || token);
  }

  return result.join('');
}

// -------------------------------------------------------------
// 4. SENTENCE SPLITTING & ARTIFACT CLEANUP
// -------------------------------------------------------------

/**
 * Splits text into meaningful, natural sentences while protecting common abbreviations
 * (e.g., "e.g.", "Dr.", "Mr.", "Mrs.", "vs.", "etc.").
 * Accurately handles Hindi Devanagari full stops (। ॥), Urdu punctuation, and newlines,
 * and chunks long sentences so browser speech synthesis never times out or freezes.
 */
export function splitTextIntoSentences(text: string): string[] {
  if (!text || text.trim().length === 0) return [];

  // Protect common abbreviations by temporarily swapping periods
  const protectedText = text
    .replace(/\r\n/g, '\n')
    .replace(/\b(e\.g|i\.e|dr|mr|mrs|ms|vs|etc|prof|jr|sr)\./gi, '$1__DOT__');

  // Split on sentence boundaries (. ! ? or Urdu full stop / question mark, Hindi Danda । ॥, and line breaks)
  const rawParts = protectedText.split(/(?<=[.?!۔؟।॥])\s+|\n+/);

  const cleanSentences: string[] = [];

  for (const part of rawParts) {
    const restored = part
      .replace(/__DOT__/g, '.')
      .replace(/[*#_`~[\]]/g, ' ')
      .replace(/^[•\-\*]\s*/, '')
      .replace(/📌|🔑|💡|📖|🧠|🎯|🌐|🕉️|✨/g, '')
      .replace(/["“”‘’']+/g, "'")
      .replace(/[\u2010-\u2015]/g, '-')
      .replace(/\s+/g, ' ')
      .trim();

    // Supports Latin, Devanagari, and Arabic/Urdu scripts
    if (restored.length > 2 && /[a-zA-Z0-9\u0900-\u097F\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/.test(restored)) {
      // If an individual sentence is too long (> 160 characters), split at clause punctuation (, : ;) to avoid Chromium TTS hangs
      if (restored.length > 160) {
        const subParts = restored.split(/(?<=[,:;—\-])\s+/);
        let currentChunk = '';
        for (const sub of subParts) {
          if (!currentChunk) {
            currentChunk = sub;
          } else if ((currentChunk + ' ' + sub).length <= 150) {
            currentChunk += ' ' + sub;
          } else {
            if (currentChunk.trim().length > 2) cleanSentences.push(currentChunk.trim());
            currentChunk = sub;
          }
        }
        if (currentChunk.trim().length > 2) {
          cleanSentences.push(currentChunk.trim());
        }
      } else {
        cleanSentences.push(restored);
      }
    }
  }

  return cleanSentences.length > 0 ? cleanSentences : [text.trim()];
}

// -------------------------------------------------------------
// 5. SYSTEM VOICE DISCOVERY & CLASSIFICATION
// -------------------------------------------------------------

export interface VoiceGroups {
  englishUS: SpeechSynthesisVoice[];
  englishUK: SpeechSynthesisVoice[];
  hindi: SpeechSynthesisVoice[];
  urdu: SpeechSynthesisVoice[];
  indianEnglish: SpeechSynthesisVoice[]; // Ideal for Hinglish
  all: SpeechSynthesisVoice[];
}

export function classifyVoices(allVoices: SpeechSynthesisVoice[]): VoiceGroups {
  const result: VoiceGroups = {
    englishUS: [],
    englishUK: [],
    hindi: [],
    urdu: [],
    indianEnglish: [],
    all: allVoices
  };

  for (const v of allVoices) {
    const lang = (v.lang || '').toLowerCase().replace('_', '-');
    const name = (v.name || '').toLowerCase();

    // Urdu voices
    if (lang.startsWith('ur') || name.includes('urdu') || name.includes('اردو') || name.includes('asad') || name.includes('uzma')) {
      result.urdu.push(v);
    }
    // Hindi voices (comprehensive multi-platform coverage)
    else if (
      lang.startsWith('hi') || 
      name.includes('hindi') || 
      name.includes('हिन्दी') || 
      name.includes('lekha') || 
      name.includes('kalpana') || 
      name.includes('hemant') || 
      name.includes('swara') || 
      name.includes('madhur') ||
      name.includes('heera') ||
      name.includes('veena') ||
      name.includes('geeta') ||
      name.includes('aarav') ||
      name.includes('ananya') ||
      name.includes('aditi')
    ) {
      result.hindi.push(v);
    }
    // Indian English (bilingual friendly)
    else if (
      lang === 'en-in' || 
      lang.startsWith('en-in') || 
      name.includes('india') || 
      name.includes('neerja') || 
      name.includes('prabhat') ||
      name.includes('ravi') ||
      name.includes('rishi') ||
      name.includes('priya') ||
      name.includes('kavya') ||
      name.includes('sangeeta')
    ) {
      result.indianEnglish.push(v);
    }
    // British English
    else if (lang === 'en-gb' || name.includes('uk') || name.includes('british')) {
      result.englishUK.push(v);
    }
    // US English
    else if (lang.startsWith('en')) {
      result.englishUS.push(v);
    }
  }

  return result;
}

/**
 * Safely loads browser voices, handling Chromium's asynchronous `voiceschanged` event
 * and falling back cleanly if voices are already loaded or if the event does not fire.
 */
export function loadVoicesSafely(callback?: (voices: SpeechSynthesisVoice[]) => void): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      resolve([]);
      return;
    }

    const immediate = window.speechSynthesis.getVoices();
    if (immediate && immediate.length > 0) {
      if (callback) callback(immediate);
      resolve(immediate);
      return;
    }

    let resolved = false;
    const handleVoices = () => {
      if (resolved) return;
      const loaded = window.speechSynthesis.getVoices();
      if (loaded && loaded.length > 0) {
        resolved = true;
        window.speechSynthesis.removeEventListener('voiceschanged', handleVoices);
        if (callback) callback(loaded);
        resolve(loaded);
      }
    };

    window.speechSynthesis.addEventListener('voiceschanged', handleVoices);

    setTimeout(() => {
      if (!resolved) {
        resolved = true;
        window.speechSynthesis.removeEventListener('voiceschanged', handleVoices);
        const finalCheck = window.speechSynthesis.getVoices();
        if (callback) callback(finalCheck || []);
        resolve(finalCheck || []);
      }
    }, 350);
  });
}

export interface SelectedVoiceInfo {
  voice: SpeechSynthesisVoice | null;
  lang: string;
  isFallback: boolean;
  notice: string | null;
  displayName: string;
}

/**
 * Robust voice selector that GUARANTEES `lang` always matches the selected voice,
 * preventing Chromium crashes when a requested language (e.g., 'hi-IN') is unavailable in the OS.
 */
/**
 * Sanitizes voice names by stripping out company/vendor prefixes
 * (Microsoft, Google, Apple, Amazon, ElevenLabs, etc.) for clean character presentation.
 */
export function cleanVoiceDisplayName(name: string): string {
  if (!name) return '';
  const cleaned = name
    .replace(/\b(Microsoft|Google|Apple|Amazon|ElevenLabs|11labs)\b/gi, '')
    .replace(/Online\s*\(Natural\)/gi, 'Natural')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/^[-–—:]\s*/, '')
    .replace(/\s*[-–—:]$/, '');
  return cleaned || name;
}

export const FEMALE_VOICE_KEYWORDS = [
  'zira', 'swara', 'kalpana', 'lekha', 'sangeeta', 'kavya', 'priya', 'neerja',
  'samantha', 'victoria', 'karen', 'moira', 'fiona', 'tessa', 'veena', 'ananya',
  'heera', 'sunita', 'female', 'woman', 'girl', 'jenny', 'aria', 'sara', 'hazel',
  'susan', 'catherine', 'linda', 'ava', 'emma', 'stephanie', 'kathy', 'lucy', 'serena', 'yuna',
  'anna', 'helena', 'ioana', 'monica', 'paulina', 'amelie', 'audrey', 'marie', 'laura', 'maja',
  'google हिन्दी', 'google hindi', 'google us english', 'google uk english female'
];

export const MALE_VOICE_KEYWORDS = [
  'madhur', 'hemant', 'aarav', 'prabhat', 'ravi', 'rishi', 'asad', 'david',
  'guy', 'brian', 'christopher', 'andrew', 'eric', 'ryan', 'mark', 'george',
  'oliver', 'richard', 'james', 'charles', 'male', 'man', 'boy', 'daniel',
  'arthur', 'thomas', 'alex', 'fred', 'nathan', 'stefan', 'cosmo', 'michi',
  'google uk english male'
];

export function isExplicitlyFemale(name: string): boolean {
  if (!name) return false;
  const lower = name.toLowerCase();
  return FEMALE_VOICE_KEYWORDS.some(k => lower.includes(k));
}

export function isExplicitlyMale(name: string): boolean {
  if (!name) return false;
  const lower = name.toLowerCase();
  return MALE_VOICE_KEYWORDS.some(k => lower.includes(k));
}

export function selectVoiceForPlayback(
  allVoices: SpeechSynthesisVoice[],
  mode: 'en-US' | 'en-GB' | 'hi-IN' | 'ur-PK' | 'hinglish',
  explicitVoiceURI?: string
): SelectedVoiceInfo {
  // If specific voice selected by user exists, honor it
  if (explicitVoiceURI) {
    const exact = allVoices.find(v => v.voiceURI === explicitVoiceURI);
    if (exact) {
      const cleanName = cleanVoiceDisplayName(exact.name);
      return {
        voice: exact,
        lang: exact.lang || 'en-US',
        isFallback: false,
        notice: null,
        displayName: `${cleanName} (${exact.lang})`
      };
    }
  }

  const groups = classifyVoices(allVoices);

  // Helper to find a male voice from an array, avoiding female names
  const findMaleVoice = (voiceList: SpeechSynthesisVoice[]): SpeechSynthesisVoice | null => {
    // 1. Explicitly named male voice
    const explicit = voiceList.find(v => isExplicitlyMale(v.name) && !isExplicitlyFemale(v.name));
    if (explicit) return explicit;
    // 2. Any voice that does not contain female keywords
    const nonFemale = voiceList.find(v => !isExplicitlyFemale(v.name));
    if (nonFemale) return nonFemale;
    return null;
  };

  // Helper to get any male voice across all available voices
  const findAnyMaleVoiceInSystem = (): SpeechSynthesisVoice | null => {
    return (
      allVoices.find(v => isExplicitlyMale(v.name) && !isExplicitlyFemale(v.name)) ||
      allVoices.find(v => !isExplicitlyFemale(v.name)) ||
      null
    );
  };

  if (mode === 'en-GB') {
    const ukMale = findMaleVoice(groups.englishUK);
    if (ukMale) {
      return {
        voice: ukMale,
        lang: ukMale.lang || 'en-GB',
        isFallback: false,
        notice: null,
        displayName: cleanVoiceDisplayName(ukMale.name)
      };
    }
    const usMale = findMaleVoice(groups.englishUS) || findAnyMaleVoiceInSystem();
    return {
      voice: usMale || (allVoices[0] || null),
      lang: usMale?.lang || 'en-US',
      isFallback: true,
      notice: usMale ? `UK English voice not found. Using ${cleanVoiceDisplayName(usMale.name)} (Male).` : null,
      displayName: usMale ? cleanVoiceDisplayName(usMale.name) : 'System Default'
    };
  }

  if (mode === 'hi-IN') {
    // Look strictly for true Hindi voices (hi, hi-IN)
    const hiVoices = allVoices.filter(v => {
      const l = (v.lang || '').toLowerCase().replace('_', '-');
      const n = (v.name || '').toLowerCase();
      return (
        l === 'hi' || 
        l.startsWith('hi-') || 
        n.includes('hindi') || 
        n.includes('हिन्दी') || 
        n.includes('hemant') || 
        n.includes('madhur') ||
        n.includes('aarav')
      );
    });

    // Strictly prefer true Male Hindi voice first (Madhur, Hemant, Aarav)
    const hiMaleVoice = hiVoices.find(v => isExplicitlyMale(v.name) && !isExplicitlyFemale(v.name));
    if (hiMaleVoice) {
      return {
        voice: hiMaleVoice,
        lang: hiMaleVoice.lang || 'hi-IN',
        isFallback: false,
        notice: null,
        displayName: cleanVoiceDisplayName(hiMaleVoice.name)
      };
    }

    // Next prefer Indian English male voice (Prabhat, Ravi, Rishi) so pronunciation matches natural Indian cadence
    const inEnMaleVoice = findMaleVoice(groups.indianEnglish);
    if (inEnMaleVoice) {
      return {
        voice: inEnMaleVoice,
        lang: inEnMaleVoice.lang || 'en-IN',
        isFallback: true,
        notice: `Speaking with ${cleanVoiceDisplayName(inEnMaleVoice.name)} (Male).`,
        displayName: cleanVoiceDisplayName(inEnMaleVoice.name)
      };
    }

    // Next fallback to studio/system Male English voice (David, Guy, Christopher, Brian)
    const usMale = findMaleVoice(groups.englishUS) || findAnyMaleVoiceInSystem();
    if (usMale) {
      return {
        voice: usMale,
        lang: usMale.lang || 'en-US',
        isFallback: true,
        notice: `Speaking with ${cleanVoiceDisplayName(usMale.name)} (Male).`,
        displayName: cleanVoiceDisplayName(usMale.name)
      };
    }

    const defaultVoice = allVoices.find(v => !isExplicitlyFemale(v.name)) || allVoices[0] || null;
    return {
      voice: defaultVoice,
      lang: defaultVoice?.lang || 'en-US',
      isFallback: true,
      notice: 'Using system male voice.',
      displayName: defaultVoice ? cleanVoiceDisplayName(defaultVoice.name) : 'System Default'
    };
  }

  if (mode === 'ur-PK') {
    // 1. Look strictly for actually available Urdu voices (ur-IN, ur-PK, ur)
    const urVoices = allVoices.filter(v => {
      const l = (v.lang || '').toLowerCase().replace('_', '-');
      const n = (v.name || '').toLowerCase();
      return l === 'ur' || l.startsWith('ur-') || n.includes('urdu') || n.includes('اردو') || n.includes('asad');
    });

    const urMale = findMaleVoice(urVoices);
    if (urMale) {
      return {
        voice: urMale,
        lang: urMale.lang || 'ur-IN',
        isFallback: false,
        notice: null,
        displayName: cleanVoiceDisplayName(urMale.name)
      };
    }

    // Next prefer Indian English or US Male voice
    const inEnMale = findMaleVoice(groups.indianEnglish) || findMaleVoice(groups.englishUS) || findAnyMaleVoiceInSystem();
    if (inEnMale) {
      return {
        voice: inEnMale,
        lang: inEnMale.lang || 'en-IN',
        isFallback: true,
        notice: `Using ${cleanVoiceDisplayName(inEnMale.name)} (Male) for Urdu.`,
        displayName: cleanVoiceDisplayName(inEnMale.name)
      };
    }

    const fallbackVoice = allVoices.find(v => !isExplicitlyFemale(v.name)) || allVoices[0] || null;
    return {
      voice: fallbackVoice,
      lang: fallbackVoice?.lang || 'en-US',
      isFallback: true,
      notice: null,
      displayName: fallbackVoice ? cleanVoiceDisplayName(fallbackVoice.name) : 'System Default'
    };
  }

  if (mode === 'hinglish') {
    // 1. Prefer Indian English Male voice (Prabhat, Ravi, Rishi)
    const inEnMaleVoice = findMaleVoice(groups.indianEnglish);
    if (inEnMaleVoice) {
      return {
        voice: inEnMaleVoice,
        lang: inEnMaleVoice.lang || 'en-IN',
        isFallback: false,
        notice: `Using ${cleanVoiceDisplayName(inEnMaleVoice.name)} (Male) for natural Hinglish pronunciation.`,
        displayName: cleanVoiceDisplayName(inEnMaleVoice.name)
      };
    }
    // 2. Next check US Male voice (David, Guy, Brian, Christopher)
    const usMaleVoice = findMaleVoice(groups.englishUS) || findAnyMaleVoiceInSystem();
    if (usMaleVoice) {
      return {
        voice: usMaleVoice,
        lang: usMaleVoice.lang || 'en-US',
        isFallback: false,
        notice: `Using ${cleanVoiceDisplayName(usMaleVoice.name)} (Male) for Hinglish.`,
        displayName: cleanVoiceDisplayName(usMaleVoice.name)
      };
    }
    const fallbackVoice = allVoices.find(v => !isExplicitlyFemale(v.name)) || allVoices[0] || null;
    return {
      voice: fallbackVoice,
      lang: fallbackVoice?.lang || 'en-US',
      isFallback: true,
      notice: null,
      displayName: fallbackVoice ? cleanVoiceDisplayName(fallbackVoice.name) : 'System Default'
    };
  }

  // Default: en-US (Prioritize the best, natural male voice: David, Guy, Christopher, Mark, George, UK Male)
  const usMale = findMaleVoice(groups.englishUS) || findMaleVoice(groups.englishUK) || findAnyMaleVoiceInSystem();
  if (usMale) {
    return {
      voice: usMale,
      lang: usMale.lang || 'en-US',
      isFallback: false,
      notice: null,
      displayName: cleanVoiceDisplayName(usMale.name)
    };
  }
  const anyVoice = allVoices.find(v => !isExplicitlyFemale(v.name)) || allVoices[0] || null;
  return {
    voice: anyVoice,
    lang: anyVoice?.lang || 'en-US',
    isFallback: anyVoice ? true : false,
    notice: anyVoice ? `Using ${cleanVoiceDisplayName(anyVoice.name)} (Male).` : null,
    displayName: anyVoice ? cleanVoiceDisplayName(anyVoice.name) : 'System Default'
  };
}

/**
 * Finds the highest quality default voice for the requested language.
 */
export function getBestVoice(
  groups: VoiceGroups,
  preferredType: 'en-US' | 'en-GB' | 'hi-IN' | 'ur-PK' | 'hinglish',
  selectedVoiceURI?: string
): { voice: SpeechSynthesisVoice | null; isFallback: boolean; fallbackMessage?: string } {
  const result = selectVoiceForPlayback(groups.all, preferredType, selectedVoiceURI);
  return {
    voice: result.voice,
    isFallback: result.isFallback,
    fallbackMessage: result.notice || undefined
  };
}

/**
 * Resumes and primes browser speech synthesis subsystem synchronously during user gesture.
 */
export function unlockSpeechAudio(): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    }
  } catch (err) {
    // Ignore unlock errors
  }
}


/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PDFBook } from '../types';

/**
 * Creates a valid PDF 1.4 binary Uint8Array containing a multi-page guide.
 */
export function generateSamplePdfBytes(): Uint8Array {
  const pages = [
    { 
      title: 'The Art of Reading', 
      sub: 'A Modern Guide to Digital Literature', 
      body: [
        'Chapter 1: The Beauty of the Written Word',
        '',
        'Reading is to the mind what exercise is to the body.',
        'In this digital age, having an ultra-crisp, distraction-free reading experience',
        'allows you to absorb wisdom without fatigue. Welcome to Smart PDF Reader!',
        '',
        'Features you will love in this reader:',
        '- Ultra-Crisp Canvas Rendering with High-DPI Retina Support',
        '- Poora Page (Fit Page) & Fit Width reading modes',
        '- Offline-first personal library stored directly in your browser',
        '- Progress auto-tracking, bookmarks, highlights, and notes.'
      ] 
    },
    { 
      title: 'Chapter 2: Deep Focus & Layouts', 
      sub: 'Mastering Attention in a Distracted World', 
      body: [
        'To read deeply is to dwell in thoughtful contemplation.',
        '',
        'Use the quick toggle in the toolbar or bottom bar to switch between:',
        '1. Poora Page (Fit Page): See the complete page from top to bottom',
        '   without any clipping or hidden content.',
        '2. Fit Width: Fill the full width of your device screen for larger text.',
        '3. Focus Mode: Hide all distraction bars and immerse in pure text.',
        '',
        'Adjust your color themes (Light, Dark, Sepia) anytime to soothe your eyes.'
      ] 
    },
    { 
      title: 'Chapter 3: Highlights & Annotations', 
      sub: 'Capturing Insights That Matter', 
      body: [
        'Active reading transforms passive absorption into active mastery.',
        '',
        'Select any phrase or sentence in this book to:',
        '- Highlight in Yellow, Green, Blue, or Pink',
        '- Add page notes to capture key takeaways',
        '- Save bookmarks for quick reference later',
        '',
        'Everything is preserved locally and works 100% offline without internet.'
      ] 
    },
    { 
      title: 'Chapter 4: Reading Habits & Insights', 
      sub: 'Building Consistent Daily Practice', 
      body: [
        'Track your reading speed, streak days, and completed pages in the Insights panel.',
        '',
        'Key reading recommendations:',
        '- Aim for 20-30 minutes of focused reading every day.',
        '- Review your highlights and notes regularly.',
        '- Organize your favorite books into custom collections.',
        '',
        'Happy reading and welcome to your new digital sanctuary!'
      ] 
    }
  ];

  let objects: string[] = [];
  function addObject(content: string) {
    objects.push(content);
    return objects.length;
  }

  const fontObj = addObject('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
  const fontBoldObj = addObject('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>');

  const contentObjNums: number[] = [];

  for (let pIdx = 0; pIdx < pages.length; pIdx++) {
    const page = pages[pIdx];
    let stream = 'BT\n';
    
    // Header Accent Box
    stream += 'ET\n';
    stream += 'q 0.93 0.35 0.05 rg 40 765 515 4 re f Q\n';
    stream += 'BT\n';

    // Title
    stream += '/F2 24 Tf\n';
    stream += '40 725 Td\n';
    stream += '(' + page.title.replace(/[()\\\\]/g, '\\$&') + ') Tj\n';

    // Subtitle
    stream += '/F1 13 Tf\n';
    stream += '0 -26 Td\n';
    stream += '(' + page.sub.replace(/[()\\\\]/g, '\\$&') + ') Tj\n';

    // Divider Line
    stream += 'ET\n';
    stream += 'q 0.85 0.85 0.85 rg 40 680 515 1 re f Q\n';
    stream += 'BT\n';

    // Body lines
    stream += '/F1 11 Tf\n';
    stream += '40 645 Td\n';
    for (let i = 0; i < page.body.length; i++) {
      const line = page.body[i];
      if (line === '') {
        stream += '0 -16 Td\n';
      } else {
        stream += '(' + line.replace(/[()\\\\]/g, '\\$&') + ') Tj\n';
        stream += '0 -20 Td\n';
      }
    }

    // Footer divider and page number
    stream += 'ET\n';
    stream += 'q 0.9 0.9 0.9 rg 40 60 515 1 re f Q\n';
    stream += 'BT\n';
    stream += '/F1 9 Tf\n';
    stream += '40 42 Td\n';
    stream += '(Smart PDF Reader  |  Page ' + (pIdx + 1) + ' of ' + pages.length + ') Tj\n';
    stream += 'ET\n';

    const encoder = new TextEncoder();
    const streamBytes = encoder.encode(stream);
    const cObj = addObject('<< /Length ' + streamBytes.length + ' >>\nstream\n' + stream + 'endstream');
    contentObjNums.push(cObj);
  }

  // Create page objects
  const finalPageObjNums: number[] = [];
  for (let i = 0; i < pages.length; i++) {
    const pNum = addObject('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents ' + contentObjNums[i] + ' 0 R /Resources << /Font << /F1 ' + fontObj + ' 0 R /F2 ' + fontBoldObj + ' 0 R >> >> >>');
    finalPageObjNums.push(pNum);
  }

  const catalog = '<< /Type /Catalog /Pages 2 0 R >>';
  const pagesObj = '<< /Type /Pages /Kids [' + finalPageObjNums.map(n => n + ' 0 R').join(' ') + '] /Count ' + pages.length + ' >>';

  let pdfText = '%PDF-1.4\n';
  const offsets: number[] = [];
  const encoder = new TextEncoder();

  // 1: Catalog
  offsets.push(encoder.encode(pdfText).length);
  pdfText += '1 0 obj\n' + catalog + '\nendobj\n';

  // 2: Pages
  offsets.push(encoder.encode(pdfText).length);
  pdfText += '2 0 obj\n' + pagesObj + '\nendobj\n';

  // 3 onwards:
  for (let i = 0; i < objects.length; i++) {
    offsets.push(encoder.encode(pdfText).length);
    pdfText += (i + 3) + ' 0 obj\n' + objects[i] + '\nendobj\n';
  }

  const xrefStart = encoder.encode(pdfText).length;
  pdfText += 'xref\n';
  pdfText += '0 ' + (objects.length + 3) + '\n';
  pdfText += '0000000000 65535 f \n';
  for (const off of offsets) {
    pdfText += String(off).padStart(10, '0') + ' 00000 n \n';
  }
  pdfText += 'trailer\n';
  pdfText += '<< /Size ' + (objects.length + 3) + ' /Root 1 0 R >>\n';
  pdfText += 'startxref\n';
  pdfText += xrefStart + '\n';
  pdfText += '%%EOF\n';

  return encoder.encode(pdfText);
}

/**
 * Creates a sample starter PDF book object with fileBlob.
 */
export function createStarterSampleBook(): PDFBook {
  const bytes = generateSamplePdfBytes();
  const blob = new Blob([bytes], { type: 'application/pdf' });
  const file = new File([blob], 'The Art of Reading.pdf', { type: 'application/pdf' });

  return {
    id: 'starter-guide-book',
    title: 'The Art of Reading (Guide)',
    fileName: 'The Art of Reading.pdf',
    fileSize: bytes.length,
    addedAt: new Date().toISOString(),
    lastOpened: new Date().toISOString(),
    totalPages: 4,
    currentPage: 1,
    scrollOffset: 0,
    progressPercent: 25,
    fileBlob: file,
    isFavorite: true,
  };
}

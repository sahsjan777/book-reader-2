/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export async function generateThumbnail(file: File): Promise<string | undefined> {
  const pdfjsLib = (window as any).pdfjsLib;
  if (!pdfjsLib) return undefined;

  try {
    const arrayBuffer = await file.arrayBuffer();
    const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
    const pdf = await loadingTask.promise;
    const page = await pdf.getPage(1);
    
    // Render at crisp 1.0 scale with high quality for sharp covers
    const viewport = page.getViewport({ scale: 1.0 });
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d', { alpha: false });
    
    if (!context) return undefined;
    
    canvas.height = viewport.height;
    canvas.width = viewport.width;
    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = 'high';
    
    await page.render({
      canvasContext: context,
      viewport: viewport
    }).promise;
    
    const thumbnail = canvas.toDataURL('image/jpeg', 0.85);
    
    // Clean up
    canvas.width = 0;
    canvas.height = 0;
    
    return thumbnail;
  } catch (err) {
    console.error('Error generating thumbnail:', err);
    return undefined;
  }
}

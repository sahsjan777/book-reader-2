/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface PDFBook {
  id: string;
  title: string;
  fileName: string;
  fileSize: number;
  addedAt: string;
  lastOpened: string | null;
  totalPages: number;
  currentPage: number;
  scrollOffset: number; // scroll percent (0 to 1)
  progressPercent: number; // (0 to 100)
  fileBlob?: Blob; // loaded dynamically from IndexedDB
  isFavorite?: boolean;
  thumbnail?: string; // base64 thumbnail from first page
  collectionIds?: string[]; // IDs of collections this book belongs to
  author?: string;
  folderId?: string | null;
  fileFormat?: 'pdf' | 'epub' | 'other';
  readingStatus?: 'want-to-read' | 'reading' | 'finished' | 'unread';
  isNewImport?: boolean;
}

export interface Folder {
  id: string;
  name: string;
  description?: string;
  color?: string;
  createdAt: number;
  updatedAt?: number;
}

export interface Collection {
  id: string;
  name: string;
  createdAt: number;
  updatedAt?: number;
}

export interface Bookmark {
  id: string;
  bookId: string;
  pageNumber: number;
  label: string;
  createdAt: string;
}

export interface BookNote {
  id: string;
  bookId: string;
  pageNumber: number;
  content: string;
  quote?: string; // Optional attached quote from highlighted/selected text
  highlightId?: string; // Optional reference to a highlight
  createdAt: string;
  updatedAt: string;
}

export interface Highlight {
  id: string;
  bookId: string;
  pageNumber: number;
  text: string;
  color: string; // e.g., 'yellow', 'green', 'blue', 'pink'
  rects: {
    left: number;  // as percent of page width (0 to 100)
    top: number;   // as percent of page height (0 to 100)
    width: number;  // as percent of page width (0 to 100)
    height: number; // as percent of page height (0 to 100)
  }[];
  startIndex?: number; // Character offset in page text
  endIndex?: number;   // Character offset in page text
  createdAt: string;
}

export interface ReaderSettings {
  zoom?: number;
  scrollMode: 'vertical' | 'continuous';
  theme: 'light' | 'dark' | 'sepia' | 'amoled';
  fontFamily?: 'sans' | 'serif' | 'display' | 'mono' | 'poppins' | 'source';
  fontSize?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl';
  lineHeight?: 'tight' | 'normal' | 'relaxed' | 'loose';
  readingWidth?: 'narrow' | 'normal' | 'wide' | 'full';
  pageFit?: 'fit-width' | 'fit-page' | 'original' | 'two-page';
  pageMargin?: 'none' | 'compact' | 'normal' | 'spacious';
  textAlign?: 'left' | 'justify' | 'center';
  letterSpacing?: 'tight' | 'normal' | 'wide' | 'wider';
}

export interface ReadingSession {
  bookId: string;
  date: string; // YYYY-MM-DD
  pagesRead: number;
  durationMs: number; // in milliseconds
}

export interface ReadingStats {
  totalBooks: number;
  completedBooks: number;
  totalPagesRead: number;
  totalReadingTimeMs: number;
  streakDays: number;
}

export interface SavedHinglish {
  id: string;
  bookId: string;
  pageNumber: number;
  quote?: string;
  explanation: string;
  mode: 'explain' | 'summary' | 'translate';
  createdAt: string;
}

export interface BackupData {
  version: number;
  exportedAt: string;
  appName: string;
  books: Omit<PDFBook, 'fileBlob'>[];
  bookmarks: Bookmark[];
  notes: BookNote[];
  highlights: Highlight[];
  sessions: ReadingSession[];
  collections: Collection[];
  folders?: Folder[];
  savedHinglish?: SavedHinglish[];
  settings?: Record<string, any>;
}

export interface AutoBackupSnapshot {
  id: string;
  createdAt: string;
  label?: string;
  itemCount: {
    books: number;
    bookmarks: number;
    notes: number;
    highlights: number;
    sessions: number;
  };
  data: BackupData;
}

export interface DataSafetyStats {
  lastBackupAt: string | null;
  autoBackupActive: boolean;
  totalSnapshots: number;
  protectedCounts: {
    books: number;
    bookmarks: number;
    notes: number;
    highlights: number;
  };
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Bookmark as BookmarkIcon, Plus, Trash, X } from 'lucide-react';
import { Bookmark } from '../types';

interface BookmarksPanelProps {
  bookmarks: Bookmark[];
  currentPage: number;
  theme?: 'light' | 'dark';
  onAddBookmark: (label: string) => void;
  onDeleteBookmark: (id: string) => void;
  onJumpToPage: (pageNumber: number) => void;
  onClose: () => void;
}

export default function BookmarksPanel({
  bookmarks,
  currentPage,
  theme = 'light',
  onAddBookmark,
  onDeleteBookmark,
  onJumpToPage,
  onClose
}: BookmarksPanelProps) {
  const [newLabel, setNewLabel] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const label = newLabel.trim() || `Bookmark Page ${currentPage}`;
    onAddBookmark(label);
    setNewLabel('');
  };

  const handleDeleteWithConfirm = (id: string) => {
    if (confirmDeleteId === id) {
      onDeleteBookmark(id);
      setConfirmDeleteId(null);
    } else {
      setConfirmDeleteId(id);
    }
  };

  const isCurrentPageBookmarked = bookmarks.some(b => b.pageNumber === currentPage);
  const isDark = theme === 'dark';

  return (
    <div className={`flex h-full flex-col transition-colors duration-300 ${
      isDark ? 'bg-[#0D0D0D] text-[#E0E0E0]' : 'bg-white text-slate-800'
    }`}>
      {/* Header */}
      <div className={`flex items-center justify-between border-b p-4 ${
        isDark ? 'border-white/5' : 'border-slate-200'
      }`}>
        <h3 className={`font-display italic flex items-center gap-2 text-sm ${
          isDark ? 'text-white' : 'text-slate-900'
        }`}>
          <BookmarkIcon className="h-4 w-4 text-orange-500" /> Bookmarks
        </h3>
        <button
          id="bookmarks-close-btn"
          onClick={onClose}
          className={`rounded-full p-1 ${isDark ? 'hover:bg-white/5' : 'hover:bg-slate-100'}`}
        >
          <X className={`h-4 w-4 ${isDark ? 'text-slate-400' : 'text-slate-500'}`} />
        </button>
      </div>

      {/* Quick Add Form */}
      <div className={`border-b p-4 ${isDark ? 'border-white/5' : 'border-slate-200'}`}>
        <form onSubmit={handleAdd} className="space-y-3">
          <div className={`text-[10px] uppercase tracking-wider font-medium ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            Current Page: <span className={`font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>Page {currentPage}</span>
          </div>
          <div className="flex gap-2">
            <input
              id="bookmark-label-input"
              type="text"
              placeholder="e.g., Chapter 1, Notes..."
              value={newLabel}
              onChange={(e) => setNewLabel(e.target.value)}
              className={`flex-1 rounded-full border px-3 py-1.5 text-xs focus:border-orange-500 outline-none transition-colors ${
                isDark ? 'border-white/10 bg-[#161616] text-white' : 'border-slate-200 bg-slate-50 text-slate-900'
              }`}
            />
            <button
              id="bookmark-add-btn"
              type="submit"
              disabled={isCurrentPageBookmarked}
              className="flex h-8 w-8 items-center justify-center rounded-full bg-orange-600 hover:bg-orange-500 text-white disabled:opacity-30 transition-all cursor-pointer font-bold"
              title={isCurrentPageBookmarked ? "Page already bookmarked" : "Add Bookmark"}
            >
              <Plus className="h-4 w-4" />
            </button>
          </div>
          {isCurrentPageBookmarked && (
            <div className="text-[10px] text-orange-500 font-medium tracking-wide">This page is already bookmarked.</div>
          )}
        </form>
      </div>

      {/* Bookmarks List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {bookmarks.length === 0 ? (
          <div className={`text-center py-8 font-serif italic text-xs ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
            No bookmarks added yet.
          </div>
        ) : (
          bookmarks.map((bookmark) => (
            <div
              id={`bookmark-item-${bookmark.id}`}
              key={bookmark.id}
              className={`group flex items-center justify-between rounded-lg border p-3 transition-all ${
                bookmark.pageNumber === currentPage
                  ? 'border-orange-500/20 bg-orange-500/5'
                  : isDark 
                    ? 'border-white/5 bg-[#121212] hover:border-white/10' 
                    : 'border-slate-200 bg-slate-50 hover:border-slate-300'
              }`}
            >
              <div 
                onClick={() => onJumpToPage(bookmark.pageNumber)}
                className="min-w-0 flex-1 cursor-pointer"
              >
                <div className={`font-semibold text-xs truncate group-hover:text-orange-500 transition-colors ${
                  isDark ? 'text-white' : 'text-slate-900'
                }`}>
                  {bookmark.label}
                </div>
                <div className={`text-[9px] mt-0.5 font-mono uppercase ${
                  isDark ? 'text-slate-400' : 'text-slate-500'
                }`}>
                  Page {bookmark.pageNumber} • {new Date(bookmark.createdAt).toLocaleDateString()}
                </div>
              </div>
              
              {confirmDeleteId === bookmark.id ? (
                <div className="flex items-center gap-1 animate-in fade-in duration-150 shrink-0">
                  <span className="text-[9px] text-red-500 font-bold">Delete?</span>
                  <button
                    onClick={() => handleDeleteWithConfirm(bookmark.id)}
                    className="px-1.5 py-0.5 rounded bg-red-600 text-white text-[9px] font-bold uppercase cursor-pointer"
                  >
                    Yes
                  </button>
                  <button
                    onClick={() => setConfirmDeleteId(null)}
                    className="px-1.5 py-0.5 rounded border text-[9px] cursor-pointer"
                  >
                    No
                  </button>
                </div>
              ) : (
                <button
                  id={`bookmark-delete-btn-${bookmark.id}`}
                  onClick={() => setConfirmDeleteId(bookmark.id)}
                  className={`opacity-0 group-hover:opacity-100 rounded-full p-1 text-slate-400 hover:text-red-400 transition-all cursor-pointer ${
                    isDark ? 'hover:bg-white/5' : 'hover:bg-slate-100'
                  }`}
                  title="Delete Bookmark"
                >
                  <Trash className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

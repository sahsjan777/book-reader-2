/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useRef, useMemo, useCallback } from 'react';
import { 
  Play, Pause, Square, SkipForward, SkipBack, Volume2, FastForward, 
  Mic, Settings2, AlertCircle, X, ChevronDown, ChevronUp,
  Minimize2, Maximize2, Loader2
} from 'lucide-react';
import { 
  detectLanguage, 
  splitTextIntoSentences, 
  loadVoicesSafely,
  selectVoiceForPlayback,
  cleanVoiceDisplayName,
  isExplicitlyFemale,
  isExplicitlyMale,
  transliterateUrduToDevanagari,
  transliterateDevanagariToRoman,
  transliterateRomanHindiToDevanagari,
  unlockSpeechAudio,
  TTSLanguage 
} from '../lib/tts-engine';

interface SpeakPlayerBarProps {
  pdfDoc?: any;
  pageText: string;
  customText?: string;
  languageHint?: TTSLanguage;
  currentPage: number;
  totalPages: number;
  isDark?: boolean;
  isSepia?: boolean;
  showControls?: boolean;
  onPageChange: (nextPage: number) => void;
  onClose: () => void;
  onCurrentSentenceChange?: (sentence: string) => void;
}

export type VoiceMode = 'en-US' | 'en-GB' | 'hi-IN' | 'ur-PK' | 'hinglish';

export default function SpeakPlayerBar({
  pdfDoc,
  pageText,
  customText,
  languageHint,
  currentPage,
  totalPages,
  isDark,
  isSepia,
  showControls = true,
  onPageChange,
  onClose,
  onCurrentSentenceChange
}: SpeakPlayerBarProps) {
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [sentenceIndex, setSentenceIndex] = useState<number>(0);
  const [rate, setRate] = useState<number>(() => {
    const saved = localStorage.getItem('reader_speak_rate');
    return saved ? parseFloat(saved) : 1.0;
  });
  const [autoAdvance, setAutoAdvance] = useState<boolean>(() => {
    const saved = localStorage.getItem('reader_speak_auto_advance');
    return saved !== null ? saved === 'true' : true;
  });
  const [showVoiceSettings, setShowVoiceSettings] = useState<boolean>(false);
  const [isMinimized, setIsMinimized] = useState<boolean>(false);

  // Status and Error Messages for visible UI error handling
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [fallbackNotice, setFallbackNotice] = useState<string | null>(null);
  const [isAudioLoading, setIsAudioLoading] = useState<boolean>(false);

  // System voices list
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [voiceMode, setVoiceMode] = useState<VoiceMode>(() => {
    const saved = localStorage.getItem('reader_voice_mode') as VoiceMode;
    return saved || 'hi-IN';
  });
  const [selectedVoiceURI, setSelectedVoiceURI] = useState<string>(() => {
    return localStorage.getItem('reader_selected_voice_uri') || '';
  });
  const [spokenSentenceDisplay, setSpokenSentenceDisplay] = useState<string>('');

  // Refs for tracking playback loop
  const sentencesRef = useRef<string[]>([]);
  const isPlayingRef = useRef<boolean>(true);
  const isPausedRef = useRef<boolean>(false);
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);
  const sharedAudioRef = useRef<HTMLAudioElement | null>(null);
  const sentenceIndexRef = useRef<number>(0);
  const rateRef = useRef<number>(rate);
  const autoAdvanceRef = useRef<boolean>(autoAdvance);
  const voiceModeRef = useRef<VoiceMode>(voiceMode);
  const selectedVoiceURIRef = useRef<string>(selectedVoiceURI);
  const voicesRef = useRef<SpeechSynthesisVoice[]>([]);
  const retryRef = useRef<boolean>(false);
  const failedVoicesRef = useRef<Set<string>>(new Set());
  const prevTextRef = useRef<string>('');
  const prevPageRef = useRef<number>(-1);
  const prevHintRef = useRef<TTSLanguage | undefined>(undefined);
  const effectIdRef = useRef<number>(0);
  const activeSpeechIdRef = useRef<number>(0);
  const abortControllerRef = useRef<AbortController | null>(null);
  const audioCacheRef = useRef<Map<string, { audioBase64: string; format: string; translatedText?: string }>>(new Map());
  const onPageChangeRef = useRef(onPageChange);
  const onCurrentSentenceChangeRef = useRef(onCurrentSentenceChange);

  onPageChangeRef.current = onPageChange;
  onCurrentSentenceChangeRef.current = onCurrentSentenceChange;
  isPlayingRef.current = isPlaying;
  isPausedRef.current = isPaused;
  sentenceIndexRef.current = sentenceIndex;
  rateRef.current = rate;
  autoAdvanceRef.current = autoAdvance;
  voiceModeRef.current = voiceMode;
  selectedVoiceURIRef.current = selectedVoiceURI;
  voicesRef.current = voices;

  // 1. Initial Voice Discovery with async voiceschanged handling
  useEffect(() => {
    let active = true;

    if (typeof window !== 'undefined') {
      try {
        localStorage.removeItem('reader_voice_gender');
      } catch (e) {}
    }

    const refreshVoiceList = () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        const fresh = window.speechSynthesis.getVoices();
        if (active && fresh && fresh.length > 0) {
          setVoices(fresh);
          voicesRef.current = fresh;
        }
      }
    };

    loadVoicesSafely((availableVoices) => {
      if (active && availableVoices.length > 0) {
        setVoices(availableVoices);
        voicesRef.current = availableVoices;
      }
    });

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = refreshVoiceList;
    }

    return () => {
      active = false;
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.onvoiceschanged = null;
      }
    };
  }, []);

  // 2. Prepare Sentences & Start Playback on Mount or Text Change
  const setupSentencesAndPlay = useCallback((rawText: string) => {
    const effectId = ++effectIdRef.current;
    setErrorMessage(null);

    // Detect language of text, prioritizing explicit hint and Devanagari Hindi
    const savedUserMode = localStorage.getItem('reader_voice_mode') as VoiceMode;
    const userHasChosen = localStorage.getItem('reader_voice_user_chosen') === 'true';
    const detected = detectLanguage(rawText, languageHint);
    const hasDevanagari = /[\u0900-\u097F]/.test(rawText);
    const hasUrduScript = /[\u0600-\u06FF]/.test(rawText);

    let initialMode: VoiceMode = 'hi-IN';
    if (hasDevanagari || languageHint === 'hindi' || detected === 'hindi') {
      initialMode = 'hi-IN';
    } else if (hasUrduScript || languageHint === 'urdu' || detected === 'urdu') {
      initialMode = 'ur-PK';
    } else if (languageHint === 'hinglish' || detected === 'hinglish') {
      initialMode = 'hinglish';
    } else if (languageHint === 'english') {
      initialMode = 'en-US';
    } else if (userHasChosen && savedUserMode) {
      initialMode = savedUserMode;
    } else {
      const savedEnMode = localStorage.getItem('reader_english_voice_mode') as VoiceMode;
      initialMode = savedEnMode === 'en-GB' ? 'en-GB' : 'hi-IN';
    }

    setVoiceMode(initialMode);
    voiceModeRef.current = initialMode;

    const pageTransKey = `reader_page_trans_${currentPage}`;
    const cachedPageTrans = typeof window !== 'undefined' ? localStorage.getItem(pageTransKey) : null;
    let textToSynthesize = rawText;

    if (initialMode === 'hi-IN' && !/[\u0900-\u097F]/.test(rawText)) {
      if (cachedPageTrans && /[\u0900-\u097F]/.test(cachedPageTrans)) {
        textToSynthesize = cachedPageTrans;
      } else {
        // Asynchronously fetch full page translation so subsequent sentences and playback have full page translated
        fetch('/api/translate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: rawText, targetLang: 'hi' })
        })
          .then(res => res.json())
          .then(data => {
            if (data?.translatedText && /[\u0900-\u097F]/.test(data.translatedText)) {
              localStorage.setItem(pageTransKey, data.translatedText);
              if (effectId === effectIdRef.current && voiceModeRef.current === 'hi-IN') {
                const newSentences = splitTextIntoSentences(data.translatedText);
                sentencesRef.current = newSentences;
              }
            }
          })
          .catch(() => {});
      }
    }

    const parsedSentences = splitTextIntoSentences(textToSynthesize);
    sentencesRef.current = parsedSentences;
    setSentenceIndex(0);
    sentenceIndexRef.current = 0;
    setIsPlaying(true);
    isPlayingRef.current = true;
    setIsPaused(false);
    isPausedRef.current = false;

    // Trigger playback immediately
    executeSentenceSpeech(0, parsedSentences);
  }, [currentPage, languageHint]);

  useEffect(() => {
    let rawText = customText && customText.trim().length > 0 ? customText.trim() : (pageText || '').trim();
    const isNewPage = currentPage !== prevPageRef.current;

    // If pageText is temporarily empty on page change, attempt direct textContent extraction from pdfDoc
    if (!rawText && pdfDoc && !customText) {
      setSpokenSentenceDisplay(`Page ${currentPage}: Reading text...`);
      setIsAudioLoading(true);
      pdfDoc.getPage(currentPage).then((p: any) => p.getTextContent()).then((tc: any) => {
        if (tc && tc.items) {
          const directText = tc.items.map((i: any) => i.str || '').filter(Boolean).join(' ').trim();
          if (directText) {
            prevTextRef.current = directText;
            prevPageRef.current = currentPage;
            setupSentencesAndPlay(directText);
          }
        }
      }).catch(() => {});
      return;
    }

    // Prevent redundant speech restart if the text, page, and language hint haven't actually changed
    if (!isNewPage && rawText === prevTextRef.current && languageHint === prevHintRef.current) {
      return;
    }
    prevTextRef.current = rawText;
    prevPageRef.current = currentPage;
    prevHintRef.current = languageHint;

    if (!rawText || rawText.length === 0) {
      setSpokenSentenceDisplay(`Page ${currentPage} text loading...`);
      return;
    }

    setupSentencesAndPlay(rawText);
  }, [pageText, customText, currentPage, languageHint, pdfDoc, setupSentencesAndPlay]);

  // Chromium keep-alive interval: Prevents speech synthesis from pausing silently after 14 seconds
  useEffect(() => {
    const keepAliveTimer = setInterval(() => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        if (isPlayingRef.current && !isPausedRef.current) {
          if (window.speechSynthesis.paused) {
            try {
              window.speechSynthesis.resume();
            } catch (e) {}
          }
        }
      }
    }, 6000);
    return () => clearInterval(keepAliveTimer);
  }, []);

  // Stop all active audio elements and browser speech synthesis cleanly
  const stopAllAudio = () => {
    activeSpeechIdRef.current++;
    if (abortControllerRef.current) {
      try {
        abortControllerRef.current.abort();
      } catch (e) {}
      abortControllerRef.current = null;
    }
    if (currentAudioRef.current) {
      try {
        currentAudioRef.current.pause();
        currentAudioRef.current.onended = null;
        currentAudioRef.current.onerror = null;
        currentAudioRef.current.src = '';
      } catch (e) {}
      currentAudioRef.current = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (e) {}
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopAllAudio();
    };
  }, []);

  // Pre-fetch next sentence in background to guarantee instant seamless playback
  const prefetchNextSentence = (nextIndex: number, list: string[], mode: string, voice: string) => {
    if (nextIndex >= list.length) return;
    const txt = list[nextIndex];
    if (!txt || txt.trim().length === 0) return;
    const cacheKey = `${mode}::${voice}::${txt}`;
    if (audioCacheRef.current.has(cacheKey)) return;

    fetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: txt,
        lang: mode,
        voice: voice,
        rate: rateRef.current
      })
    })
      .then(res => res.json())
      .then(data => {
        if (data && data.audioBase64) {
          audioCacheRef.current.set(cacheKey, data);
        }
      })
      .catch(() => {});
  };

  // Play Neural Audio from base64 buffer
  const playNeuralAudio = async (
    data: { audioBase64: string; format?: string; translatedText?: string },
    speechId: number,
    activeIndex: number,
    currentSentences: string[],
    activeVoiceParam: string,
    sentenceToSpeak: string
  ) => {
    setIsAudioLoading(false);
    if (speechId !== activeSpeechIdRef.current || !isPlayingRef.current || isPausedRef.current) return;

    const displayTxt = data.translatedText || sentenceToSpeak;
    if (data.translatedText) {
      setSpokenSentenceDisplay(data.translatedText);
      if (onCurrentSentenceChangeRef.current) {
        onCurrentSentenceChangeRef.current(data.translatedText);
      }
    }

    const audio = sharedAudioRef.current || new Audio();
    sharedAudioRef.current = audio;
    audio.src = `data:${data.format || 'audio/mp3'};base64,${data.audioBase64}`;
    audio.playbackRate = rateRef.current;
    currentAudioRef.current = audio;

    audio.onended = () => {
      if (speechId !== activeSpeechIdRef.current) return;
      currentAudioRef.current = null;
      if (!isPlayingRef.current || isPausedRef.current) return;
      advanceToNext(activeIndex, currentSentences);
    };

    audio.onerror = (e) => {
      if (speechId !== activeSpeechIdRef.current) return;
      console.warn('[TTS] Audio element error, using Web Speech:', e);
      currentAudioRef.current = null;
      speakViaWebSpeech(displayTxt, activeIndex, currentSentences, speechId);
    };

    try {
      await audio.play();
      if (speechId !== activeSpeechIdRef.current) return;
      setErrorMessage(null);
      setFallbackNotice(null);

      // Pre-fetch next 2 sentences in background to guarantee instant seamless playback
      if (activeIndex + 1 < currentSentences.length) {
        prefetchNextSentence(activeIndex + 1, currentSentences, voiceModeRef.current, activeVoiceParam);
        if (activeIndex + 2 < currentSentences.length) {
          prefetchNextSentence(activeIndex + 2, currentSentences, voiceModeRef.current, activeVoiceParam);
        }
      }
    } catch (playErr: any) {
      if (speechId !== activeSpeechIdRef.current) return;
      if (playErr?.name === 'AbortError') return; // User skipped sentence, cancel cleanly
      console.warn('[TTS] audio.play() blocked, trying Web Speech:', playErr);
      speakViaWebSpeech(displayTxt, activeIndex, currentSentences, speechId);
    }
  };

  // 4. Sentence Speech Execution
  const executeSentenceSpeech = async (index: number, list = sentencesRef.current) => {
    stopAllAudio();
    const speechId = ++activeSpeechIdRef.current;
    if (abortControllerRef.current) {
      try { abortControllerRef.current.abort(); } catch (e) {}
    }
    const abortController = new AbortController();
    abortControllerRef.current = abortController;

    if (index >= list.length) {
      // Finished all sentences on this page -> automatically jump to next page!
      if (autoAdvanceRef.current && currentPage < totalPages) {
        const nextPage = currentPage + 1;
        setSpokenSentenceDisplay(`Page ${currentPage} completed. Advancing to Page ${nextPage}...`);
        setIsPlaying(true);
        isPlayingRef.current = true;
        setTimeout(() => {
          if (isPlayingRef.current && speechId === activeSpeechIdRef.current) {
            onPageChangeRef.current(nextPage);
          }
        }, 350);
      } else {
        setIsPlaying(false);
        isPlayingRef.current = false;
        if (onCurrentSentenceChangeRef.current) onCurrentSentenceChangeRef.current('');
      }
      return;
    }

    const sentenceToSpeak = list[index];
    if (!sentenceToSpeak || sentenceToSpeak.trim().length === 0) {
      advanceToNext(index, list);
      return;
    }

    if (onCurrentSentenceChangeRef.current) {
      onCurrentSentenceChangeRef.current(sentenceToSpeak);
    }
    setSpokenSentenceDisplay(sentenceToSpeak);

    const hasDevanagariText = /[\u0900-\u097F]/.test(sentenceToSpeak);
    const hasUrduText = /[\u0600-\u06FF]/.test(sentenceToSpeak);
    const currentMode = hasDevanagariText ? 'hi-IN' : (hasUrduText ? 'ur-PK' : voiceModeRef.current);
    const activeVoiceParam = hasDevanagariText
      ? 'hi-IN-MadhurNeural'
      : (hasUrduText ? 'ur-PK-AsadNeural' : (selectedVoiceURIRef.current || (
          currentMode === 'hi-IN' ? 'hi-IN-MadhurNeural' :
          currentMode === 'ur-PK' ? 'ur-PK-AsadNeural' :
          currentMode === 'hinglish' ? 'en-IN-PrabhatNeural' :
          'en-US-GuyNeural'
        )));

    setErrorMessage(null);
    setIsAudioLoading(true);

    const activeIndex = index;
    const currentSentences = list;

    // Check pre-fetched in-memory cache first for instant playback
    const cacheKey = `${currentMode}::${activeVoiceParam}::${sentenceToSpeak}`;
    const cachedItem = audioCacheRef.current.get(cacheKey);

    if (cachedItem && cachedItem.audioBase64) {
      playNeuralAudio(cachedItem, speechId, activeIndex, currentSentences, activeVoiceParam, sentenceToSpeak);
      return;
    }

    // 1. Request realistic Male Neural voice audio from /api/tts
    const fetchTimer = setTimeout(() => {
      try { abortController.abort(); } catch (e) {}
    }, 5500);

    try {
      const resp = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: abortController.signal,
        body: JSON.stringify({
          text: sentenceToSpeak,
          lang: currentMode,
          voice: activeVoiceParam,
          rate: rateRef.current
        })
      });
      clearTimeout(fetchTimer);

      if (speechId !== activeSpeechIdRef.current) return;

      if (resp.ok) {
        const data = await resp.json();
        if (speechId !== activeSpeechIdRef.current) return;

        if (data.audioBase64) {
          audioCacheRef.current.set(cacheKey, data);
          playNeuralAudio(data, speechId, activeIndex, currentSentences, activeVoiceParam, sentenceToSpeak);
          return;
        }

        if (data.fallbackToWebSpeech) {
          setIsAudioLoading(false);
          if (!isPlayingRef.current || isPausedRef.current) return;
          speakViaWebSpeech(data.translatedText || sentenceToSpeak, activeIndex, currentSentences, speechId);
          return;
        }
      }
    } catch (e: any) {
      clearTimeout(fetchTimer);
      // Only abort cleanly if a newer speechId took over (user clicked next/prev/stop)
      if (speechId !== activeSpeechIdRef.current) return;
      console.warn('[TTS] /api/tts fetch issue, speaking via Web Speech fallback:', e);
    }

    setIsAudioLoading(false);
    if (speechId !== activeSpeechIdRef.current || !isPlayingRef.current || isPausedRef.current) return;
    speakViaWebSpeech(sentenceToSpeak, activeIndex, currentSentences, speechId);
  };

  const speakViaWebSpeech = (sentenceToSpeak: string, index: number, list: string[], speechId = activeSpeechIdRef.current) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      setErrorMessage("Speech is not supported in this browser.");
      return;
    }

    if (speechId !== activeSpeechIdRef.current) return;

    const currentMode = voiceModeRef.current;
    let allAvailVoices = (typeof window !== 'undefined' && 'speechSynthesis' in window && window.speechSynthesis.getVoices().length > 0)
      ? window.speechSynthesis.getVoices()
      : (voicesRef.current.length > 0 ? voicesRef.current : (voices.length > 0 ? voices : []));

    if (allAvailVoices.length === 0 && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      allAvailVoices = window.speechSynthesis.getVoices() || [];
    }

    const voiceSelection = selectVoiceForPlayback(
      allAvailVoices, 
      currentMode, 
      selectedVoiceURIRef.current
    );

    if (voiceSelection.notice) {
      setFallbackNotice(voiceSelection.notice);
    } else {
      setFallbackNotice(null);
    }

    const maleOnlyVoices = allAvailVoices.filter(v => !isExplicitlyFemale(v.name));
    let activeVoice = voiceSelection.voice || (maleOnlyVoices.length > 0 ? maleOnlyVoices[0] : (allAvailVoices[0] || null));
    let voiceLang = (activeVoice?.lang || '').toLowerCase().replace('_', '-');
    let isVoiceNativeHindi = (voiceLang.startsWith('hi') || (activeVoice?.name || '').toLowerCase().includes('hindi') || (activeVoice?.name || '').toLowerCase().includes('हिन्दी')) && !isExplicitlyFemale(activeVoice?.name || '');
    const hasVoiceFailed = activeVoice && failedVoicesRef.current.has(activeVoice.voiceURI || activeVoice.name);

    let textToUtter = sentenceToSpeak;
    let targetLang = activeVoice?.lang || 'en-US';

    const hasDevanagari = /[\u0900-\u097F]/.test(sentenceToSpeak);
    const hasUrduArabic = /[\u0600-\u06FF]/.test(sentenceToSpeak);

    if (currentMode === 'hi-IN') {
      if (hasDevanagari) {
        if (isVoiceNativeHindi && !hasVoiceFailed) {
          textToUtter = sentenceToSpeak;
          targetLang = activeVoice?.lang || 'hi-IN';
        } else {
          // Device lacks working native Hindi voice: Convert Devanagari to Roman phonetics so device's standard voice speaks it audibly!
          textToUtter = transliterateDevanagariToRoman(sentenceToSpeak);
          const reliableVoice = allAvailVoices.find(v => {
            const l = (v.lang || '').toLowerCase().replace('_', '-');
            const n = (v.name || '').toLowerCase();
            return !failedVoicesRef.current.has(v.name) && !isExplicitlyFemale(v.name) && (l.startsWith('en-in') || n.includes('ravi') || n.includes('prabhat'));
          }) || allAvailVoices.find(v => !failedVoicesRef.current.has(v.name) && !isExplicitlyFemale(v.name) && (v.lang || '').toLowerCase().startsWith('en')) || allAvailVoices.find(v => !isExplicitlyFemale(v.name)) || allAvailVoices[0] || null;

          if (reliableVoice) {
            activeVoice = reliableVoice;
            targetLang = reliableVoice.lang || 'en-IN';
          } else {
            targetLang = 'en-US';
          }
        }
      } else {
        // Text is in Latin alphabet (Roman Hindi or English)
        const hasRomanHindiWords = /\b(yeh|woh|hai|hain|tha|thi|the|ka|ki|ke|ko|mein|se|par|aur|kya|kyun|kaise|kaha|apka|mera|hum|aap|tum|karein|karna|hona|nahi|bhi|achha|kuch|sab)\b/i.test(sentenceToSpeak);
        if (isVoiceNativeHindi && !hasVoiceFailed && hasRomanHindiWords) {
          textToUtter = transliterateRomanHindiToDevanagari(sentenceToSpeak);
          targetLang = activeVoice?.lang || 'hi-IN';
        } else {
          textToUtter = sentenceToSpeak;
          if (isVoiceNativeHindi) {
            const englishVoice = allAvailVoices.find(v => {
              const l = (v.lang || '').toLowerCase().replace('_', '-');
              return !failedVoicesRef.current.has(v.name) && !isExplicitlyFemale(v.name) && (l.startsWith('en-in') || l.startsWith('en-us'));
            }) || null;
            if (englishVoice) {
              activeVoice = englishVoice;
              targetLang = englishVoice.lang || 'en-IN';
            } else {
              targetLang = 'en-US';
            }
          } else {
            targetLang = activeVoice?.lang || 'en-IN';
          }
        }
      }
    } else if (currentMode === 'ur-PK') {
      if (hasUrduArabic) {
        textToUtter = sentenceToSpeak;
        targetLang = activeVoice?.lang || 'ur-IN';
      } else {
        textToUtter = sentenceToSpeak;
        targetLang = activeVoice?.lang || 'en-US';
      }
    } else if (currentMode === 'hinglish') {
      if (hasDevanagari) {
        textToUtter = transliterateDevanagariToRoman(sentenceToSpeak);
      } else {
        textToUtter = sentenceToSpeak;
      }
      targetLang = activeVoice?.lang || 'en-IN';
    } else {
      textToUtter = sentenceToSpeak;
      targetLang = activeVoice?.lang || (currentMode === 'en-GB' ? 'en-GB' : 'en-US');
    }

    setErrorMessage(null);

    const utterance = new SpeechSynthesisUtterance(textToUtter);
    utterance.rate = rateRef.current;
    // Lower formant pitch if fallback voice is female to ensure rich masculine tone
    utterance.pitch = isExplicitlyFemale(activeVoice?.name || '') ? 0.72 : 0.88;
    utterance.lang = targetLang;

    // Explicitly assign active voice whenever available
    if (activeVoice) {
      try { utterance.voice = activeVoice; } catch (e) {}
    }

    if (typeof window !== 'undefined') {
      if (!(window as any).__ttsActiveUtterances) {
        (window as any).__ttsActiveUtterances = new Set();
      }
      (window as any).__ttsActiveUtterances.add(utterance);
    }

    let started = false;
    let watchdogTimer: any = null;

    const playSafeFallbackSpeech = () => {
      try {
        if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
          window.speechSynthesis.cancel();
        }
        const safeFallbackText = /[\u0900-\u097F]/.test(sentenceToSpeak) 
          ? transliterateDevanagariToRoman(sentenceToSpeak) 
          : sentenceToSpeak;

        const fallbackUtterance = new SpeechSynthesisUtterance(safeFallbackText);
        fallbackUtterance.rate = rateRef.current;
        fallbackUtterance.pitch = 0.85;

        const reliableVoice = allAvailVoices.find(v => {
          const l = (v.lang || '').toLowerCase().replace('_', '-');
          const n = (v.name || '').toLowerCase();
          return !failedVoicesRef.current.has(v.name) && !isExplicitlyFemale(v.name) && (l.startsWith('en-in') || l.startsWith('en-us') || n.includes('david') || n.includes('guy')) && v.name !== activeVoice?.name;
        }) || allAvailVoices.find(v => !failedVoicesRef.current.has(v.name) && !isExplicitlyFemale(v.name) && (v.lang || '').toLowerCase().startsWith('en')) || allAvailVoices.find(v => !isExplicitlyFemale(v.name)) || allAvailVoices[0] || null;

        if (reliableVoice) {
          try { fallbackUtterance.voice = reliableVoice; } catch (vErr) {}
          fallbackUtterance.lang = reliableVoice.lang || 'en-IN';
        } else {
          fallbackUtterance.lang = 'en-US';
        }

        if (typeof window !== 'undefined' && (window as any).__ttsActiveUtterances) {
          (window as any).__ttsActiveUtterances.add(fallbackUtterance);
        }
        fallbackUtterance.onstart = () => {
          if (speechId !== activeSpeechIdRef.current) return;
          setIsPlaying(true);
          isPlayingRef.current = true;
          setIsPaused(false);
          isPausedRef.current = false;
        };
        fallbackUtterance.onend = () => {
          retryRef.current = false;
          if (typeof window !== 'undefined' && (window as any).__ttsActiveUtterances) {
            (window as any).__ttsActiveUtterances.delete(fallbackUtterance);
          }
          if (speechId !== activeSpeechIdRef.current || !isPlayingRef.current || isPausedRef.current) return;
          advanceToNext(index, list);
        };
        fallbackUtterance.onerror = (fallbackErr: any) => {
          retryRef.current = false;
          if (typeof window !== 'undefined' && (window as any).__ttsActiveUtterances) {
            (window as any).__ttsActiveUtterances.delete(fallbackUtterance);
          }
          if (speechId !== activeSpeechIdRef.current) return;
          if (!fallbackErr || fallbackErr.error === 'canceled' || fallbackErr.error === 'interrupted') return;
          setIsPlaying(false);
          isPlayingRef.current = false;
        };

        setTimeout(() => {
          if (speechId !== activeSpeechIdRef.current) return;
          if (window.speechSynthesis.paused) window.speechSynthesis.resume();
          window.speechSynthesis.speak(fallbackUtterance);
        }, 50);
      } catch (retryEx) {
        console.warn('[TTS] Fallback error:', retryEx);
      }
    };

    if (isVoiceNativeHindi && hasDevanagari && !hasVoiceFailed) {
      watchdogTimer = setTimeout(() => {
        if (speechId !== activeSpeechIdRef.current) return;
        if (!started && isPlayingRef.current && !isPausedRef.current) {
          if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
            if (window.speechSynthesis.paused) {
              window.speechSynthesis.resume();
            }
            if (!started && !retryRef.current) {
              if (activeVoice) {
                failedVoicesRef.current.add(activeVoice.voiceURI || activeVoice.name);
              }
              retryRef.current = true;
              playSafeFallbackSpeech();
            }
          }
        }
      }, 950);
    }

    utterance.onstart = () => {
      started = true;
      if (watchdogTimer) clearTimeout(watchdogTimer);
      if (speechId !== activeSpeechIdRef.current) return;
      setIsPlaying(true);
      isPlayingRef.current = true;
      setIsPaused(false);
      isPausedRef.current = false;
    };

    utterance.onend = () => {
      if (watchdogTimer) clearTimeout(watchdogTimer);
      retryRef.current = false;
      if (typeof window !== 'undefined' && (window as any).__ttsActiveUtterances) {
        (window as any).__ttsActiveUtterances.delete(utterance);
      }
      if (speechId !== activeSpeechIdRef.current || !isPlayingRef.current || isPausedRef.current) return;
      advanceToNext(index, list);
    };

    utterance.onerror = (e: any) => {
      if (watchdogTimer) clearTimeout(watchdogTimer);
      if (typeof window !== 'undefined' && (window as any).__ttsActiveUtterances) {
        (window as any).__ttsActiveUtterances.delete(utterance);
      }
      if (speechId !== activeSpeechIdRef.current) return;
      if (!e || e.error === 'canceled' || e.error === 'interrupted') return;

      if (activeVoice) {
        failedVoicesRef.current.add(activeVoice.voiceURI || activeVoice.name);
      }

      if (!retryRef.current) {
        retryRef.current = true;
        playSafeFallbackSpeech();
        return;
      }

      retryRef.current = false;
      setIsPlaying(false);
      isPlayingRef.current = false;
    };

    try {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
      window.speechSynthesis.speak(utterance);
    } catch (err: any) {
      if (speechId !== activeSpeechIdRef.current) return;
      console.warn('[TTS] speak exception:', err);
      advanceToNext(index, list);
    }
  };

  const advanceToNext = (currentIndex: number, list: string[]) => {
    const nextIndex = currentIndex + 1;
    if (nextIndex < list.length) {
      setSentenceIndex(nextIndex);
      sentenceIndexRef.current = nextIndex;
      setTimeout(() => {
        if (isPlayingRef.current && !isPausedRef.current) {
          executeSentenceSpeech(nextIndex, list);
        }
      }, 100);
    } else {
      // Reached the end of the page! Seamlessly advance to the next page and continue speaking!
      if (autoAdvanceRef.current && currentPage < totalPages) {
        const nextPage = currentPage + 1;
        setSpokenSentenceDisplay(`Page ${currentPage} completed. Advancing to Page ${nextPage}...`);
        setIsPlaying(true);
        isPlayingRef.current = true;
        setTimeout(() => {
          if (isPlayingRef.current) {
            onPageChangeRef.current(nextPage);
          }
        }, 350);
      } else {
        setIsPlaying(false);
        isPlayingRef.current = false;
        if (onCurrentSentenceChangeRef.current) onCurrentSentenceChangeRef.current('');
      }
    }
  };

  // 5. Playback Controls
  const handlePlay = () => {
    console.log('[TTS] button clicked: Play/Resume');
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    unlockSpeechAudio();
    setErrorMessage(null);
    setIsPlaying(true);
    isPlayingRef.current = true;
    setIsPaused(false);
    isPausedRef.current = false;

    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    }
    
    if (sentencesRef.current.length > 0) {
      executeSentenceSpeech(sentenceIndexRef.current);
    } else {
      const rawText = customText && customText.trim().length > 0 ? customText.trim() : (pageText || '').trim();
      if (rawText) {
        const parsed = splitTextIntoSentences(rawText);
        sentencesRef.current = parsed;
        executeSentenceSpeech(0, parsed);
      }
    }
  };

  const handlePause = () => {
    console.log('[TTS] button clicked: Pause');
    setIsPaused(true);
    isPausedRef.current = true;
    setIsPlaying(false);
    isPlayingRef.current = false;

    if (currentAudioRef.current) {
      try {
        currentAudioRef.current.pause();
      } catch (e) {}
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.pause();
      } catch (e) {
        window.speechSynthesis.cancel();
      }
    }
  };

  const handleStop = () => {
    console.log('[TTS] button clicked: Stop');
    stopAllAudio();
    setIsPlaying(false);
    isPlayingRef.current = false;
    setIsPaused(false);
    isPausedRef.current = false;
    if (onCurrentSentenceChangeRef.current) onCurrentSentenceChangeRef.current('');
    onClose();
  };

  const handleNext = () => {
    stopAllAudio();
    setIsPlaying(true);
    isPlayingRef.current = true;
    setIsPaused(false);
    isPausedRef.current = false;

    if (sentenceIndex < sentencesRef.current.length - 1) {
      const n = sentenceIndex + 1;
      setSentenceIndex(n);
      sentenceIndexRef.current = n;
      executeSentenceSpeech(n);
      if (n + 1 < sentencesRef.current.length) {
        const currentMode = voiceModeRef.current;
        const activeVoiceParam = selectedVoiceURIRef.current || (
          currentMode === 'hi-IN' ? 'hi-IN-MadhurNeural' :
          currentMode === 'ur-PK' ? 'ur-PK-AsadNeural' :
          currentMode === 'hinglish' ? 'en-IN-PrabhatNeural' :
          'en-US-GuyNeural'
        );
        prefetchNextSentence(n + 1, sentencesRef.current, currentMode, activeVoiceParam);
      }
    } else if (!customText && currentPage < totalPages) {
      const nextPage = currentPage + 1;
      setSpokenSentenceDisplay(`Page ${currentPage} completed. Advancing to Page ${nextPage}...`);
      setIsPlaying(true);
      isPlayingRef.current = true;
      onPageChange(nextPage);
    }
  };

  const handlePrev = () => {
    stopAllAudio();
    setIsPlaying(true);
    isPlayingRef.current = true;
    setIsPaused(false);
    isPausedRef.current = false;

    if (sentenceIndex > 0) {
      const p = sentenceIndex - 1;
      setSentenceIndex(p);
      sentenceIndexRef.current = p;
      executeSentenceSpeech(p);
    } else if (!customText && currentPage > 1) {
      const prevPage = currentPage - 1;
      setSpokenSentenceDisplay(`Moving to Page ${prevPage}...`);
      setIsPlaying(true);
      isPlayingRef.current = true;
      onPageChange(prevPage);
    }
  };

  // Supported playback speeds: 0.5x, 0.75x, 1x, 1.25x, 1.5x, 2x, 2.5x, 3x
  const speedOptions = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0];
  const cycleSpeed = () => {
    const nextSpeed = speedOptions[(speedOptions.indexOf(rate) + 1) % speedOptions.length];
    setRate(nextSpeed);
    rateRef.current = nextSpeed;
    localStorage.setItem('reader_speak_rate', String(nextSpeed));
    if (currentAudioRef.current) {
      currentAudioRef.current.playbackRate = nextSpeed;
    }
    if (isPlaying && !currentAudioRef.current) {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      executeSentenceSpeech(sentenceIndex);
    }
  };

  const currentSentence = sentencesRef.current[sentenceIndex] || '';

  // Minimized Compact Audio Pill View (Leaves full page readable on mobile & desktop)
  if (isMinimized) {
    return (
      <div 
        id="speak-mode-player-minimized"
        className={`fixed ${showControls ? 'bottom-16 sm:bottom-20' : 'bottom-3 sm:bottom-5'} left-2 right-2 sm:left-auto sm:right-6 sm:w-[420px] z-50 rounded-full px-3 py-2 shadow-2xl border-2 transition-all duration-200 ${
          isDark 
            ? 'border-orange-500/40 text-white shadow-black/80' 
            : (isSepia ? 'border-[#D4C3A3] text-[#5B4636] shadow-amber-950/20' : 'border-orange-300 text-slate-900 shadow-slate-900/30')
        }`}
        style={{
          backgroundColor: isDark ? '#18181b' : (isSepia ? '#FAF3E0' : '#ffffff'),
          opacity: 1,
        }}
      >
        <div className="flex items-center justify-between gap-2">
          {/* Left: Play/Pause button + Current snippet */}
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <button
              onClick={isPlaying && !isPaused ? handlePause : handlePlay}
              className={`h-9 w-9 rounded-full flex items-center justify-center shrink-0 shadow-md cursor-pointer active:scale-95 transition-all text-white border-2 ${
                isAudioLoading
                  ? 'bg-amber-600 border-amber-400 shadow-amber-600/30'
                  : isPlaying && !isPaused
                  ? 'bg-orange-600 border-orange-400/80 shadow-orange-600/30 hover:bg-orange-700'
                  : 'bg-emerald-600 border-emerald-400/80 shadow-emerald-600/30 hover:bg-emerald-700'
              }`}
              title={isAudioLoading ? 'Loading speech (Taiyaar ho raha hai...)' : isPlaying && !isPaused ? 'Pause (Rukiye)' : 'Play (Suniye)'}
              aria-label={isAudioLoading ? 'Loading audio' : isPlaying && !isPaused ? 'Pause Speech' : 'Play Speech'}
            >
              {isAudioLoading ? (
                <Loader2 className="h-4.5 w-4.5 text-white" strokeWidth={2.5} />
              ) : isPlaying && !isPaused ? (
                <Pause className="h-4.5 w-4.5 fill-white text-white" strokeWidth={2.5} />
              ) : (
                <Play className="h-4.5 w-4.5 fill-white text-white ml-0.5" strokeWidth={2.5} />
              )}
            </button>

            <div className="flex items-center gap-1.5 min-w-0 flex-1">
              <span className="text-[9.5px] font-bold px-1.5 py-0.5 rounded bg-orange-500/15 text-orange-600 dark:text-orange-400 shrink-0 border border-orange-500/20">
                {voiceMode === 'hinglish' ? 'Hinglish' : voiceMode === 'hi-IN' ? '🇮🇳 Hindi' : voiceMode === 'ur-PK' ? '🇮🇳 Urdu' : voiceMode === 'en-GB' ? '🇬🇧 UK' : '🇺🇸 US'}
              </span>
              <p className="text-xs truncate italic text-slate-700 dark:text-slate-300">
                "{spokenSentenceDisplay || currentSentence || 'Preparing speech...'}"
              </p>
            </div>
          </div>

          {/* Right: Speed + Expand + Close */}
          <div className="flex items-center gap-1 shrink-0">
            <button
              onClick={cycleSpeed}
              className="px-2 py-0.5 rounded-lg border border-black/10 dark:border-white/10 text-[10px] font-mono font-bold hover:bg-orange-500/10 hover:text-orange-600 transition-colors cursor-pointer"
              title="Reading speed"
            >
              {rate}x
            </button>

            <button
              onClick={() => setIsMinimized(false)}
              className="p-1.5 rounded-full hover:bg-black/5 dark:hover:bg-white/10 text-slate-700 dark:text-slate-200 hover:text-orange-600 transition-colors cursor-pointer"
              title="Expand player"
            >
              <Maximize2 className="h-4 w-4" strokeWidth={2.2} />
            </button>

            <button
              onClick={handleStop}
              className="p-1.5 rounded-full hover:bg-rose-500/10 text-slate-700 dark:text-slate-200 hover:text-rose-600 transition-colors cursor-pointer"
              title="Stop & Close"
            >
              <X className="h-4 w-4" strokeWidth={2.2} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Expanded View
  return (
    <div 
      id="speak-mode-player"
      className={`fixed ${showControls ? 'bottom-16 sm:bottom-20' : 'bottom-3 sm:bottom-5'} left-2 right-2 sm:left-auto sm:right-6 sm:w-[440px] z-50 rounded-2xl p-3 sm:p-4 shadow-2xl border-2 transition-all duration-200 ${
        isDark 
          ? 'border-orange-500/40 text-white shadow-black/90' 
          : (isSepia ? 'border-[#D4C3A3] text-[#5B4636] shadow-amber-950/20' : 'border-orange-200 text-slate-900 shadow-slate-900/25')
      }`}
      style={{
        backgroundColor: isDark ? '#18181b' : (isSepia ? '#FAF3E0' : '#ffffff'),
        opacity: 1,
      }}
    >
      {/* Top Header */}
      <div className="flex items-center justify-between gap-2 pb-2 mb-2 border-b border-black/5 dark:border-white/10">
        <div className="flex items-center gap-2 min-w-0">
          <div className="h-6 w-6 rounded-full bg-orange-600 text-white flex items-center justify-center shrink-0 shadow-xs">
            <Volume2 className="h-3.5 w-3.5" />
          </div>
          
          <div className="flex items-center gap-1.5 truncate">
            <span className="text-xs font-bold text-orange-600 dark:text-orange-400 truncate">
              {customText ? 'Speaking Selection' : `Reading Aloud • Pg ${currentPage}/${totalPages}`}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              ({sentenceIndex + 1}/{sentencesRef.current.length || 1})
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1">
          {/* Active Voice Mode Badge */}
          <button
            onClick={() => setShowVoiceSettings(!showVoiceSettings)}
            className="flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-orange-500/10 text-orange-600 dark:text-orange-400 hover:bg-orange-500/20 transition-colors cursor-pointer border border-orange-500/20"
            title="Click to change Voice & Language Settings"
          >
            <span>{voiceMode === 'hinglish' ? 'Hinglish' : voiceMode === 'hi-IN' ? 'Hindi' : voiceMode === 'ur-PK' ? 'Urdu' : voiceMode === 'en-GB' ? 'UK English' : 'US English'}</span>
            <Mic className="h-3 w-3" />
          </button>

          {!customText && (
            <button
              onClick={() => {
                setAutoAdvance(prev => {
                  const nextVal = !prev;
                  autoAdvanceRef.current = nextVal;
                  localStorage.setItem('reader_speak_auto_advance', String(nextVal));
                  return nextVal;
                });
              }}
              className={`hidden xs:inline-block px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider transition-colors cursor-pointer border ${
                autoAdvance 
                  ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-600 dark:text-emerald-400' 
                  : 'bg-slate-200/50 border-transparent text-slate-500'
              }`}
              title="Auto Advance to Next Page"
            >
              Next Pg: {autoAdvance ? 'ON' : 'OFF'}
            </button>
          )}

          {/* Minimize / Collapse Button */}
          <button
            onClick={() => setIsMinimized(true)}
            className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 text-slate-600 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            title="Minimize to Compact Bar"
          >
            <ChevronDown className="h-4 w-4" strokeWidth={2.2} />
          </button>
          
          {/* Stop / Close Button */}
          <button
            onClick={handleStop}
            className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 text-slate-600 dark:text-slate-200 hover:text-rose-600 dark:hover:text-rose-400 transition-colors cursor-pointer"
            title="Stop & Exit Speak Mode"
          >
            <Square className="h-4 w-4 fill-current" strokeWidth={2.2} />
          </button>
        </div>
      </div>

      {/* Visible Error Notification if Speech is Unsupported, Empty, or Failed */}
      {errorMessage && (
        <div className="flex items-center gap-1.5 text-[11px] font-medium text-rose-600 dark:text-rose-400 bg-rose-500/10 border border-rose-500/20 p-2 rounded-xl mb-2.5">
          <AlertCircle className="h-4 w-4 shrink-0" />
          <span className="flex-1">{errorMessage}</span>
          <button 
            onClick={() => setErrorMessage(null)} 
            className="p-1 hover:bg-rose-500/20 rounded cursor-pointer"
          >
            <X className="h-3 w-3" />
          </button>
        </div>
      )}

      {/* Voice Selection & Language Settings Panel */}
      {showVoiceSettings && (
        <div className="mb-3 p-3 rounded-xl border border-orange-500/25 bg-orange-500/5 text-xs space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Voice & Language Settings
            </span>
            <span className="text-[9px] text-slate-400">
              {voices.length} voices available
            </span>
          </div>

          {/* Language Mode Selector (Scrollable horizontally on mobile, clean wrapping) */}
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
            {[
              { id: 'en-US', label: '🇺🇸 US En' },
              { id: 'en-GB', label: '🇬🇧 UK En' },
              { id: 'hinglish', label: 'Hinglish' },
              { id: 'hi-IN', label: '🇮🇳 Hindi (हिंदी)' },
              { id: 'ur-PK', label: '🇮🇳 Urdu (اردو)' },
            ].map((m) => (
              <button
                key={m.id}
                onClick={() => {
                  const newMode = m.id as VoiceMode;
                  setVoiceMode(newMode);
                  voiceModeRef.current = newMode;
                  localStorage.setItem('reader_voice_mode', newMode);
                  localStorage.setItem('reader_voice_user_chosen', 'true');
                  if (newMode === 'en-US' || newMode === 'en-GB') {
                    localStorage.setItem('reader_english_voice_mode', newMode);
                  }
                  setSelectedVoiceURI('');
                  selectedVoiceURIRef.current = '';
                  localStorage.removeItem('reader_selected_voice_uri');
                  unlockSpeechAudio();
                  setErrorMessage(null);
                  setFallbackNotice(null);

                  // If user switched to Hindi and cached page translation exists, switch sentences
                  if (newMode === 'hi-IN') {
                    const pageTransKey = `reader_page_trans_${currentPage}`;
                    const cachedTrans = typeof window !== 'undefined' ? localStorage.getItem(pageTransKey) : null;
                    if (cachedTrans && /[\u0900-\u097F]/.test(cachedTrans)) {
                      const newHiSentences = splitTextIntoSentences(cachedTrans);
                      if (newHiSentences.length > 0) {
                        sentencesRef.current = newHiSentences;
                        setSentenceIndex(0);
                        sentenceIndexRef.current = 0;
                      }
                    }
                  } else if (!/[\u0900-\u097F]/.test(pageText || '')) {
                    // Restoring original English page sentences if switching away from Hindi
                    const rawBase = customText && customText.trim().length > 0 ? customText.trim() : (pageText || '').trim();
                    if (rawBase) {
                      const origSentences = splitTextIntoSentences(rawBase);
                      if (origSentences.length > 0) {
                        sentencesRef.current = origSentences;
                        setSentenceIndex(0);
                        sentenceIndexRef.current = 0;
                      }
                    }
                  }

                  setIsPlaying(true);
                  isPlayingRef.current = true;
                  setIsPaused(false);
                  isPausedRef.current = false;
                  executeSentenceSpeech(sentenceIndexRef.current);
                }}
                className={`py-1 px-2.5 rounded-lg text-center font-bold text-[10px] whitespace-nowrap transition-all cursor-pointer border shrink-0 ${
                  voiceMode === m.id
                    ? 'bg-orange-600 text-white border-orange-500 shadow-xs'
                    : 'bg-white/60 dark:bg-black/30 border-slate-200 dark:border-white/10 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>

          {/* Voice Selection Dropdown with Studio Male Voices */}
          <div className="space-y-1">
            <label className="text-[10px] font-semibold text-slate-600 dark:text-slate-300 block">
              Voice Character / Narrator:
            </label>
            <select
              value={selectedVoiceURI}
              onChange={(e) => {
                setSelectedVoiceURI(e.target.value);
                selectedVoiceURIRef.current = e.target.value;
                localStorage.setItem('reader_selected_voice_uri', e.target.value);
                localStorage.setItem('reader_voice_user_chosen', 'true');
                if (isPlaying) executeSentenceSpeech(sentenceIndex);
              }}
              className="w-full text-xs rounded-lg border p-1.5 bg-white dark:bg-black/50 text-slate-800 dark:text-white border-slate-200 dark:border-white/10 outline-hidden"
            >
              <option value="">🎙️ Auto AI Narrator Male (Madhur / Adam / David) [Default]</option>
              <optgroup label="✨ 100% Free Studio Voices (Male)">
                <option value="hi-IN-MadhurNeural">🇮🇳 Madhur (Hindi Male - Natural & Fluent)</option>
                <option value="en-US-Adam">🇺🇸 Adam (Warm & Deep Male Narrator - 100% Free)</option>
                <option value="en-US-David">🇺🇸 David (Clear Classic Male Narrator - 100% Free)</option>
                <option value="en-IN-PrabhatNeural">🇮🇳 Prabhat (Indian English Male)</option>
                <option value="en-US-GuyNeural">🇺🇸 Guy (English Male - Smooth Storyteller)</option>
                <option value="en-US-ChristopherNeural">🇺🇸 Christopher (Authoritative Male)</option>
                <option value="en-GB-RyanNeural">🇬🇧 Ryan (British English Male)</option>
                <option value="ur-PK-AsadNeural">🇵🇰 Asad (Urdu Male - Authentic)</option>
              </optgroup>
              {voices.length > 0 && (
                <optgroup label="🔊 Device Voices">
                  {voices.map(v => {
                    const l = (v.lang || '').toLowerCase();
                    const n = (v.name || '').toLowerCase();
                    const isHi = l.startsWith('hi') || n.includes('hindi') || n.includes('हिन्दी') || n.includes('lekha') || n.includes('kalpana') || n.includes('hemant');
                    const isUr = l.startsWith('ur') || n.includes('urdu') || n.includes('اردو') || n.includes('asad') || n.includes('uzma');
                    const tag = isHi ? ' [🇮🇳 Hindi]' : isUr ? ' [🇵🇰 Urdu]' : '';
                    const cleanName = cleanVoiceDisplayName(v.name);
                    return (
                      <option key={v.voiceURI} value={v.voiceURI}>
                        {cleanName} ({v.lang}){tag}
                      </option>
                    );
                  })}
                </optgroup>
              )}
            </select>
          </div>
        </div>
      )}

      {/* Current Spoken Sentence Preview */}
      <div className="px-3 py-2 rounded-xl bg-orange-500/10 dark:bg-white/5 border border-orange-500/20 mb-3 shadow-inner">
        <p className="text-xs font-semibold text-slate-900 dark:text-white line-clamp-2 leading-relaxed">
          "{spokenSentenceDisplay || currentSentence || 'Preparing speech...'}"
        </p>
      </div>

      {/* Controls row */}
      <div className="flex items-center justify-between gap-2 pt-1">
        {/* Speed button with exact required speeds: 0.5x, 0.75x, 1x, 1.25x, 1.5x, 2x, 2.5x, 3x */}
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={cycleSpeed}
            className="h-9 px-3 rounded-full border border-slate-300 dark:border-white/20 bg-slate-100 dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 font-mono font-bold text-xs flex items-center justify-center cursor-pointer shadow-2xs hover:bg-orange-500/10 hover:text-orange-600 transition-colors"
            title="Reading speed (0.5x, 0.75x, 1x, 1.25x, 1.5x, 2x, 2.5x, 3x)"
          >
            {rate}x
          </button>
        </div>

        {/* Center player buttons: Previous Sentence, Play/Pause, Next Sentence */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={handlePrev}
            disabled={sentenceIndex === 0 && currentPage <= 1}
            className="h-10 w-10 rounded-full bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-900 dark:text-zinc-100 disabled:opacity-25 flex items-center justify-center border-2 border-slate-300 dark:border-white/20 shadow-xs cursor-pointer active:scale-95 transition-all"
            title="Previous sentence (Pichla vakya)"
            aria-label="Previous sentence"
          >
            <SkipBack className="h-5 w-5" strokeWidth={2.4} />
          </button>

          {isAudioLoading ? (
            <button
              id="speak-player-loading-btn"
              onClick={() => {
                setIsAudioLoading(false);
                const s = sentencesRef.current[sentenceIndexRef.current] || '';
                if (s) speakViaWebSpeech(s, sentenceIndexRef.current, sentencesRef.current);
              }}
              className="h-14 w-14 rounded-full bg-amber-600 text-white hover:bg-amber-700 flex items-center justify-center shadow-xl shadow-amber-600/40 cursor-pointer active:scale-95 transition-all border-2 border-amber-400 ring-4 ring-amber-500/20"
              title="Generating voice - Click to speak immediately (Bol kar suniye)"
              aria-label="Generating voice"
            >
              <Loader2 className="h-7 w-7 text-white animate-spin" strokeWidth={2.6} />
            </button>
          ) : isPlaying && !isPaused ? (
            <button
              id="speak-player-pause-btn"
              onClick={handlePause}
              className="h-14 w-14 rounded-full bg-orange-600 text-white hover:bg-orange-700 flex items-center justify-center shadow-xl shadow-orange-600/40 cursor-pointer active:scale-95 transition-all border-2 border-orange-400 ring-4 ring-orange-500/20"
              title="Pause Speech (Rukiye)"
              aria-label="Pause Speech"
            >
              <Pause className="h-7 w-7 fill-white text-white" strokeWidth={2.6} />
            </button>
          ) : (
            <button
              id="speak-player-play-btn"
              onClick={handlePlay}
              className="h-14 w-14 rounded-full bg-emerald-600 text-white hover:bg-emerald-700 flex items-center justify-center shadow-xl shadow-emerald-600/40 cursor-pointer active:scale-95 transition-all border-2 border-emerald-400 ring-4 ring-emerald-500/20"
              title="Play / Resume Speech (Suniye)"
              aria-label="Play Speech"
            >
              <Play className="h-7 w-7 fill-white text-white ml-1" strokeWidth={2.6} />
            </button>
          )}

          <button
            onClick={handleNext}
            disabled={sentenceIndex >= sentencesRef.current.length - 1 && currentPage >= totalPages}
            className="h-10 w-10 rounded-full bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-900 dark:text-zinc-100 disabled:opacity-25 flex items-center justify-center border-2 border-slate-300 dark:border-white/20 shadow-xs cursor-pointer active:scale-95 transition-all"
            title="Next sentence (Agla vakya)"
            aria-label="Next sentence"
          >
            <SkipForward className="h-5 w-5" strokeWidth={2.4} />
          </button>
        </div>

        {/* Next page quick skip or Close button */}
        <div className="flex items-center gap-1 shrink-0">
          {!customText ? (
            <button
              onClick={() => {
                if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
                  window.speechSynthesis.cancel();
                }
                onPageChange(currentPage + 1);
              }}
              disabled={currentPage >= totalPages}
              className="h-9 px-3 rounded-full text-xs font-bold uppercase tracking-wider bg-orange-500/15 text-orange-600 dark:text-orange-400 hover:bg-orange-500/25 border border-orange-500/30 disabled:opacity-25 transition-all cursor-pointer flex items-center gap-1 shadow-2xs"
              title="Skip to next page"
            >
              <span>Next Pg</span>
              <FastForward className="h-3.5 w-3.5" strokeWidth={2.2} />
            </button>
          ) : (
            <button
              onClick={handleStop}
              className="h-9 px-3.5 rounded-full text-xs font-bold uppercase tracking-wider bg-slate-100 dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 hover:bg-rose-500/15 hover:text-rose-600 dark:hover:text-rose-400 border border-black/10 dark:border-white/10 transition-all cursor-pointer shadow-2xs flex items-center justify-center"
              title="Close"
            >
              <span>Close</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';

// Unified spring physics tokens for cohesive fluid motion across the app
export const springPhysics = {
  type: 'spring',
  stiffness: 380,
  damping: 32,
  mass: 0.65,
} as const;

export const springGentle = {
  type: 'spring',
  stiffness: 280,
  damping: 28,
  mass: 0.8,
} as const;

export const springSnappy = {
  type: 'spring',
  stiffness: 460,
  damping: 34,
  mass: 0.5,
} as const;

// View indexing to compute fluid directional slide physics
const VIEW_ORDER: Record<string, number> = {
  dashboard: 0,
  library: 1,
  stats: 2,
  feedback: 3,
  reader: 4,
};

interface PageTransitionManagerProps {
  viewKey: string;
  children: React.ReactNode;
  className?: string;
}

export default function PageTransitionManager({
  viewKey,
  children,
  className = '',
}: PageTransitionManagerProps) {
  const prevViewKeyRef = useRef(viewKey);
  const prevIndex = VIEW_ORDER[prevViewKeyRef.current] ?? 0;
  const currentIndex = VIEW_ORDER[viewKey] ?? 0;
  
  // Determine slide direction (+1 for forward/right, -1 for backward/left)
  const direction = currentIndex >= prevIndex ? 1 : -1;
  prevViewKeyRef.current = viewKey;

  // Variants with hardware-accelerated transforms & spring physics
  const pageVariants = {
    initial: (dir: number) => ({
      opacity: 0,
      x: dir * 16,
      scale: 0.996,
    }),
    animate: {
      opacity: 1,
      x: 0,
      scale: 1,
      transition: springPhysics,
    },
    exit: (dir: number) => ({
      opacity: 0,
      x: dir * -14,
      scale: 0.996,
      transition: {
        duration: 0.15,
        ease: [0.32, 0, 0.67, 0],
      },
    }),
  };

  return (
    <AnimatePresence mode="wait" custom={direction}>
      <motion.div
        key={viewKey}
        custom={direction}
        variants={pageVariants}
        initial="initial"
        animate="animate"
        exit="exit"
        className={`w-full ${className}`}
        style={{
          transform: 'translateZ(0)',
          WebkitTransform: 'translateZ(0)',
          willChange: 'transform, opacity',
          backfaceVisibility: 'hidden',
          WebkitBackfaceVisibility: 'hidden',
        }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}

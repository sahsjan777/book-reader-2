/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useMemo } from 'react';
import { 
  ArrowLeft, ArrowRight, ChevronLeft, ChevronRight,
  Bookmark, FileText, Settings, Eye, EyeOff, Sliders, ChevronDown, Clock,
  Sun, Moon, Search, MoreVertical, WrapText, X, Download,
  ZoomIn, ZoomOut, Maximize2, Minimize2, Volume2, Highlighter,
  Columns, AlignLeft, AlignJustify, AlignCenter, Languages, BookOpen, Play, Pause, AlertCircle
} from 'lucide-react';
import { PDFBook, Bookmark as BookmarkType, BookNote, Highlight, ReaderSettings } from '../types';
import { createStarterSampleBook } from '../lib/sample-book';
import BookmarksPanel from './BookmarksPanel';
import NotesPanel from './NotesPanel';
import HighlightsPanel from './HighlightsPanel';
import SearchPanel from './SearchPanel';
import HinglishPanel, { HinglishMode } from './HinglishPanel';
import SpeakPlayerBar from './SpeakPlayerBar';
import AnnotationsPanel from './AnnotationsPanel';
import ExportAnnotationsModal from './ExportAnnotationsModal';
import { detectLanguage, TTSLanguage, unlockSpeechAudio } from '../lib/tts-engine';

interface ReaderProps {
  book: PDFBook;
  bookmarks: BookmarkType[];
  notes: BookNote[];
  highlights: Highlight[];
  theme?: 'light' | 'dark';
  onBack: () => void;
  onToggleTheme?: () => void;
  onUpdateProgress: (page: number, scrollOffset: number, progress: number, totalPages?: number) => void;
  onAddBookmark: (bookmark: Omit<BookmarkType, 'id' | 'createdAt'>) => void;
  onDeleteBookmark: (id: string) => void;
  onSaveNote: (page: number, content: string, quote?: string) => void;
  onDeleteNote: (id: string) => void;
  onAddHighlight: (highlight: Omit<Highlight, 'id' | 'createdAt'>) => void;
  onDeleteHighlight: (id: string) => void;
  onUpdateHighlightColor?: (id: string, color: string) => void;
  onLogReadingTime: (durationMs: number, pagesRead: number) => void;
}

type PanelType = 'none' | 'bookmarks' | 'notes' | 'highlights' | 'settings' | 'search' | 'hinglish' | 'annotations';

function convertLineToHinglishLocal(line: string): string {
  let h = line.trim();
  h = h.replace(/is one of the most powerful tools for/i, 'sabse powerful tools mein se ek hai for');
  h = h.replace(/plays an important role in/i, 'mein important role play karta hai');
  h = h.replace(/It can create opportunities for/i, 'Yeh opportunities create kar sakta hai for');
  h = h.replace(/The author argues that/i, 'Author ka kehna hai ki');
  h = h.replace(/The author explains that/i, 'Author explain karta hai ki');
  h = h.replace(/is to the mind what exercise is to the body/i, 'dimaag ke liye wahi hai jo exercise body ke liye hoti hai');
  h = h.replace(/allows you to absorb wisdom without fatigue/i, 'bina thake wisdom absorb karne mein help karta hai');
  h = h.replace(/Features you will love in this reader/i, 'Is reader mein aapko yeh features pasand aayenge');
  h = h.replace(/In this digital age/i, 'Is digital daur mein');
  h = h.replace(/To read deeply is to dwell in thoughtful contemplation/i, 'Gehraayi se padhna thoughtful contemplation mein rehna hai');
  h = h.replace(/Use the quick toggle in the toolbar/i, 'Toolbar mein quick toggle use karein');
  h = h.replace(/without any clipping or hidden content/i, 'bina kisi clipping ya hidden content ke');
  h = h.replace(/Fill the full width of your device screen/i, 'Apni device screen ki poori width fill karein');
  h = h.replace(/Hide all distraction bars and immerse in pure text/i, 'Saari distractions hide karke sirf text par focus karein');
  h = h.replace(/Active reading transforms passive absorption into active mastery/i, 'Active reading passive padhai ko active mastery mein badal deti hai');
  h = h.replace(/Select any phrase or sentence in this book/i, 'Is book mein kisi bhi phrase ya sentence ko select karein');
  h = h.replace(/Everything is preserved locally and works 100% offline/i, 'Sab kuch locally save rehta hai aur 100% offline kaam karta hai');
  if (h === line.trim() && h.length > 5) {
    if (h.endsWith('.')) {
      return h.slice(0, -1) + ' — yeh point yahan discuss kiya gaya hai.';
    }
  }
  return h;
}

export default function Reader({
  book,
  bookmarks,
  notes,
  highlights,
  theme = 'light',
  onBack,
  onToggleTheme,
  onUpdateProgress,
  onAddBookmark,
  onDeleteBookmark,
  onSaveNote,
  onDeleteNote,
  onAddHighlight,
  onDeleteHighlight,
  onUpdateHighlightColor,
  onLogReadingTime
}: ReaderProps) {
  const [pdf, setPdf] = useState<any>(null);
  const [currentPage, setCurrentPage] = useState(book.currentPage || 1);
  const [totalPages, setTotalPages] = useState(book.totalPages || 0);
  const [loading, setLoading] = useState(true);
  const [renderingPage, setRenderingPage] = useState(false);
  const [activePanel, setActivePanel] = useState<PanelType>('none');
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
  const [currentScaleFactor, setCurrentScaleFactor] = useState<number>(1.0);
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);
  const [tutorialStep, setTutorialStep] = useState(0);
  const [showTutorial, setShowTutorial] = useState(() => {
    return localStorage.getItem('reader_tutorial_completed') !== 'true';
  });

  const completeTutorial = () => {
    setShowTutorial(false);
    localStorage.setItem('reader_tutorial_completed', 'true');
  };

  const nextTutorial = () => {
    if (tutorialStep < tutorialContent.length - 1) {
      setTutorialStep(tutorialStep + 1);
    } else {
      completeTutorial();
    }
  };
  const [showControls, setShowControls] = useState(true);
  const [focusMode, setFocusMode] = useState<boolean>(false);
  const [selectedQuoteForHinglish, setSelectedQuoteForHinglish] = useState<string>('');
  const [hinglishMode, setHinglishMode] = useState<HinglishMode>('hinglish');
  // Speak Mode: Always default to false on book open so books never auto-play audio
  const [isSpeakMode, setIsSpeakMode] = useState<boolean>(false);
  const [customTextForSpeak, setCustomTextForSpeak] = useState<string>('');
  const [speakLanguageHint, setSpeakLanguageHint] = useState<TTSLanguage | undefined>(undefined);
  const [currentSpokenSentence, setCurrentSpokenSentence] = useState<string>('');
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [initialQuoteForNote, setInitialQuoteForNote] = useState<string>('');
  const [targetHighlightId, setTargetHighlightId] = useState<string | null>(null);
  const [temporarySearchSnippet, setTemporarySearchSnippet] = useState<string>('');
  const [temporarySearchPage, setTemporarySearchPage] = useState<number | null>(null);

  // Full Page Translation State and Cache
  const [fullPageTranslation, setFullPageTranslation] = useState<string>('');
  const [isTranslatingPage, setIsTranslatingPage] = useState<boolean>(false);
  const [showFullPageTranslation, setShowFullPageTranslation] = useState<boolean>(false);

  // Clear any legacy auto-play flags and stop background speech when switching books
  useEffect(() => {
    try {
      localStorage.removeItem('reader_is_speak_mode');
    } catch (e) {}
    return () => {
      try {
        localStorage.removeItem('reader_is_speak_mode');
        if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
          window.speechSynthesis.cancel();
        }
      } catch (e) {}
    };
  }, []);

  const handleBackSafely = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try { window.speechSynthesis.cancel(); } catch (e) {}
    }
    setIsSpeakMode(false);
    setCustomTextForSpeak('');
    setSpeakLanguageHint(undefined);
    setCurrentSpokenSentence('');
    onBack();
  };

  // Automatically scroll to the currently spoken sentence in Reflow mode or PDF mode
  useEffect(() => {
    if (!isSpeakMode || !currentSpokenSentence) return;
    
    const timer = setTimeout(() => {
      const activeEl = document.querySelector('.spoken-active-sentence');
      if (activeEl) {
        activeEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 120);

    return () => clearTimeout(timer);
  }, [isSpeakMode, currentSpokenSentence]);

  // Touch swipe and pinch tracking refs
  const touchStartXRef = useRef<number | null>(null);
  const touchStartYRef = useRef<number | null>(null);
  const initialPinchDistanceRef = useRef<number | null>(null);
  const initialPinchZoomRef = useRef<number>(1.0);
  const secondCanvasRef = useRef<HTMLCanvasElement>(null);
  const secondTextLayerRef = useRef<HTMLDivElement>(null);

  const [pageInputVal, setPageInputVal] = useState<string>(String(book.currentPage || 1));

  // Synchronize with book prop when it changes
  useEffect(() => {
    setCurrentPage(book.currentPage || 1);
    setTotalPages(book.totalPages || 0);
    setPageInputVal(String(book.currentPage || 1));
  }, [book.id]);

  useEffect(() => {
    setPageInputVal(String(currentPage));
  }, [currentPage]);

  const topBarRef = useRef<HTMLDivElement>(null);
  const [topBarHeight, setTopBarHeight] = useState<number>(() => (typeof window !== 'undefined' && window.innerWidth < 768 ? 96 : 64));

  useEffect(() => {
    let timeoutId: any = null;
    const handleResize = () => {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        setWindowWidth(window.innerWidth);
      }, 150);
    };
    window.addEventListener('resize', handleResize);

    let topBarObserver: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined' && topBarRef.current) {
      topBarObserver = new ResizeObserver((entries) => {
        for (const entry of entries) {
          const h = entry.borderBoxSize?.[0]?.blockSize || entry.contentRect?.height;
          if (h && h > 0) {
            setTopBarHeight(prev => (Math.abs(prev - Math.ceil(h)) > 2 ? Math.ceil(h) : prev));
          }
        }
      });
      topBarObserver.observe(topBarRef.current);
    }

    return () => {
      window.removeEventListener('resize', handleResize);
      if (timeoutId) clearTimeout(timeoutId);
      if (topBarObserver) topBarObserver.disconnect();
    };
  }, []);

  // Auto-hide controls in Focus Mode after a few seconds of inactivity
  useEffect(() => {
    if (focusMode && showControls) {
      const timer = setTimeout(() => {
        setShowControls(false);
      }, 3500); // Hide controls after 3.5 seconds
      return () => clearTimeout(timer);
    }
  }, [focusMode, showControls]);
  
  // Floating Highlight Tooltip State
  const [tooltip, setTooltip] = useState<{
    visible: boolean;
    x: number;
    y: number;
    text: string;
    rects: Array<{ left: number; top: number; width: number; height: number }>;
    startIndex?: number;
    endIndex?: number;
  }>({ visible: false, x: 0, y: 0, text: '', rects: [] });

  const [extractedText, setExtractedText] = useState<string>('');
  const pageTextCacheRef = useRef<Map<number, string>>(new Map());
  const [pdfError, setPdfError] = useState<string | null>(null);
  const [readerMode, setReaderMode] = useState<'pdf' | 'reflow'>(() => {
    const saved = localStorage.getItem('reader_mode');
    return saved === 'reflow' ? 'reflow' : 'pdf';
  });

  // Reading Flow — Line-by-Line Hinglish State
  const [showLineByLineHinglish, setShowLineByLineHinglish] = useState<boolean>(() => {
    return localStorage.getItem('reader_line_by_line_hinglish') === 'true';
  });
  const [hinglishLinesMap, setHinglishLinesMap] = useState<Record<number, Array<{ original: string; hinglish: string }>>>({});
  const [loadingHinglishLines, setLoadingHinglishLines] = useState<boolean>(false);

  // Fetch or generate line-by-line Hinglish when Reading Flow is active
  useEffect(() => {
    if (!showLineByLineHinglish || !extractedText || readerMode !== 'reflow') return;
    if (extractedText.includes('This page has no selectable text')) return;
    if (hinglishLinesMap[currentPage] && hinglishLinesMap[currentPage].length > 0) return;

    let active = true;
    const fetchLineByLine = async () => {
      setLoadingHinglishLines(true);
      try {
        const rawParas = extractedText.split('\n').map(p => p.trim()).filter(Boolean);
        const lines: string[] = [];

        rawParas.forEach(para => {
          if (para.length < 80 || !/[.!?]/.test(para)) {
            lines.push(para);
          } else {
            const parts = para.split(/(?<=[.!?])\s+/).map(s => s.trim()).filter(Boolean);
            if (parts.length > 0) {
              lines.push(...parts);
            } else {
              lines.push(para);
            }
          }
        });

        if (lines.length === 0) return;

        const res = await fetch('/api/gemini/line-by-line-hinglish', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ lines }),
        });

        if (res.ok) {
          const data = await res.json();
          if (active && Array.isArray(data.items) && data.items.length > 0) {
            setHinglishLinesMap(prev => ({
              ...prev,
              [currentPage]: data.items,
            }));
            return;
          }
        }
        throw new Error('API fallback');
      } catch {
        if (active) {
          const rawParas = extractedText.split('\n').map(p => p.trim()).filter(Boolean);
          const fallbackItems = rawParas.map(orig => ({
            original: orig,
            hinglish: convertLineToHinglishLocal(orig),
          }));
          setHinglishLinesMap(prev => ({
            ...prev,
            [currentPage]: fallbackItems,
          }));
        }
      } finally {
        if (active) {
          setLoadingHinglishLines(false);
        }
      }
    };

    fetchLineByLine();

    return () => {
      active = false;
    };
  }, [showLineByLineHinglish, extractedText, currentPage, readerMode]);

  const [searchQuery, setSearchQuery] = useState('');
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [hasUsedReflow, setHasUsedReflow] = useState(() => {
    return localStorage.getItem('has_used_reflow') === 'true';
  });
  const [showReflowTooltip, setShowReflowTooltip] = useState(false);
  const [showReflowBanner, setShowReflowBanner] = useState(false);

  // Check for first-time reflow discovery
  useEffect(() => {
    if (!loading && !hasUsedReflow && readerMode === 'pdf') {
      const timer = setTimeout(() => {
        setShowReflowTooltip(true);
        if (window.innerWidth < 768) {
          setShowReflowBanner(true);
        }
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [loading, hasUsedReflow, readerMode]);

  // Stop any active speech synthesis when Reader unmounts
  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Memoize highlights on the current page for performance optimization
  const currentPageHighlights = useMemo(() => {
    return highlights.filter(h => h.pageNumber === currentPage);
  }, [highlights, currentPage]);

  // Reader Settings (Zoom, Page Fit, Margins, Typography Style)
  const [settings, setSettings] = useState<ReaderSettings>(() => {
    const saved = localStorage.getItem('reader_settings');
    const hasV2Fit = localStorage.getItem('reader_fit_preference_v2');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const fitMode = hasV2Fit ? (parsed.pageFit || 'fit-width') : 'fit-width';
        return {
          zoom: fitMode === 'fit-page' ? 1.0 : (parsed.zoom !== undefined ? parsed.zoom : 1.0),
          scrollMode: parsed.scrollMode || 'vertical',
          theme: parsed.theme || 'light',
          fontFamily: parsed.fontFamily || 'sans',
          fontSize: parsed.fontSize || 'md',
          lineHeight: parsed.lineHeight || 'relaxed',
          readingWidth: parsed.readingWidth || 'full',
          pageFit: fitMode,
          pageMargin: parsed.pageMargin || 'none'
        };
      } catch (e) {
        // ignore
      }
    }
    return {
      zoom: 1.0,
      scrollMode: 'vertical',
      theme: 'light',
      fontFamily: 'sans',
      fontSize: 'md',
      lineHeight: 'relaxed',
      readingWidth: 'full',
      pageFit: 'fit-width',
      pageMargin: 'none'
    };
  });

  // Save settings when they change
  useEffect(() => {
    localStorage.setItem('reader_settings', JSON.stringify(settings));
  }, [settings]);

  // Dynamically update toolbar height to ensure PDF content starts cleanly below it without overlap
  useEffect(() => {
    if (!topBarRef.current) return;
    const updateHeight = () => {
      if (topBarRef.current) {
        const rect = topBarRef.current.getBoundingClientRect();
        const h = Math.ceil(rect.height || topBarRef.current.offsetHeight);
        if (h > 0) {
          setTopBarHeight(prev => prev === h ? prev : h);
        }
      }
    };
    updateHeight();
    window.addEventListener('resize', updateHeight);
    window.addEventListener('orientationchange', updateHeight);

    let observer: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      observer = new ResizeObserver(updateHeight);
      observer.observe(topBarRef.current);
    }
    return () => {
      window.removeEventListener('resize', updateHeight);
      window.removeEventListener('orientationchange', updateHeight);
      if (observer) observer.disconnect();
    };
  }, [windowWidth, focusMode, showControls, isSpeakMode, readerMode, settings.pageFit]);

  const [dynamicHighlightRects, setDynamicHighlightRects] = useState<Record<string, Highlight['rects']>>({});

  const isCurrentPageBookmarked = useMemo(() => {
    return bookmarks.some(b => b.pageNumber === currentPage);
  }, [bookmarks, currentPage]);

  const handleToggleBookmark = () => {
    const existing = bookmarks.find(b => b.pageNumber === currentPage);
    if (existing) {
      onDeleteBookmark(existing.id);
    } else {
      onAddBookmark({
        bookId: book.id,
        pageNumber: currentPage,
        label: `Page ${currentPage}`
      });
    }
  };

  const handleExportNotes = () => {
    setShowExportModal(true);
  };

  // Helper to calculate visual rects from character offsets
  const getRectsFromOffsets = (container: HTMLElement, start: number, end: number) => {
    try {
      const range = document.createRange();
      let charCount = 0;
      let startNode: Node | null = null;
      let startOffset = 0;
      let endNode: Node | null = null;
      let endOffset = 0;

      const traverse = (node: Node) => {
        if (node.nodeType === Node.TEXT_NODE) {
          const len = node.textContent?.length || 0;
          if (!startNode && charCount + len >= start) {
            startNode = node;
            startOffset = Math.max(0, start - charCount);
          }
          if (!endNode && charCount + len >= end) {
            endNode = node;
            endOffset = Math.min(len, end - charCount);
          }
          charCount += len;
        } else {
          for (let i = 0; i < node.childNodes.length; i++) {
            traverse(node.childNodes[i]);
            if (startNode && endNode) break;
          }
        }
      };

      traverse(container);

      if (startNode && endNode) {
        range.setStart(startNode, startOffset);
        range.setEnd(endNode, endOffset);
        
        const pageRect = container.getBoundingClientRect();
        const clientRects = range.getClientRects();
        
        if (clientRects.length === 0) return null;
        
        return Array.from(clientRects)
          .map(r => ({
            left: ((r.left - pageRect.left) / pageRect.width) * 100,
            top: ((r.top - pageRect.top) / pageRect.height) * 100,
            width: (r.width / pageRect.width) * 100,
            height: (r.height / pageRect.height) * 100
          }))
          .filter(r => r.width > 0.01 && r.height > 0.01);
      }
    } catch (e) {
      console.warn("Failed to dynamically calculate highlight rects:", e);
    }
    return null;
  };

  // Synchronize highlight visual rects when page or layout changes in Reflow mode
  useEffect(() => {
    if (readerMode !== 'reflow' || renderingPage || !pageContainerRef.current) return;
    
    const newDynamicRects: Record<string, Highlight['rects']> = {};
    let hasUpdates = false;
    
    currentPageHighlights.forEach(h => {
      if (h.startIndex !== undefined && h.endIndex !== undefined) {
        const rects = getRectsFromOffsets(pageContainerRef.current!, h.startIndex, h.endIndex);
        if (rects) {
          newDynamicRects[h.id] = rects;
          hasUpdates = true;
        }
      }
    });
    
    if (hasUpdates) {
      setDynamicHighlightRects(prev => {
        const prevKeys = Object.keys(prev);
        const newKeys = Object.keys(newDynamicRects);
        if (prevKeys.length === newKeys.length && prevKeys.every(k => prev[k] === newDynamicRects[k])) {
          return prev;
        }
        return newDynamicRects;
      });
    } else {
      setDynamicHighlightRects(prev => Object.keys(prev).length === 0 ? prev : {});
    }
  }, [currentPage, currentPageHighlights, renderingPage, readerMode, windowWidth]);
  const [showTextSettings, setShowTextSettings] = useState(false);

  const getFontFamilyClass = (font?: 'sans' | 'serif' | 'display' | 'mono' | 'poppins' | 'source') => {
    switch (font) {
      case 'mono': return 'font-mono';
      default: return 'font-sans';
    }
  };

  const getFontSizeClass = (size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl') => {
    switch (size) {
      case 'xs': return 'text-xs md:text-xs';
      case 'sm': return 'text-sm md:text-sm';
      case 'md': return 'text-base md:text-base';
      case 'lg': return 'text-lg md:text-lg font-medium';
      case 'xl': return 'text-xl md:text-xl font-medium';
      case '2xl': return 'text-2xl md:text-2xl font-medium';
      case '3xl': return 'text-3xl md:text-3xl font-medium';
      default: return 'text-base';
    }
  };

  const getLineHeightClass = (lh?: 'tight' | 'normal' | 'relaxed' | 'loose') => {
    switch (lh) {
      case 'tight': return 'leading-snug';
      case 'normal': return 'leading-normal';
      case 'relaxed': return 'leading-relaxed';
      case 'loose': return 'leading-loose';
      default: return 'leading-relaxed';
    }
  };

  const getReadingWidthClass = (rw?: 'narrow' | 'normal' | 'wide' | 'full') => {
    switch (rw) {
      case 'narrow': return 'max-w-md mx-auto';
      case 'normal': return 'max-w-3xl mx-auto';
      case 'wide': return 'max-w-5xl mx-auto';
      case 'full': return 'max-w-full w-full';
      default: return 'max-w-full w-full';
    }
  };

  const getReadingWidthContainerClass = (rw?: 'narrow' | 'normal' | 'wide' | 'full') => {
    switch (rw) {
      case 'narrow': return 'max-w-md';
      case 'normal': return 'max-w-3xl';
      case 'wide': return 'max-w-5xl';
      case 'full': return 'max-w-full';
      default: return 'max-w-full';
    }
  };

  const handleZoomChange = (delta: number) => {
    setSettings(prev => {
      const current = prev.pageFit === 'fit-page' ? 1.0 : (prev.zoom || 1.0);
      const next = Math.min(3.0, Math.max(0.6, Math.round((current + delta) * 10) / 10));
      return { ...prev, zoom: next, pageFit: 'fit-width' };
    });
  };

  const handleResetZoom = () => {
    setSettings(prev => ({ ...prev, zoom: 1.0, pageFit: 'fit-page', pageMargin: 'none' }));
    localStorage.setItem('reader_fit_preference_v2', 'true');
  };

  const activeFontClass = getFontFamilyClass(settings.fontFamily);
  const activeSizeClass = getFontSizeClass(settings.fontSize);

  // Track session metrics
  const sessionStartTimeRef = useRef<number>(Date.now());
  const pagesReadSetRef = useRef<Set<number>>(new Set());

  // Refs for rendering
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const textLayerRef = useRef<HTMLDivElement>(null);
  const pageContainerRef = useRef<HTMLDivElement>(null);
  const documentWrapperRef = useRef<HTMLDivElement>(null);
  const viewportContainerRef = useRef<HTMLDivElement>(null);
  const renderTaskRef = useRef<any>(null);
  const selectionTimeoutRef = useRef<any>(null);
  const copyTimeoutRef = useRef<any>(null);
  const isClearingSelectionRef = useRef<boolean>(false);

  const resetSelectionState = React.useCallback(() => {
    if (isClearingSelectionRef.current) return;
    try {
      isClearingSelectionRef.current = true;
      const selection = window.getSelection();
      if (selection) {
        selection.removeAllRanges();
      }
      setTooltip({ visible: false, x: 0, y: 0, text: '', rects: [] });
    } catch (e) {
      // ignore
    } finally {
      // Use a slightly longer delay for safety
      setTimeout(() => {
        isClearingSelectionRef.current = false;
      }, 200);
    }
  }, []);

  // Final cleanup on unmount
  useEffect(() => {
    return () => {
      try {
        const selection = window.getSelection();
        if (selection) {
          selection.removeAllRanges();
        }
      } catch (e) {
        // ignore
      }
      if (selectionTimeoutRef.current) clearTimeout(selectionTimeoutRef.current);
      if (copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current);
    };
  }, []);

  // Refs to optimize layout rendering and avoid destroying/recreating text layers on minor mobile resizes
  const lastRenderedWidthRef = useRef<number>(0);
  const lastRenderedHeightRef = useRef<number>(0);
  const lastRenderedPageRef = useRef<number>(0);
  const lastSavedProgressPageRef = useRef<number>(-1);
  const lastRenderedModeRef = useRef<string>('');
  const lastRenderedPdfRef = useRef<any>(null);
  const lastRenderedZoomRef = useRef<number>(1.0);
  const lastRenderedMarginRef = useRef<string>('none');
  const lastRenderedFitRef = useRef<string>('fit-page');

  // Initialize PDF.js worker and load document
  useEffect(() => {
    const pdfjsLib = (window as any).pdfjsLib;
    if (!pdfjsLib) {
      console.error("PDF.js library is missing in index.html");
      return;
    }
    
    // Set worker source
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

    let active = true;
    let loadedPdf: any = null;

    async function loadPDF() {
      let fileBlob = book.fileBlob;
      if (!fileBlob && book.id === 'starter-guide-book') {
        const fresh = createStarterSampleBook();
        fileBlob = fresh.fileBlob;
      }
      if (!fileBlob) {
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        const arrayBuffer = await fileBlob.arrayBuffer();
        const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
        const pdfDoc = await loadingTask.promise;
        
        if (active) {
          loadedPdf = pdfDoc;
          setTotalPages(pdfDoc.numPages);
          pagesReadSetRef.current.add(currentPage);
          setLoading(false);
          setPdf(pdfDoc);
        } else {
          pdfDoc.destroy();
        }
      } catch (err) {
        console.error("Error loading PDF: ", err);
        if (active) {
          setLoading(false);
          setPdfError("Could not load document. The file may be corrupted or unsupported.");
        }
      }
    }

    loadPDF();

    // Start reading session timer
    sessionStartTimeRef.current = Date.now();
    pagesReadSetRef.current = new Set([currentPage]);
    lastLoggedTimeRef.current = Date.now();
    intervalPagesReadSetRef.current = new Set([currentPage]);

    const handleBeforeUnload = () => {
      const now = Date.now();
      const elapsed = now - lastLoggedTimeRef.current;
      if (elapsed >= 2000) {
        const pagesCount = intervalPagesReadSetRef.current.size;
        onLogReadingTime(elapsed, pagesCount);
        lastLoggedTimeRef.current = now;
        intervalPagesReadSetRef.current.clear();
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      active = false;
      window.removeEventListener('beforeunload', handleBeforeUnload);
      
      const now = Date.now();
      const elapsed = now - lastLoggedTimeRef.current;
      if (elapsed >= 2000) {
        const pagesCount = intervalPagesReadSetRef.current.size;
        onLogReadingTime(elapsed, pagesCount);
      }

      if (loadedPdf) {
        try {
          loadedPdf.destroy();
        } catch (e) {
          // ignore
        }
      }

      if (selectionTimeoutRef.current) {
        clearTimeout(selectionTimeoutRef.current);
      }
    };
  }, [book.id]);

  const lastLoggedTimeRef = useRef<number>(Date.now());
  const intervalPagesReadSetRef = useRef<Set<number>>(new Set());

  // Track page counts for timing intervals
  useEffect(() => {
    pagesReadSetRef.current.add(currentPage);
    intervalPagesReadSetRef.current.add(currentPage);
  }, [currentPage]);

  // Periodic save of reading session time (every 30 seconds)
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      const elapsed = now - lastLoggedTimeRef.current;
      if (elapsed >= 5000) { // log if at least 5s passed
        const pagesCount = intervalPagesReadSetRef.current.size;
        onLogReadingTime(elapsed, pagesCount);
        lastLoggedTimeRef.current = now;
        intervalPagesReadSetRef.current.clear();
        intervalPagesReadSetRef.current.add(currentPage);
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [currentPage, onLogReadingTime]);

  // Render Page Canvas & Text Layer
  useEffect(() => {
    if (!pdf) return;

    let active = true;

    async function renderPage() {
      if (!active) return;
      
      try {
        // Cancel any pending render task from previous runs and await release
        if (renderTaskRef.current) {
          try {
            const oldTask = renderTaskRef.current;
            renderTaskRef.current = null;
            oldTask.cancel();
            await oldTask.promise.catch(() => {});
          } catch (e) {
            // ignore
          }
        }

        const page = await pdf.getPage(currentPage);
        if (!active) return;

        // Pre-fetch text content immediately so Speak Mode and Hinglish are instantly ready
        page.getTextContent().then((tc: any) => {
          if (active && tc && tc.items) {
            const pageStrings = tc.items
              .map((item: any) => item.str || '')
              .filter((str: string) => str.trim().length > 0);
            if (pageStrings.length > 0) {
              const fullStr = pageStrings.join(' ');
              pageTextCacheRef.current.set(currentPage, fullStr);
              setExtractedText(fullStr);
            }
          }
        }).catch(() => {});

        // Pre-extract next page text for seamless continuous speaking transition
        if (currentPage < totalPages && pdf) {
          const nextP = currentPage + 1;
          if (!pageTextCacheRef.current.has(nextP)) {
            pdf.getPage(nextP).then((np: any) => np.getTextContent()).then((tc: any) => {
              if (tc && tc.items) {
                const s = tc.items.map((i: any) => i.str || '').filter((x: string) => x.trim().length > 0).join(' ');
                if (s) pageTextCacheRef.current.set(nextP, s);
              }
            }).catch(() => {});
          }
        }
        
        // Optimize rendering: Avoid destroying/recreating canvas and text layer on minor resizes
        let containerWidth = 0;
        let containerHeight = 0;
        if (viewportContainerRef.current) {
          containerWidth = viewportContainerRef.current.clientWidth || window.innerWidth;
          containerHeight = viewportContainerRef.current.clientHeight || window.innerHeight;
        } else {
          containerWidth = window.innerWidth;
          containerHeight = window.innerHeight;
        }
        
        const pageMarginMode = settings.pageMargin || 'none';
        const pageFitMode = settings.pageFit || 'fit-page';
        const currentZoom = pageFitMode === 'fit-page' ? 1.0 : (settings.zoom || 1.0);

        const widthDiff = Math.abs(containerWidth - lastRenderedWidthRef.current);
        const heightDiff = Math.abs(containerHeight - lastRenderedHeightRef.current);
        const isSamePageAndMode = lastRenderedPageRef.current === currentPage && lastRenderedModeRef.current === readerMode;
        const isSameSettings = 
          lastRenderedZoomRef.current === currentZoom &&
          lastRenderedMarginRef.current === pageMarginMode &&
          lastRenderedFitRef.current === pageFitMode;
        
        if (isSamePageAndMode && isSameSettings && lastRenderedPdfRef.current === pdf && widthDiff < 20 && heightDiff < 20 && lastRenderedWidthRef.current > 0) {
          return;
        }
        setRenderingPage(true);
        
        if (readerMode === 'reflow') {
          // ------------------ REFLOW TEXT ENGINE ------------------
          // Fast path: Only extract text content. Bypass canvas and text layer render entirely.
          const textContent = await page.getTextContent();
          if (active) {
            if (textContent && textContent.items && textContent.items.length > 0) {
              // Sort items by Y (top to bottom) and then X (left to right) to ensure correct reading order
              const sortedItems = [...textContent.items].sort((a: any, b: any) => {
                const yA = a.transform ? a.transform[5] : 0;
                const yB = b.transform ? b.transform[5] : 0;
                const xA = a.transform ? a.transform[4] : 0;
                const xB = b.transform ? b.transform[4] : 0;
                
                // PDF coordinates have Y=0 at the bottom. So higher Y is higher on page.
                if (Math.abs(yA - yB) > 5) {
                  return yB - yA;
                }
                return xA - xB;
              });

              // Deduplicate items (common in PDFs with "shadow" text or multiple layers)
              const uniqueItems: any[] = [];
              sortedItems.forEach((item: any) => {
                const isDuplicate = uniqueItems.some(u => 
                  u.str === item.str && 
                  Math.abs(u.transform[4] - item.transform[4]) < 1 &&
                  Math.abs(u.transform[5] - item.transform[5]) < 1
                );
                if (!isDuplicate) {
                  uniqueItems.push(item);
                }
              });

              let lastY: number | null = null;
              let lines: string[] = [];
              let currentPara = '';
              
              uniqueItems.forEach((item: any) => {
                const str = item.str || '';
                if (!str.trim() && str !== ' ') return;
                
                const y = item.transform ? item.transform[5] : null;
                
                // If Y difference is significant, start a new paragraph/block
                if (y !== null && lastY !== null && Math.abs(y - lastY) > 10) {
                  if (currentPara.trim()) {
                    lines.push(currentPara.trim());
                  }
                  currentPara = str;
                } else {
                  // Append to current paragraph with appropriate spacing
                  const needsSpace = currentPara.length > 0 && 
                                   !currentPara.endsWith(' ') && 
                                   !str.startsWith(' ') &&
                                   !currentPara.endsWith('-') &&
                                   !str.startsWith(',') &&
                                   !str.startsWith('.');
                  currentPara += (needsSpace ? ' ' : '') + str;
                }
                
                if (y !== null) {
                  lastY = y;
                }
              });
              
              if (currentPara.trim()) {
                lines.push(currentPara.trim());
              }
              
              setExtractedText(lines.join('\n'));
            } else {
              setExtractedText('This page has no selectable text. Try reading in PDF Mode!');
            }
          }
        } else {
          // ------------------ HIGH-DEFINITION PDF LAYOUT ENGINE ------------------
          let baseScale = 1.0;
          if (viewportContainerRef.current) {
            const container = viewportContainerRef.current;
            const containerWidth = container.clientWidth || window.innerWidth;
            const containerHeight = container.clientHeight || window.innerHeight;
            const unscaledViewport = page.getViewport({ scale: 1.0 });
            
            // Accurately measure container computed padding to prevent horizontal overflow and clipping
            const computedStyle = window.getComputedStyle(container);
            const padLeft = parseFloat(computedStyle.paddingLeft) || 0;
            const padRight = parseFloat(computedStyle.paddingRight) || 0;
            const padTop = parseFloat(computedStyle.paddingTop) || 0;
            const padBottom = parseFloat(computedStyle.paddingBottom) || 0;
            
            // Usable inner content dimensions of viewport (excluding padding & safe area insets)
            const innerWidth = Math.max(containerWidth - padLeft - padRight, 180);
            const innerHeight = Math.max(containerHeight - padTop - padBottom, 180);

            // Safe side margin so text is NEVER cut off by rounded screen bezels, scrollbars, or edge gestures
            let sideSafetyGap = 0;
            if (pageMarginMode === 'none') {
              // Full width with safe gutter (8px mobile, 14px desktop) so edge letters are 100% visible and never truncated
              sideSafetyGap = window.innerWidth < 768 ? 8 : 14;
            } else if (pageMarginMode === 'compact') {
              sideSafetyGap = window.innerWidth < 768 ? 16 : 24;
            } else {
              sideSafetyGap = window.innerWidth >= 768 ? 48 : 28;
            }

            const availableWidth = Math.max(innerWidth - sideSafetyGap, 160);

            if (pageFitMode === 'original') {
              baseScale = 1.0;
            } else if (pageFitMode === 'two-page' && window.innerWidth >= 768) {
              const twoPageWidth = Math.max((availableWidth - 16) / 2, 120);
              const scaleW = twoPageWidth / unscaledViewport.width;
              const verticalSafetyGap = 16;
              const availableHeight = Math.max(innerHeight - verticalSafetyGap, 160);
              const scaleH = availableHeight / unscaledViewport.height;
              baseScale = Math.min(scaleW, scaleH);
            } else if (pageFitMode === 'fit-page' && unscaledViewport.height > 0 && innerHeight > 0) {
              // innerHeight already accounts for top bar (padTop) and bottom bar (padBottom)
              // We only apply a light safety gap for elegant framing
              const verticalSafetyGap = window.innerWidth < 768 ? 10 : 16;
              const availableHeight = Math.max(innerHeight - verticalSafetyGap, 160);
              const scaleW = availableWidth / unscaledViewport.width;
              const scaleH = availableHeight / unscaledViewport.height;
              // Math.min guarantees the WHOLE PAGE (top-to-bottom and left-to-right) fits 100% on screen
              baseScale = Math.min(scaleW, scaleH);
            } else {
              // fit-width: Full edge-to-edge reading layout without clipping or truncated text
              if (availableWidth > 0 && unscaledViewport.width > 0) {
                baseScale = availableWidth / unscaledViewport.width;
              }
            }
            baseScale = Math.max(0.05, baseScale);
          }
          
          // Apply user zoom multiplier
          const effectiveScale = baseScale * currentZoom;
          const cssScale = Math.min(4.5, Math.max(0.05, effectiveScale));
          const viewport = page.getViewport({ scale: cssScale });

          if (!active) return;

          // Set dimensions immediately so layout container and textLayer resize in sync
          const targetWidth = Math.floor(viewport.width);
          const targetHeight = Math.floor(viewport.height);
          if (active) {
            setDimensions({ width: targetWidth, height: targetHeight });
            setCurrentScaleFactor(viewport.scale);
          }

          // Ensure CSS scale factor is updated on root document
          if (typeof document !== 'undefined') {
            document.documentElement.style.setProperty('--scale-factor', `${viewport.scale}`);
          }

          // Render Ultra-Crisp High-DPI Canvas
          const mainCanvas = canvasRef.current;
          if (mainCanvas && active) {
            const dpr = window.devicePixelRatio || 1;
            // Target retina quality (minimum 2.0x, up to 3.0x on retina displays)
            const targetOutputScale = Math.max(dpr, 2.0);
            
            // Protect against browser GPU texture limits (e.g. 4096px)
            const maxDimension = 4096;
            let outputScale = targetOutputScale;
            if (viewport.width * outputScale > maxDimension || viewport.height * outputScale > maxDimension) {
              outputScale = Math.min(maxDimension / viewport.width, maxDimension / viewport.height);
            }
            outputScale = Math.max(1.0, outputScale);

            const canvasWidth = Math.floor(viewport.width * outputScale);
            const canvasHeight = Math.floor(viewport.height * outputScale);

            mainCanvas.width = canvasWidth;
            mainCanvas.height = canvasHeight;
            mainCanvas.style.width = `${targetWidth}px`;
            mainCanvas.style.height = `${targetHeight}px`;
            mainCanvas.style.display = 'block';

            const context = mainCanvas.getContext('2d', { alpha: false });
            if (context) {
              context.setTransform(1, 0, 0, 1, 0, 0);
              context.fillStyle = '#ffffff';
              context.fillRect(0, 0, canvasWidth, canvasHeight);
              context.imageSmoothingEnabled = true;
              context.imageSmoothingQuality = 'high';

              // CRITICAL: PDF.js requires the transform matrix to draw into the high-DPI canvas buffer
              const transform = outputScale !== 1 
                ? [outputScale, 0, 0, outputScale, 0, 0] 
                : null;

              const renderContext = {
                canvasContext: context,
                transform: transform,
                viewport: viewport
              };

              const renderTask = page.render(renderContext);
              renderTaskRef.current = renderTask;
              
              await renderTask.promise;

              // Render second page if in Two-Page mode on desktop/tablet
              if (pageFitMode === 'two-page' && window.innerWidth >= 768 && currentPage < totalPages) {
                try {
                  const secondPage = await pdf.getPage(currentPage + 1);
                  if (active && secondCanvasRef.current) {
                    const secondCanvas = secondCanvasRef.current;
                    secondCanvas.width = canvasWidth;
                    secondCanvas.height = canvasHeight;
                    secondCanvas.style.width = `${targetWidth}px`;
                    secondCanvas.style.height = `${targetHeight}px`;
                    secondCanvas.style.display = 'block';
                    const ctx2 = secondCanvas.getContext('2d', { alpha: false });
                    if (ctx2) {
                      ctx2.setTransform(1, 0, 0, 1, 0, 0);
                      ctx2.fillStyle = '#ffffff';
                      ctx2.fillRect(0, 0, canvasWidth, canvasHeight);
                      ctx2.imageSmoothingEnabled = true;
                      ctx2.imageSmoothingQuality = 'high';
                      const secondRenderTask = secondPage.render({
                        canvasContext: ctx2,
                        transform: transform,
                        viewport: viewport
                      });
                      await secondRenderTask.promise;
                    }
                  }
                } catch (err) {
                  console.warn("Second page render notice:", err);
                }
              }
            }
          }

          // Render Text Layer for Highlights & Selection
          const textLayerDiv = textLayerRef.current;
          const pdfjsLib = (window as any).pdfjsLib;
          if (textLayerDiv && pdfjsLib && active) {
            textLayerDiv.innerHTML = '';
            textLayerDiv.style.width = `${Math.floor(viewport.width)}px`;
            textLayerDiv.style.height = `${Math.floor(viewport.height)}px`;
            
            const scaleStr = `${viewport.scale}`;
            textLayerDiv.style.setProperty('--scale-factor', scaleStr);
            if (pageContainerRef.current) {
              pageContainerRef.current.style.setProperty('--scale-factor', scaleStr);
            }
            if (typeof document !== 'undefined') {
              document.documentElement.style.setProperty('--scale-factor', scaleStr);
            }
            
            try {
              const textContent = await page.getTextContent();
              if (active && textContent && textContent.items) {
                const pageStrings = textContent.items
                  .map((item: any) => item.str || '')
                  .filter((str: string) => str.trim().length > 0);
                const fullText = pageStrings.join(' ');
                setExtractedText(fullText);
              }

              // Re-affirm --scale-factor immediately before renderTextLayer to guard against React re-render wiping style
              const exactScale = viewport.scale;
              const scaleStr = `${exactScale}`;
              textLayerDiv.style.setProperty('--scale-factor', scaleStr);
              if (pageContainerRef.current) {
                pageContainerRef.current.style.setProperty('--scale-factor', scaleStr);
              }
              if (typeof document !== 'undefined') {
                document.documentElement.style.setProperty('--scale-factor', scaleStr);
              }

              // Temporarily shield against any internal PDF.js scale-factor error logging
              const originalConsoleError = console.error;
              console.error = function(...args: any[]) {
                if (typeof args[0] === 'string' && args[0].includes('--scale-factor')) {
                  return;
                }
                originalConsoleError.apply(console, args);
              };

              try {
                const textLayerTask = pdfjsLib.renderTextLayer({
                  textContent: textContent,
                  container: textLayerDiv,
                  viewport: viewport,
                  textDivs: []
                });
                if (textLayerTask && textLayerTask.promise) {
                  await textLayerTask.promise;
                }
              } finally {
                console.error = originalConsoleError;
              }
            } catch (err) {
              console.warn("Text layer rendering notice:", err);
            }
          }
        }

        // Update layout stability refs on successful render
        if (active) {
          lastRenderedWidthRef.current = containerWidth;
          lastRenderedHeightRef.current = containerHeight;
          lastRenderedPageRef.current = currentPage;
          lastRenderedModeRef.current = readerMode;
          lastRenderedPdfRef.current = pdf;
          lastRenderedZoomRef.current = currentZoom;
          lastRenderedMarginRef.current = pageMarginMode;
          lastRenderedFitRef.current = pageFitMode;
        }

        // Auto-save reading progress (only once per unique page to prevent render cascades)
        if (active && lastSavedProgressPageRef.current !== currentPage) {
          lastSavedProgressPageRef.current = currentPage;
          const progress = totalPages > 0 ? (currentPage / totalPages) * 100 : 0;
          onUpdateProgress(currentPage, 0, progress, totalPages);
        }

      } catch (err: any) {
        if (err && (err.name === 'RenderingCancelledException' || err.message?.includes('cancelled'))) {
          // Expected when a task is cancelled, so we don't log it as an error
        } else {
          console.error("Error rendering page: ", err);
        }
      } finally {
        setRenderingPage(false);
      }
    }

    renderPage();

    return () => {
      active = false;
      if (renderTaskRef.current) {
        try {
          renderTaskRef.current.cancel();
        } catch (e) {
          // ignore
        }
      }
    };
  }, [pdf, currentPage, windowWidth, readerMode, settings.zoom, settings.pageMargin, settings.pageFit, showControls, focusMode]);

  // Highlight search terms within the text layer in PDF Mode
  useEffect(() => {
    if (readerMode !== 'pdf' || renderingPage) return;
    
    const textLayerDiv = textLayerRef.current;
    if (textLayerDiv) {
      highlightTextLayer(textLayerDiv, searchQuery);
      
      // Auto-scroll to first match on page if search was just triggered or page changed
      if (searchQuery && searchQuery.trim().length >= 2) {
        const firstMatch = textLayerDiv.querySelector('mark');
        if (firstMatch && viewportContainerRef.current) {
          setTimeout(() => {
            firstMatch.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }, 100);
        }
      }
    }
  }, [searchQuery, currentPage, renderingPage, readerMode]);

  const highlightText = (text: string, highlight: string, spokenSentence?: string) => {
    if (!text) return null;

    // Split for currently spoken sentence if active
    let baseNodes: React.ReactNode[] = [text];
    if (spokenSentence && spokenSentence.trim().length > 3) {
      const s = spokenSentence.trim();
      const sEscaped = escapeRegExp(s).replace(/\s+/g, '\\s+');
      try {
        const regex = new RegExp(`(${sEscaped})`, 'gi');
        if (regex.test(text)) {
          const parts = text.split(regex);
          baseNodes = parts.map((part, idx) => {
            if (part.toLowerCase().replace(/\s+/g, ' ') === s.toLowerCase().replace(/\s+/g, ' ')) {
              return (
                <span key={`spoken-${idx}`} className="spoken-active-sentence bg-orange-400/25 dark:bg-orange-500/30 text-orange-950 dark:text-orange-100 rounded px-1 transition-all duration-300 ring-2 ring-orange-500/50 font-medium">
                  {part}
                </span>
              );
            }
            return part;
          });
        }
      } catch {
        // fallback to simple string check
        if (text.toLowerCase().includes(s.toLowerCase())) {
          const parts = text.split(new RegExp(`(${escapeRegExp(s)})`, 'gi'));
          baseNodes = parts.map((part, idx) => {
            if (part.toLowerCase() === s.toLowerCase()) {
              return (
                <span key={`spoken-${idx}`} className="spoken-active-sentence bg-orange-400/25 dark:bg-orange-500/30 text-orange-950 dark:text-orange-100 rounded px-1 transition-all duration-300 ring-2 ring-orange-500/50 font-medium">
                  {part}
                </span>
              );
            }
            return part;
          });
        }
      }
    }

    if (!highlight || !highlight.trim()) {
      return <>{baseNodes}</>;
    }

    const q = highlight.trim();
    return (
      <>
        {baseNodes.map((node, nodeIdx) => {
          if (typeof node !== 'string') return <React.Fragment key={nodeIdx}>{node}</React.Fragment>;
          const parts = node.split(new RegExp(`(${escapeRegExp(q)})`, 'gi'));
          return parts.map((part, i) =>
            part.toLowerCase() === q.toLowerCase() ? (
              <mark key={`m-${nodeIdx}-${i}`} className="bg-amber-300 dark:bg-amber-500/30 dark:text-amber-100 text-amber-900 font-bold px-0.5 rounded border border-amber-500/30">
                {part}
              </mark>
            ) : (
              part
            )
          );
        })}
      </>
    );
  };



  // Handle text selection using the standard, mobile-friendly selectionchange event
  const handleSelectionChange = React.useCallback(() => {
    if (isClearingSelectionRef.current) return;

    if (selectionTimeoutRef.current) {
      clearTimeout(selectionTimeoutRef.current);
    }

    selectionTimeoutRef.current = setTimeout(() => {
      try {
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0 && !selection.isCollapsed) {
          const range = selection.getRangeAt(0);
          if (!range) return;

          // Ensure selection is inside the text layer of the reader
          const textLayerDiv = textLayerRef.current;
          if (!textLayerDiv || !textLayerDiv.contains(range.commonAncestorContainer)) {
            // Check if it's reflow mode container
            const pageContainer = pageContainerRef.current;
            if (readerMode !== 'reflow' || !pageContainer || !pageContainer.contains(range.commonAncestorContainer)) {
              return;
            }
          }

          const textStr = selection.toString().trim();
          if (textStr.length === 0) {
            setTooltip(prev => (prev.visible ? { ...prev, visible: false, text: '', rects: [] } : prev));
            return;
          }

          const rect = range.getBoundingClientRect();
          if (rect.width === 0 || rect.height === 0) return;

          const viewportContainer = viewportContainerRef.current;
          if (!viewportContainer) return;

          const containerRect = viewportContainer.getBoundingClientRect();
          const newX = rect.left - containerRect.left + (rect.width / 2);
          const newY = rect.bottom - containerRect.top + viewportContainer.scrollTop + 12;

          // Precompute selection rects relative to the page container
          let rects: Array<{ left: number; top: number; width: number; height: number }> = [];
          let startIndex: number | undefined;
          let endIndex: number | undefined;
          const pageContainer = pageContainerRef.current;

          if (pageContainer) {
            const pageRect = pageContainer.getBoundingClientRect();
            const clientRects = range.getClientRects();
            rects = Array.from(clientRects)
              .map(r => ({
                left: ((r.left - pageRect.left) / pageRect.width) * 100,
                top: ((r.top - pageRect.top) / pageRect.height) * 100,
                width: (r.width / pageRect.width) * 100,
                height: (r.height / pageRect.height) * 100
              }))
              .filter(r => r.width > 0.01 && r.height > 0.01);

            // Calculate character offsets for stable text anchoring
            try {
              const preSelectionRange = range.cloneRange();
              preSelectionRange.selectNodeContents(pageContainer);
              preSelectionRange.setEnd(range.startContainer, range.startOffset);
              startIndex = preSelectionRange.toString().length;
              endIndex = startIndex + selection.toString().length;
            } catch (e) {
              console.warn("Failed to calculate character offsets:", e);
            }
          }

          setTooltip(prev => {
            // Only update if selection changed to prevent redundant renders
            if (prev.visible && prev.text === textStr && Math.abs(prev.x - newX) < 1 && Math.abs(prev.y - newY) < 1 && prev.startIndex === startIndex) {
              return prev;
            }
            return {
              visible: true,
              x: newX,
              y: newY,
              text: textStr,
              rects,
              startIndex,
              endIndex
            };
          });
        } else {
          setTooltip(prev => (prev.visible ? { ...prev, visible: false, text: '', rects: [] } : prev));
        }
      } catch (err) {
        console.warn("Error handling text selection:", err);
      }
    }, 200); 
  }, [readerMode]);

  useEffect(() => {
    document.addEventListener('selectionchange', handleSelectionChange);
    return () => {
      document.removeEventListener('selectionchange', handleSelectionChange);
      if (selectionTimeoutRef.current) {
        clearTimeout(selectionTimeoutRef.current);
      }
    };
  }, [handleSelectionChange]);

  // Handle global copy to cleanly dismiss selection handles and hide the highlight menu
  useEffect(() => {
    const handleGlobalCopy = () => {
      if (copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current);
      
      // Allow the native browser copy operation to complete first
      copyTimeoutRef.current = setTimeout(() => {
        resetSelectionState();
      }, 150);
    };

    document.addEventListener('copy', handleGlobalCopy);
    return () => {
      document.removeEventListener('copy', handleGlobalCopy);
      if (copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current);
    };
  }, [resetSelectionState]);

  const handleAddHighlightClick = (color: string) => {
    try {
      if (!tooltip.text || !tooltip.rects || tooltip.rects.length === 0) return;

      onAddHighlight({
        bookId: book.id,
        pageNumber: currentPage,
        text: tooltip.text,
        color,
        rects: tooltip.rects,
        startIndex: tooltip.startIndex,
        endIndex: tooltip.endIndex
      });

      resetSelectionState();
    } catch (err) {
      console.warn("Error adding highlight:", err);
    }
  };

  const isNavigatingRef = useRef(false);
  const handlePageNavigation = React.useCallback((newPage: number) => {
    if (loading || isNavigatingRef.current) return;
    const maxPages = totalPages > 0 ? totalPages : 1;
    const page = Math.max(1, Math.min(maxPages, newPage));
    if (page === currentPage) return;
    
    isNavigatingRef.current = true;
    setTimeout(() => {
      isNavigatingRef.current = false;
    }, 120);

    // Clear selection and tooltip before navigating
    resetSelectionState();

    // If speaking a custom selected snippet, clear snippet so next page reads page text seamlessly
    if (customTextForSpeak) {
      setCustomTextForSpeak('');
    }

    // Immediately extract text for the destination page so Speak Mode never stutters or resets
    const cachedPageText = pageTextCacheRef.current.get(page);
    if (cachedPageText) {
      setExtractedText(cachedPageText);
    } else {
      setExtractedText('');
      if (pdf) {
        pdf.getPage(page).then((p: any) => p.getTextContent()).then((tc: any) => {
          if (tc && tc.items) {
            const strings = tc.items
              .map((item: any) => item.str || '')
              .filter((str: string) => str.trim().length > 0);
            if (strings.length > 0) {
              const fullStr = strings.join(' ');
              pageTextCacheRef.current.set(page, fullStr);
              setExtractedText(fullStr);
            }
          }
        }).catch(() => {});
      }
    }

    setCurrentPage(page);
    pagesReadSetRef.current.add(page);
    // Scroll viewport container back to top and left so the next page starts naturally
    if (viewportContainerRef.current) {
      viewportContainerRef.current.scrollTop = 0;
      viewportContainerRef.current.scrollLeft = 0;
    }
  }, [loading, totalPages, currentPage, customTextForSpeak, resetSelectionState]);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0].clientX;
    touchStartYRef.current = e.touches[0].clientY;
    if (e.touches.length === 2) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      initialPinchDistanceRef.current = dist;
      initialPinchZoomRef.current = settings.zoom || 1.0;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && initialPinchDistanceRef.current !== null && initialPinchDistanceRef.current > 0) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      const ratio = dist / initialPinchDistanceRef.current;
      const nextZoom = Math.min(3.5, Math.max(0.6, Math.round(initialPinchZoomRef.current * ratio * 20) / 20));
      setSettings(prev => ({
        ...prev,
        zoom: nextZoom,
        pageFit: 'fit-width'
      }));
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    touchStartXRef.current = null;
    touchStartYRef.current = null;
    if (e.touches.length < 2) {
      initialPinchDistanceRef.current = null;
    }
  };

  // Wheel navigation debounced for smooth reading without accidental page jumps
  const lastWheelTimeRef = useRef<number>(0);
  const handleWheel = (e: React.WheelEvent) => {
    // Page changes via mouse wheel / scroll in Fit Mode are disabled as requested
    // ("Fite mode up down scroll kar na sa page change horha hai")
    // Content simply scrolls naturally without turning pages
  };

  const handleViewportClick = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    if (
      target.closest('button') || 
      target.closest('input') || 
      target.closest('a') || 
      target.closest('.z-50') ||
      isClearingSelectionRef.current
    ) {
      return;
    }

    if (tooltip.visible) {
      resetSelectionState();
      return;
    }

    if (activePanel !== 'none') {
      setActivePanel('none');
      return;
    }

    // Edge tap navigation: Tapping on far right turns to Next Page; far left turns to Previous Page
    if (viewportContainerRef.current) {
      const rect = viewportContainerRef.current.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const width = rect.width;

      if (clickX > width * 0.82 && currentPage < totalPages) {
        handlePageNavigation(currentPage + 1);
        return;
      }
      if (clickX < width * 0.18 && currentPage > 1) {
        handlePageNavigation(currentPage - 1);
        return;
      }
    }

    // Center tap: Toggle controls visibility
    setShowControls(prev => !prev);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
        return;
      }
      
      if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        e.preventDefault();
        if (currentPage > 1) {
          handlePageNavigation(currentPage - 1);
        }
      } else if (e.key === 'ArrowRight' || e.key === 'PageDown') {
        e.preventDefault();
        if (totalPages > 0 && currentPage < totalPages) {
          handlePageNavigation(currentPage + 1);
        }
      } else if (e.key === 'Escape') {
        setShowControls(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentPage, totalPages, loading, activePanel, handlePageNavigation]);

  const toggleScrollMode = () => {
    setSettings(prev => ({
      ...prev,
      scrollMode: prev.scrollMode === 'vertical' ? 'continuous' : 'vertical'
    }));
  };

  const handleReaderModeChange = (mode: 'pdf' | 'reflow') => {
    setReaderMode(mode);
    localStorage.setItem('reader_mode', mode);
    if (mode === 'reflow' && !hasUsedReflow) {
      setHasUsedReflow(true);
      localStorage.setItem('has_used_reflow', 'true');
      setShowReflowTooltip(false);
      setShowReflowBanner(false);
    }
  };

  const handleTranslateFullPage = async () => {
    const cacheKey = `reader_page_trans_${currentPage}`;
    const cached = typeof window !== 'undefined' ? localStorage.getItem(cacheKey) : null;
    if (cached) {
      setFullPageTranslation(cached);
      setShowFullPageTranslation(true);
      return;
    }

    let textToTranslate = (extractedText || '').trim();
    if (!textToTranslate || textToTranslate.includes('This page has no selectable text')) {
      const spans = document.querySelectorAll('.textLayer span, .react-pdf__Page__textContent span, #document-alignment-container p, #reflow-content-container p');
      if (spans.length > 0) {
        textToTranslate = Array.from(spans).map(s => s.textContent || '').join(' ').trim();
      }
    }

    if (!textToTranslate) return;

    setIsTranslatingPage(true);
    try {
      const res = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textToTranslate, targetLang: 'hi' })
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.translatedText) {
          localStorage.setItem(cacheKey, data.translatedText);
          setFullPageTranslation(data.translatedText);
          setShowFullPageTranslation(true);
        }
      }
    } catch (e) {
      console.warn('Full page translation error:', e);
    } finally {
      setIsTranslatingPage(false);
    }
  };

  const handleToggleSpeakMode = async () => {
    console.log('[TTS] Play/Speak button clicked');
    unlockSpeechAudio();

    if (!isSpeakMode) {
      // Prime browser audio in current user gesture
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }
      }
      
      // If extractedText is empty, attempt DOM text recovery from textLayer or reflow container
      let textToUse = (extractedText || '').trim();
      if (!textToUse || textToUse.length === 0) {
        const spans = document.querySelectorAll('.textLayer span, .react-pdf__Page__textContent span, #document-alignment-container p, #reflow-content-container p, .reflow-text p, [data-page-number] span');
        if (spans.length > 0) {
          textToUse = Array.from(spans).map(s => s.textContent || '').join(' ').trim();
        }
      }

      // If still empty and PDF doc available, extract directly before mounting player
      if ((!textToUse || textToUse.length === 0) && pdf) {
        try {
          const pageObj = await pdf.getPage(currentPage);
          const tc = await pageObj.getTextContent();
          if (tc && tc.items) {
            const str = tc.items.map((i: any) => i.str || '').filter((s: string) => s.trim().length > 0).join(' ');
            if (str) {
              textToUse = str;
            }
          }
        } catch (e) {
          console.warn('PDF text extraction error:', e);
        }
      }

      // Fallback text if page has no selectable text (e.g. image-only cover)
      if (!textToUse || textToUse.trim().length === 0) {
        textToUse = `Page ${currentPage}: ${book.title || 'Book'}`;
      }

      setExtractedText(textToUse);
      setCustomTextForSpeak('');
      
      const detected = detectLanguage(textToUse);
      setSpeakLanguageHint(detected);
      setIsSpeakMode(true);
    } else {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setIsSpeakMode(false);
      setCustomTextForSpeak('');
      setSpeakLanguageHint(undefined);
      setCurrentSpokenSentence('');
    }
  };

  const tutorialContent = [
    {
      title: "📖 Reflow Text Mode",
      desc: "Makes PDF text easier to read on mobile screens by extracting text and reflowing it.",
      icon: <WrapText className="h-6 w-6 text-orange-500" />
    },
    {
      title: "🖍 Highlights",
      desc: "Select any text to highlight it. Save important ideas and insights instantly.",
      icon: <Highlighter className="h-6 w-6 text-orange-500" />
    },
    {
      title: "📑 Notes",
      desc: "Attach notes to your highlighted passages to capture your thoughts as you read.",
      icon: <FileText className="h-6 w-6 text-orange-500" />
    },
    {
      title: "🔍 Search",
      desc: "Find any word or phrase instantly inside the book using the powerful search tool.",
      icon: <Search className="h-6 w-6 text-orange-500" />
    }
  ];

  const getHighlightColorHex = (color: string) => {
    switch (color) {
      case 'yellow': return 'rgba(253, 224, 71, 0.45)';
      case 'green': return 'rgba(52, 211, 153, 0.45)';
      case 'blue': return 'rgba(96, 165, 250, 0.45)';
      case 'pink': return 'rgba(244, 114, 182, 0.45)';
      case 'orange': return 'rgba(251, 146, 60, 0.45)';
      default: return 'rgba(253, 224, 71, 0.45)';
    }
  };

  const pageMarginMode = settings.pageMargin || 'none';
  const pageFitMode = settings.pageFit || 'fit-page';
  const currentZoom = pageFitMode === 'fit-page' ? 1.0 : (settings.zoom || 1.0);

  const isMobile = windowWidth < 768;
  const isTablet = windowWidth >= 768 && windowWidth <= 1024;
  const isDesktop = windowWidth > 1024;
  const paddingLeftVal = pageMarginMode === 'none'
    ? '0px'
    : (pageMarginMode === 'compact' ? '6px' : (isMobile ? '12px' : '24px'));
  const paddingRightVal = pageMarginMode === 'none'
    ? '0px'
    : (pageMarginMode === 'compact' ? '6px' : (isMobile ? '12px' : '24px'));
  const paddingTopVal = focusMode
    ? `${Math.max(48, topBarHeight + 6)}px`
    : (showControls ? `${topBarHeight + 8}px` : '0px');
  const paddingBottomVal = isSpeakMode
    ? '280px'
    : (showControls ? '100px' : (focusMode ? '24px' : '0px'));

  const dismissOnboarding = () => {
    setHasUsedReflow(true);
    localStorage.setItem('has_used_reflow', 'true');
    setShowReflowTooltip(false);
    setShowReflowBanner(false);
  };

  const isDark = theme === 'dark';
  const isSepia = false; 
  const isLight = theme === 'light';

  const getThemeColors = () => {
    if (isDark) return 'border-white/10 bg-[#0D0D0D]/95 text-[#E0E0E0]';
    if (isSepia) return 'border-[#E2D1B3] bg-[#F4ECD8]/95 text-[#5B4636]';
    return 'border-slate-200 bg-white/95 text-slate-800';
  };

  const getReaderBg = () => {
    if (isDark) return 'bg-[#121212]';
    if (isSepia) return 'bg-[#FAF3E0]';
    return 'bg-[#F6F4EF]';
  };

  const getPageBg = () => {
    if (isDark) return 'bg-[#181818]';
    if (isSepia) return 'bg-[#FDF6E3]';
    return 'bg-white';
  };

  const renderSettingsPopover = () => {
    if (!showTextSettings) return null;
    return (
      <div className={`absolute right-0 top-12 z-[100] w-72 max-w-[calc(100vw-24px)] max-h-[80vh] overflow-y-auto rounded-2xl border p-4.5 shadow-2xl backdrop-blur-md transition-all duration-300 ${
        isDark ? 'border-white/10 bg-[#0D0D0D]/95 text-[#E0E0E0]' : (isSepia ? 'border-[#E2D1B3] bg-[#FAF3E0]/95 text-[#5B4636]' : 'border-slate-200 bg-white/95 text-slate-800')
      }`}>
        <h4 className={`text-[10px] font-bold uppercase tracking-wider mb-3.5 ${
          isDark ? 'text-white/40' : (isSepia ? 'text-[#5B4636]/60' : 'text-slate-400')
        }`}>Reader Settings</h4>
        
        <div className="space-y-4">
          {/* Reading Modes Selector */}
          <div className="mb-4">
            <label className={`text-[9px] uppercase tracking-widest font-semibold mb-1.5 block ${
              isDark ? 'text-white/40' : (isSepia ? 'text-[#5B4636]/60' : 'text-slate-400')
            }`}>Reading Mode</label>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={() => {
                  setSettings(prev => ({ ...prev, pageFit: 'original', zoom: 1.0 }));
                  handleReaderModeChange('pdf');
                }}
                className={`p-2 text-left rounded-lg border transition-all cursor-pointer ${
                  readerMode === 'pdf' && settings.pageFit === 'original'
                    ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-bold'
                    : isDark ? 'border-white/5 hover:bg-white/5 text-slate-300' : 'border-slate-100 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div className="text-[11px] font-semibold flex items-center gap-1">
                  <span>📄 Original PDF</span>
                </div>
                <div className="text-[8px] opacity-70">Original PDF layout</div>
              </button>

              <button
                onClick={() => {
                  setSettings(prev => ({ ...prev, pageFit: 'fit-width', zoom: 1.0 }));
                  handleReaderModeChange('pdf');
                }}
                className={`p-2 text-left rounded-lg border transition-all cursor-pointer ${
                  readerMode === 'pdf' && (settings.pageFit || 'fit-width') === 'fit-width'
                    ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-bold'
                    : isDark ? 'border-white/5 hover:bg-white/5 text-slate-300' : 'border-slate-100 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div className="text-[11px] font-semibold flex items-center gap-1">
                  <span>↔️ Fit Width</span>
                </div>
                <div className="text-[8px] opacity-70">Edge-to-edge</div>
              </button>

              <button
                onClick={() => {
                  setSettings(prev => ({ ...prev, pageFit: 'fit-page', zoom: 1.0 }));
                  handleReaderModeChange('pdf');
                }}
                className={`p-2 text-left rounded-lg border transition-all cursor-pointer ${
                  readerMode === 'pdf' && settings.pageFit === 'fit-page'
                    ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-bold'
                    : isDark ? 'border-white/5 hover:bg-white/5 text-slate-300' : 'border-slate-100 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div className="text-[11px] font-semibold flex items-center gap-1">
                  <span>📱 Single Page</span>
                </div>
                <div className="text-[8px] opacity-70">Fit whole page</div>
              </button>

              <button
                onClick={() => {
                  setSettings(prev => ({ ...prev, scrollMode: prev.scrollMode === 'continuous' ? 'vertical' : 'continuous' }));
                  handleReaderModeChange('pdf');
                }}
                className={`p-2 text-left rounded-lg border transition-all cursor-pointer ${
                  readerMode === 'pdf' && settings.scrollMode === 'continuous'
                    ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-bold'
                    : isDark ? 'border-white/5 hover:bg-white/5 text-slate-300' : 'border-slate-100 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div className="text-[11px] font-semibold flex items-center gap-1">
                  <span>📜 Continuous</span>
                </div>
                <div className="text-[8px] opacity-70">{settings.scrollMode === 'continuous' ? 'Scroll Active' : 'Vertical Pages'}</div>
              </button>

              <button
                onClick={() => {
                  setSettings(prev => ({ ...prev, pageFit: 'two-page', zoom: 1.0 }));
                  handleReaderModeChange('pdf');
                }}
                className={`p-2 text-left rounded-lg border transition-all cursor-pointer ${
                  readerMode === 'pdf' && settings.pageFit === 'two-page'
                    ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-bold'
                    : isDark ? 'border-white/5 hover:bg-white/5 text-slate-300' : 'border-slate-100 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div className="text-[11px] font-semibold flex items-center gap-1">
                  <span>📖 Two Page</span>
                </div>
                <div className="text-[8px] opacity-70">Side-by-side view</div>
              </button>

              <button
                onClick={() => handleReaderModeChange('reflow')}
                className={`p-2 text-left rounded-lg border transition-all cursor-pointer ${
                  readerMode === 'reflow'
                    ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-bold'
                    : isDark ? 'border-white/5 hover:bg-white/5 text-slate-300' : 'border-slate-100 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div className="text-[11px] font-semibold flex items-center gap-1">
                  <span>✨ Reflow Mode</span>
                </div>
                <div className="text-[8px] opacity-70">Mobile text reflow</div>
              </button>
            </div>
          </div>

          {readerMode === 'pdf' && (
            <>
              {/* PDF Screen Fit & Margins (Side Space Control) */}
              <div className="mb-4">
                <label className={`text-[9px] uppercase tracking-widest font-semibold mb-1.5 block ${
                  isDark ? 'text-white/40' : (isSepia ? 'text-[#5B4636]/60' : 'text-slate-400')
                }`}>Page Width & Margins (Side Space)</label>
                <div className="grid grid-cols-3 gap-1">
                  {[
                    { id: 'none', label: 'Full Width', sub: 'No Margins', fit: 'fit-width', margin: 'none' },
                    { id: 'compact', label: 'Compact', sub: 'Minimal', fit: 'fit-width', margin: 'compact' },
                    { id: 'page', label: 'Fit Page', sub: 'Whole Page', fit: 'fit-page', margin: 'compact' },
                  ].map(opt => {
                    const isSelected = opt.fit === 'fit-page'
                      ? (settings.pageFit === 'fit-page')
                      : ((settings.pageFit || 'fit-width') === 'fit-width' && (settings.pageMargin || 'none') === opt.margin);
                    return (
                      <button
                        key={opt.id}
                        onClick={() => {
                          setSettings(prev => ({
                            ...prev,
                            pageFit: opt.fit as any,
                            pageMargin: opt.margin as any,
                            zoom: 1.0
                          }));
                        }}
                        className={`px-1.5 py-2 text-center rounded-lg border transition-all cursor-pointer flex flex-col items-center justify-center ${
                          isSelected
                            ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-bold'
                            : isDark
                              ? 'border-white/5 hover:bg-white/5 text-slate-300'
                              : (isSepia ? 'border-[#E2D1B3] hover:bg-[#5B4636]/5 text-[#5B4636]' : 'border-slate-100 hover:bg-slate-50 text-slate-700')
                        }`}
                      >
                        <span className="text-[11px] leading-tight font-semibold">{opt.label}</span>
                        <span className="text-[8px] opacity-70 leading-tight">{opt.sub}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* PDF Zoom & Scale */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-1.5">
                  <label className={`text-[9px] uppercase tracking-widest font-semibold ${
                    isDark ? 'text-white/40' : (isSepia ? 'text-[#5B4636]/60' : 'text-slate-400')
                  }`}>Zoom & Scale</label>
                  <span className="text-[10px] font-mono font-bold text-orange-500">
                    {Math.round((settings.zoom || 1.0) * 100)}%
                  </span>
                </div>
                
                <div className="flex items-center gap-2 mb-2">
                  <button
                    onClick={() => handleZoomChange(-0.1)}
                    className={`flex-1 py-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                      isDark ? 'border-white/10 hover:bg-white/5 text-slate-300' : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                    title="Zoom Out (-10%)"
                  >
                    <ZoomOut className="h-3.5 w-3.5" />
                    <span>Zoom Out</span>
                  </button>
                  <button
                    onClick={handleResetZoom}
                    className={`px-3 py-1.5 rounded-lg border text-[11px] font-semibold transition-all cursor-pointer ${
                      (settings.zoom || 1.0) === 1.0 && (settings.pageMargin || 'none') === 'none'
                        ? 'border-orange-500 bg-orange-500/10 text-orange-500'
                        : isDark ? 'border-white/10 hover:bg-white/5 text-slate-400' : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                    title="Reset to Fit Width"
                  >
                    100%
                  </button>
                  <button
                    onClick={() => handleZoomChange(0.1)}
                    className={`flex-1 py-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                      isDark ? 'border-white/10 hover:bg-white/5 text-slate-300' : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                    title="Zoom In (+10%)"
                  >
                    <ZoomIn className="h-3.5 w-3.5" />
                    <span>Zoom In</span>
                  </button>
                </div>

                <div className="grid grid-cols-4 gap-1">
                  {[
                    { label: 'Fit Width', zoom: 1.0 },
                    { label: '120%', zoom: 1.2 },
                    { label: '140%', zoom: 1.4 },
                    { label: '160%', zoom: 1.6 }
                  ].map(z => (
                    <button
                      key={z.label}
                      onClick={() => setSettings(prev => ({ ...prev, zoom: z.zoom }))}
                      className={`py-1 text-center text-[9px] font-mono rounded border transition-all cursor-pointer ${
                        Math.abs((settings.zoom || 1.0) - z.zoom) < 0.05
                          ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-bold'
                          : isDark ? 'border-white/5 hover:bg-white/5 text-slate-400' : 'border-slate-100 hover:bg-slate-50 text-slate-600'
                      }`}
                    >
                      {z.label}
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

          {readerMode === 'reflow' && (
            <>
              {/* Reflow Background Theme */}
              <div className="mb-4">
                <label className={`text-[9px] uppercase tracking-widest font-semibold mb-1.5 block ${
                  isDark ? 'text-white/40' : (isSepia ? 'text-[#5B4636]/60' : 'text-slate-400')
                }`}>Background Theme</label>
                <div className="grid grid-cols-4 gap-1">
                  {[
                    { id: 'light', label: 'Light', bg: 'bg-[#FAF8F5] text-slate-800' },
                    { id: 'dark', label: 'Dark', bg: 'bg-[#1C1C1C] text-white' },
                    { id: 'sepia', label: 'Sepia', bg: 'bg-[#FDF6E3] text-[#5B4636]' },
                    { id: 'amoled', label: 'AMOLED', bg: 'bg-black text-white' },
                  ].map(th => (
                    <button
                      key={th.id}
                      onClick={() => setSettings(prev => ({ ...prev, theme: th.id as any }))}
                      className={`px-1 py-1.5 text-center text-[10px] rounded-md border transition-all cursor-pointer font-bold ${
                        (settings.theme || 'light') === th.id
                          ? 'border-orange-500 ring-2 ring-orange-500/30 font-bold'
                          : isDark ? 'border-white/10 hover:bg-white/5' : 'border-slate-200 hover:bg-slate-100'
                      } ${th.bg}`}
                    >
                      {th.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Font Style Options */}
              <div className="mb-4">
                <label className={`text-[9px] uppercase tracking-widest font-semibold mb-1.5 block ${
                  isDark ? 'text-white/40' : (isSepia ? 'text-[#5B4636]/60' : 'text-slate-400')
                }`}>Font Style</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { id: 'sans', label: 'Inter Sans' },
                    { id: 'poppins', label: 'Poppins' },
                    { id: 'source', label: 'Source Sans' },
                    { id: 'serif', label: 'Serif (Georgia)' },
                    { id: 'mono', label: 'Clean Mono' }
                  ].map(f => (
                    <button
                      key={f.id}
                      onClick={() => setSettings(prev => ({ ...prev, fontFamily: f.id as any }))}
                      className={`px-2.5 py-1.5 text-left text-xs rounded-lg border transition-all cursor-pointer ${
                        (settings.fontFamily || 'sans') === f.id
                          ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-semibold'
                          : isDark
                            ? 'border-white/5 hover:bg-white/5 text-slate-300'
                            : (isSepia ? 'border-[#E2D1B3] hover:bg-[#5B4636]/5 text-[#5B4636]' : 'border-slate-100 hover:bg-slate-50 text-slate-700')
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Font Size Scale Selector */}
              <div className="mb-4">
                <label className={`text-[9px] uppercase tracking-widest font-semibold mb-1.5 block ${
                  isDark ? 'text-white/40' : (isSepia ? 'text-[#5B4636]/60' : 'text-slate-400')
                }`}>Text Size</label>
                <div className="grid grid-cols-4 gap-1">
                  {[
                    { id: 'xs', label: 'XS' },
                    { id: 'sm', label: 'SM' },
                    { id: 'md', label: 'Normal' },
                    { id: 'lg', label: 'LG' },
                    { id: 'xl', label: 'XL' },
                    { id: '2xl', label: '2XL' },
                    { id: '3xl', label: '3XL' }
                  ].map(s => (
                    <button
                      key={s.id}
                      onClick={() => setSettings(prev => ({ ...prev, fontSize: s.id as any }))}
                      className={`px-1 py-1.5 text-center text-[10px] rounded-md border transition-all cursor-pointer ${
                        (settings.fontSize || 'md') === s.id
                          ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-semibold'
                          : isDark
                            ? 'border-white/5 hover:bg-white/5 text-slate-300'
                            : (isSepia ? 'border-[#E2D1B3] hover:bg-[#5B4636]/5 text-[#5B4636]' : 'border-slate-100 hover:bg-slate-50 text-slate-700')
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Line Height Selector */}
              <div className="mb-4">
                <label className={`text-[9px] uppercase tracking-widest font-semibold mb-1.5 block ${
                  isDark ? 'text-white/40' : (isSepia ? 'text-[#5B4636]/60' : 'text-slate-400')
                }`}>Line Spacing</label>
                <div className="grid grid-cols-4 gap-1">
                  {[
                    { id: 'tight', label: 'Tight' },
                    { id: 'normal', label: 'Normal' },
                    { id: 'relaxed', label: 'Relaxed' },
                    { id: 'loose', label: 'Loose' }
                  ].map(lh => (
                    <button
                      key={lh.id}
                      onClick={() => setSettings(prev => ({ ...prev, lineHeight: lh.id as any }))}
                      className={`px-1 py-1.5 text-center text-[10px] rounded-md border transition-all cursor-pointer ${
                        (settings.lineHeight || 'relaxed') === lh.id
                          ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-semibold'
                          : isDark
                            ? 'border-white/5 hover:bg-white/5 text-slate-300'
                            : (isSepia ? 'border-[#E2D1B3] hover:bg-[#5B4636]/5 text-[#5B4636]' : 'border-slate-100 hover:bg-slate-50 text-slate-700')
                      }`}
                    >
                      {lh.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Letter Spacing Selector */}
              <div className="mb-4">
                <label className={`text-[9px] uppercase tracking-widest font-semibold mb-1.5 block ${
                  isDark ? 'text-white/40' : (isSepia ? 'text-[#5B4636]/60' : 'text-slate-400')
                }`}>Letter Spacing</label>
                <div className="grid grid-cols-4 gap-1">
                  {[
                    { id: 'tight', label: 'Tight' },
                    { id: 'normal', label: 'Normal' },
                    { id: 'wide', label: 'Wide' },
                    { id: 'wider', label: 'Wider' }
                  ].map(ls => (
                    <button
                      key={ls.id}
                      onClick={() => setSettings(prev => ({ ...prev, letterSpacing: ls.id as any }))}
                      className={`px-1 py-1.5 text-center text-[10px] rounded-md border transition-all cursor-pointer ${
                        (settings.letterSpacing || 'normal') === ls.id
                          ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-semibold'
                          : isDark
                            ? 'border-white/5 hover:bg-white/5 text-slate-300'
                            : (isSepia ? 'border-[#E2D1B3] hover:bg-[#5B4636]/5 text-[#5B4636]' : 'border-slate-100 hover:bg-slate-50 text-slate-700')
                      }`}
                    >
                      {ls.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Text Alignment Selector */}
              <div className="mb-4">
                <label className={`text-[9px] uppercase tracking-widest font-semibold mb-1.5 block ${
                  isDark ? 'text-white/40' : (isSepia ? 'text-[#5B4636]/60' : 'text-slate-400')
                }`}>Text Alignment</label>
                <div className="grid grid-cols-3 gap-1">
                  {[
                    { id: 'left', label: 'Left', icon: AlignLeft },
                    { id: 'justify', label: 'Justify', icon: AlignJustify },
                    { id: 'center', label: 'Center', icon: AlignCenter },
                  ].map(al => {
                    const IconComp = al.icon;
                    return (
                      <button
                        key={al.id}
                        onClick={() => setSettings(prev => ({ ...prev, textAlign: al.id as any }))}
                        className={`px-2 py-1.5 flex items-center justify-center gap-1.5 rounded-md border text-[11px] transition-all cursor-pointer ${
                          (settings.textAlign || 'left') === al.id
                            ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-semibold'
                            : isDark
                              ? 'border-white/5 hover:bg-white/5 text-slate-300'
                              : (isSepia ? 'border-[#E2D1B3] hover:bg-[#5B4636]/5 text-[#5B4636]' : 'border-slate-100 hover:bg-slate-50 text-slate-700')
                        }`}
                      >
                        <IconComp className="h-3 w-3" />
                        <span>{al.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Margins Selector */}
              <div className="mb-4">
                <label className={`text-[9px] uppercase tracking-widest font-semibold mb-1.5 block ${
                  isDark ? 'text-white/40' : (isSepia ? 'text-[#5B4636]/60' : 'text-slate-400')
                }`}>Margins</label>
                <div className="grid grid-cols-4 gap-1">
                  {[
                    { id: 'none', label: 'None' },
                    { id: 'compact', label: 'Compact' },
                    { id: 'normal', label: 'Normal' },
                    { id: 'spacious', label: 'Spacious' }
                  ].map(mg => (
                    <button
                      key={mg.id}
                      onClick={() => setSettings(prev => ({ ...prev, pageMargin: mg.id as any }))}
                      className={`px-1 py-1.5 text-center text-[10px] rounded-md border transition-all cursor-pointer ${
                        (settings.pageMargin || 'none') === mg.id
                          ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-semibold'
                          : isDark
                            ? 'border-white/5 hover:bg-white/5 text-slate-300'
                            : (isSepia ? 'border-[#E2D1B3] hover:bg-[#5B4636]/5 text-[#5B4636]' : 'border-slate-100 hover:bg-slate-50 text-slate-700')
                      }`}
                    >
                      {mg.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reading Column Width */}
              <div className="mb-4">
                <label className={`text-[9px] uppercase tracking-widest font-semibold mb-1.5 block ${
                  isDark ? 'text-white/40' : (isSepia ? 'text-[#5B4636]/60' : 'text-slate-400')
                }`}>Reading column width</label>
                <div className="grid grid-cols-4 gap-1">
                  {[
                    { id: 'narrow', label: 'Narrow' },
                    { id: 'normal', label: 'Normal' },
                    { id: 'wide', label: 'Wide' },
                    { id: 'full', label: 'Full' }
                  ].map(rw => (
                    <button
                      key={rw.id}
                      onClick={() => setSettings(prev => ({ ...prev, readingWidth: rw.id as any }))}
                      className={`px-1 py-1.5 text-center text-[10px] rounded-md border transition-all cursor-pointer ${
                        (settings.readingWidth || 'normal') === rw.id
                          ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-semibold'
                          : isDark
                            ? 'border-white/5 hover:bg-white/5 text-slate-300'
                            : (isSepia ? 'border-[#E2D1B3] hover:bg-[#5B4636]/5 text-[#5B4636]' : 'border-slate-100 hover:bg-slate-50 text-slate-700')
                      }`}
                    >
                      {rw.label}
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* Reset to Default */}
          <div className={`pt-2 border-t mt-2 ${isDark ? 'border-white/10' : (isSepia ? 'border-[#E2D1B3]' : 'border-slate-200')}`}>
            <button
              onClick={() => {
                setSettings({ zoom: 1.0, scrollMode: 'vertical', theme: 'light', fontFamily: 'sans', fontSize: 'md', lineHeight: 'relaxed', readingWidth: 'full', pageFit: 'fit-page', pageMargin: 'none' });
                localStorage.setItem('reader_fit_preference_v2', 'true');
                handleReaderModeChange('pdf');
                setShowTextSettings(false);
              }}
              className={`w-full py-2 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                isDark ? 'border-white/10 hover:bg-white/5 text-slate-300 hover:text-white' : (isSepia ? 'border-[#E2D1B3] hover:bg-[#FDF6E3]/50 text-[#5B4636]' : 'border-slate-200 hover:bg-slate-50 text-slate-600 hover:text-slate-900')
              }`}
            >
              Reset to Default Settings
            </button>
          </div>
        </div>
      </div>
    );
  };

  const renderMoreMenu = () => {
    if (!showMoreMenu) return null;
    return (
      <div className={`absolute right-0 top-12 z-[100] w-64 max-w-[calc(100vw-24px)] rounded-2xl border p-2 shadow-2xl backdrop-blur-md transition-all duration-300 ${
        isDark ? 'border-white/10 bg-[#0D0D0D]/95 text-[#E0E0E0]' : (isSepia ? 'border-[#E2D1B3] bg-[#FAF3E0]/95 text-[#5B4636]' : 'border-slate-200 bg-white/95 text-slate-800')
      }`}>
        <div className="flex flex-col gap-1">
          <button
            onClick={() => {
              console.log('Search clicked');
              setActivePanel(activePanel === 'search' ? 'none' : 'search');
              setShowMoreMenu(false);
            }}
            className={`flex items-center gap-3 w-full px-4 py-3 text-sm rounded-xl transition-all cursor-pointer ${
              activePanel === 'search' 
                ? 'bg-orange-600 text-white font-bold' 
                : isDark ? 'text-slate-300 hover:bg-white/5' : (isSepia ? 'text-[#5B4636] hover:bg-[#5B4636]/5' : 'text-slate-700 hover:bg-slate-50')
            }`}
          >
            <Search className="h-4.5 w-4.5" />
            <span>Search in Document</span>
          </button>

          <button
            onClick={() => {
              console.log('Bookmarks clicked');
              setActivePanel(activePanel === 'bookmarks' ? 'none' : 'bookmarks');
              setShowMoreMenu(false);
            }}
            className={`flex items-center gap-3 w-full px-4 py-3 text-sm rounded-xl transition-all cursor-pointer ${
              activePanel === 'bookmarks' 
                ? 'bg-orange-600 text-white font-bold' 
                : isDark ? 'text-slate-300 hover:bg-white/5' : (isSepia ? 'text-[#5B4636] hover:bg-[#5B4636]/5' : 'text-slate-700 hover:bg-slate-50')
            }`}
          >
            <Bookmark className="h-4.5 w-4.5" />
            <span>Bookmarks List</span>
          </button>

          <button
            onClick={() => {
              console.log('Reader Settings clicked');
              setShowTextSettings(true);
              setShowMoreMenu(false);
            }}
            className={`flex items-center gap-3 w-full px-4 py-3 text-sm rounded-xl transition-all cursor-pointer ${
              showTextSettings 
                ? 'bg-orange-600 text-white font-bold' 
                : isDark ? 'text-slate-300 hover:bg-white/5' : (isSepia ? 'text-[#5B4636] hover:bg-[#5B4636]/5' : 'text-slate-700 hover:bg-slate-50')
            }`}
          >
            <Sliders className="h-4.5 w-4.5" />
            <span>Reader Settings</span>
          </button>

          {readerMode === 'pdf' && (
            <div className={`flex items-center justify-between px-3 py-2 rounded-xl border my-0.5 ${
              isDark ? 'border-white/10 bg-white/5' : 'border-slate-200/80 bg-slate-50'
            }`}>
              <span className={`text-xs font-medium ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>Zoom</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleZoomChange(-0.1)}
                  className={`p-1.5 rounded-lg border text-xs cursor-pointer ${
                    isDark ? 'border-white/10 hover:bg-white/10 text-slate-300' : 'border-slate-200 hover:bg-slate-200 text-slate-700'
                  }`}
                  title="Zoom Out"
                >
                  <ZoomOut className="h-3.5 w-3.5" />
                </button>
                <span className="text-xs font-mono font-bold px-1 min-w-[42px] text-center text-orange-500">
                  {Math.round((settings.zoom || 1.0) * 100)}%
                </span>
                <button
                  onClick={() => handleZoomChange(0.1)}
                  className={`p-1.5 rounded-lg border text-xs cursor-pointer ${
                    isDark ? 'border-white/10 hover:bg-white/10 text-slate-300' : 'border-slate-200 hover:bg-slate-200 text-slate-700'
                  }`}
                  title="Zoom In"
                >
                  <ZoomIn className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          )}

          {readerMode === 'pdf' && (
            <button
              id="more-menu-fit-toggle-btn"
              onClick={() => {
                setSettings(prev => ({
                  ...prev,
                  pageFit: prev.pageFit === 'fit-page' ? 'fit-width' : 'fit-page',
                  zoom: 1.0
                }));
                localStorage.setItem('reader_fit_preference_v2', 'true');
                setShowMoreMenu(false);
              }}
              className={`flex items-center justify-between w-full px-4 py-3 text-sm rounded-xl transition-all cursor-pointer ${
                settings.pageFit === 'fit-page'
                  ? 'bg-orange-500/10 text-orange-500 font-bold border border-orange-500/20' 
                  : isDark ? 'text-slate-300 hover:bg-white/5' : (isSepia ? 'text-[#5B4636] hover:bg-[#5B4636]/5' : 'text-slate-700 hover:bg-slate-50')
              }`}
            >
              <div className="flex items-center gap-3">
                {settings.pageFit === 'fit-page' ? <Minimize2 className="h-4.5 w-4.5" /> : <Maximize2 className="h-4.5 w-4.5" />}
                <span>{settings.pageFit === 'fit-page' ? 'Poora Page (Fit Whole Page)' : 'Fit to Width (Poori Chaudai)'}</span>
              </div>
              <span className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded font-bold ${
                settings.pageFit === 'fit-page' ? 'bg-orange-500 text-white' : 'bg-slate-200 dark:bg-white/10 text-slate-600 dark:text-slate-300'
              }`}>
                {settings.pageFit === 'fit-page' ? 'Active' : 'Switch'}
              </span>
            </button>
          )}

          <button
            onClick={() => {
              console.log('Focus Mode clicked');
              const nextState = !focusMode;
              setFocusMode(nextState);
              if (nextState) {
                setShowControls(false);
                setActivePanel('none');
                setShowTextSettings(false);
              } else {
                setShowControls(true);
              }
              setShowMoreMenu(false);
            }}
            className={`flex items-center gap-3 w-full px-4 py-3 text-sm rounded-xl transition-all cursor-pointer ${
              focusMode 
                ? 'bg-orange-600 text-white font-bold' 
                : isDark ? 'text-slate-300 hover:bg-white/5' : (isSepia ? 'text-[#5B4636] hover:bg-[#5B4636]/5' : 'text-slate-700 hover:bg-slate-50')
            }`}
          >
            {focusMode ? <Eye className="h-4.5 w-4.5" /> : <EyeOff className="h-4.5 w-4.5" />}
            <span>{focusMode ? "Disable Focus Mode" : "Enable Focus Mode"}</span>
          </button>

          <button
            onClick={() => {
              console.log('Highlights clicked');
              setActivePanel(activePanel === 'highlights' ? 'none' : 'highlights');
              setShowMoreMenu(false);
            }}
            className={`flex items-center gap-3 w-full px-4 py-3 text-sm rounded-xl transition-all cursor-pointer ${
              activePanel === 'highlights' 
                ? 'bg-orange-600 text-white font-bold' 
                : isDark ? 'text-slate-300 hover:bg-white/5' : (isSepia ? 'text-[#5B4636] hover:bg-[#5B4636]/5' : 'text-slate-700 hover:bg-slate-50')
            }`}
          >
            <Highlighter className="h-4.5 w-4.5" />
            <span>Highlights</span>
          </button>

          <button
            onClick={() => {
              console.log('Notes clicked');
              setActivePanel(activePanel === 'notes' ? 'none' : 'notes');
              setShowMoreMenu(false);
            }}
            className={`flex items-center gap-3 w-full px-4 py-3 text-sm rounded-xl transition-all cursor-pointer ${
              activePanel === 'notes' 
                ? 'bg-orange-600 text-white font-bold' 
                : isDark ? 'text-slate-300 hover:bg-white/5' : (isSepia ? 'text-[#5B4636] hover:bg-[#5B4636]/5' : 'text-slate-700 hover:bg-slate-50')
            }`}
          >
            <FileText className="h-4.5 w-4.5" />
            <span>Notes & Annotations</span>
          </button>

          <button
            onClick={() => {
              setActivePanel(activePanel === 'annotations' ? 'none' : 'annotations');
              setShowMoreMenu(false);
            }}
            className={`flex items-center gap-3 w-full px-4 py-3 text-sm rounded-xl transition-all cursor-pointer ${
              activePanel === 'annotations' 
                ? 'bg-orange-600 text-white font-bold' 
                : isDark ? 'text-slate-300 hover:bg-white/5' : (isSepia ? 'text-[#5B4636] hover:bg-[#5B4636]/5' : 'text-slate-700 hover:bg-slate-50')
            }`}
          >
            <FileText className="h-4.5 w-4.5 text-orange-500" />
            <span>All Annotations</span>
          </button>

          <button
            onClick={() => {
              console.log('Export Notes clicked');
              handleExportNotes();
              setShowMoreMenu(false);
            }}
            className={`flex items-center gap-3 w-full px-4 py-3 text-sm rounded-xl transition-all cursor-pointer ${
              isDark ? 'text-slate-300 hover:bg-white/5' : (isSepia ? 'text-[#5B4636] hover:bg-[#5B4636]/5' : 'text-slate-700 hover:bg-slate-50')
            }`}
          >
            <Download className="h-4.5 w-4.5" />
            <span>Export Notes & Highlights</span>
          </button>

          <button
            onClick={() => {
              console.log('Theme Toggle clicked');
              onToggleTheme();
              setShowMoreMenu(false);
            }}
            className={`flex items-center gap-3 w-full px-4 py-3 text-sm rounded-xl transition-all cursor-pointer ${
              isDark ? 'text-slate-300 hover:bg-white/5' : (isSepia ? 'text-[#5B4636] hover:bg-[#5B4636]/5' : 'text-slate-700 hover:bg-slate-50')
            }`}
          >
            {isDark ? <Sun className="h-4.5 w-4.5 text-orange-400" /> : <Moon className="h-4.5 w-4.5" />}
            <span>{isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}</span>
          </button>
        </div>
      </div>
    );
  };

  const renderTutorial = () => {
    if (!showTutorial) return null;
    const current = tutorialContent[tutorialStep];
    return (
      <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
        <div className={`w-full max-w-sm rounded-3xl p-8 shadow-2xl animate-in zoom-in-95 duration-300 ${
          isDark ? 'bg-[#1A1A1A] text-white border border-white/10' : (isSepia ? 'bg-[#FDF6E3] text-[#5B4636] border border-[#E2D1B3]' : 'bg-white text-slate-800')
        }`}>
          <div className="flex flex-col items-center text-center">
            <div className="mb-6 p-4 bg-orange-500/10 rounded-2xl">
              {current.icon}
            </div>
            <h3 className="text-xl font-bold mb-3">{current.title}</h3>
            <p className="text-sm opacity-70 leading-relaxed mb-8">
              {current.desc}
            </p>
            
            <div className="flex items-center gap-2 mb-8">
              {tutorialContent.map((_, i) => (
                <div 
                  key={i} 
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    i === tutorialStep ? 'w-8 bg-orange-600' : 'w-2 bg-slate-300 dark:bg-white/20'
                  }`}
                />
              ))}
            </div>

            <div className="flex w-full gap-3">
              <button 
                onClick={completeTutorial}
                className="flex-1 px-4 py-3 text-sm font-bold uppercase tracking-widest text-slate-500 hover:text-slate-800 dark:hover:text-white transition-colors"
              >
                Skip
              </button>
              <button 
                onClick={nextTutorial}
                className="flex-[2] px-6 py-3 bg-orange-600 text-white text-sm font-black uppercase tracking-widest rounded-xl shadow-lg shadow-orange-600/20 hover:bg-orange-700 transition-all active:scale-95"
              >
                {tutorialStep === tutorialContent.length - 1 ? "Get Started" : "Next Step"}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className={`fixed inset-0 z-50 flex flex-col font-sans transition-colors duration-300 ${
      isDark ? 'bg-[#0D0D0D] text-[#E0E0E0]' : (isSepia ? 'bg-[#FAF3E0] text-[#5B4636]' : 'bg-[#F6F4EF] text-slate-800')
    }`}>
      
      {/* Reader Header Toolbar */}
      <div 
        id="reader-top-bar"
        ref={topBarRef}
        className={`fixed top-0 left-0 right-0 z-40 border-b transition-all duration-300 transform backdrop-blur-xl ${
          focusMode ? 'h-12 flex items-center justify-between' : 'h-auto md:h-16 flex items-center justify-between'
        } ${
          focusMode 
            ? 'translate-y-0 opacity-100' 
            : (showControls ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0 pointer-events-none')
        } ${
          isDark ? 'border-white/10 bg-[#0D0D11]/90 text-[#E0E0E0]' : (isSepia ? 'border-[#E2D1B3] bg-[#FAF3E0]/90 text-[#5B4636]' : 'border-black/5 bg-white/95 text-slate-800 shadow-xs')
        }`}
        style={{
          paddingLeft: `max(${isTablet ? '1.5rem' : '0.5rem'}, env(safe-area-inset-left, 0px))`,
          paddingRight: `max(${isTablet ? '1.5rem' : '0.5rem'}, env(safe-area-inset-right, 0px))`,
          paddingTop: `max(0.375rem, env(safe-area-inset-top, 0px))`,
          paddingBottom: `0.375rem`,
        }}
      >
        {focusMode ? (
          <div className="flex w-full items-center justify-between h-full max-w-full">
            {/* Mobile Focus Mode (< md) */}
            <div className="flex md:hidden w-full items-center justify-between gap-1.5 h-full px-1 min-w-0">
              <div className="flex items-center gap-1.5 min-w-0 flex-1">
                <button
                  id="reader-exit-focus-btn-mobile"
                  onClick={() => {
                    setFocusMode(false);
                    setShowControls(true);
                  }}
                  className="p-1.5 rounded-full bg-orange-600 text-white shrink-0 shadow-xs cursor-pointer active:scale-95 touch-manipulation"
                  title="Exit Focus Mode"
                  aria-label="Exit Focus Mode"
                >
                  <Eye className="h-3.5 w-3.5" />
                </button>
                <span className={`text-xs font-bold truncate select-none ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
                  {book.title}
                </span>
              </div>

              {/* Page Nav */}
              <div className={`flex items-center gap-0.5 rounded-full p-0.5 border shrink-0 ${
                isDark ? 'border-white/10 bg-white/5' : 'border-slate-200 bg-slate-50'
              }`}>
                <button
                  onClick={() => handlePageNavigation(currentPage - 1)}
                  disabled={currentPage <= 1 || loading}
                  className="p-1 rounded-full disabled:opacity-30 cursor-pointer active:scale-90 touch-manipulation"
                  title="Previous Page"
                  aria-label="Previous Page"
                >
                  <ChevronLeft className="h-3.5 w-3.5" />
                </button>
                <span className="text-[10px] font-mono font-bold px-1.5 whitespace-nowrap">
                  {currentPage}/{totalPages || '?'}
                </span>
                <button
                  onClick={() => handlePageNavigation(currentPage + 1)}
                  disabled={currentPage >= totalPages || loading}
                  className="p-1 rounded-full disabled:opacity-30 cursor-pointer active:scale-90 touch-manipulation"
                  title="Next Page"
                  aria-label="Next Page"
                >
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={() => handleReaderModeChange(readerMode === 'pdf' ? 'reflow' : 'pdf')}
                  className={`p-1.5 rounded-full border cursor-pointer active:scale-95 touch-manipulation ${
                    readerMode === 'reflow' ? 'bg-orange-600 text-white border-orange-500' : (isDark ? 'border-white/10 text-slate-300' : 'border-slate-200 text-slate-700')
                  }`}
                  title="Toggle Reflow"
                  aria-label="Toggle Reflow"
                >
                  <WrapText className="h-3.5 w-3.5" />
                </button>
                <div className="relative">
                  <button
                    onClick={() => {
                      setShowMoreMenu(!showMoreMenu);
                      setShowTextSettings(false);
                    }}
                    className="p-1.5 rounded-full border border-slate-200 dark:border-white/10 cursor-pointer active:scale-95 touch-manipulation"
                    title="More"
                    aria-label="More Options"
                  >
                    <MoreVertical className="h-3.5 w-3.5" />
                  </button>
                  {renderMoreMenu()}
                  {renderSettingsPopover()}
                </div>
              </div>
            </div>

            {/* Desktop Focus Mode (>= md) */}
            <div className="hidden md:flex w-full items-center justify-between">
              {/* Left side: Book Title / Compact identifier */}
              <div className="flex items-center gap-2.5 min-w-0">
                <span className={`text-xs font-bold font-sans tracking-wide truncate max-w-[100px] sm:max-w-[200px] ${
                  isDark ? 'text-slate-400' : 'text-slate-600'
                }`}>
                  {book.title}
                </span>
                <span className={`text-[10px] font-mono tracking-wider font-semibold border px-1.5 py-0.5 rounded flex-shrink-0 ${
                  isDark ? 'border-orange-500/20 text-orange-400 bg-orange-950/20' : 'border-orange-200 text-orange-600 bg-orange-50'
                }`}>
                  Pg {currentPage}/{totalPages || '?'}
                </span>
              </div>

              {/* Right side: Toolbar buttons */}
              <div className="flex items-center gap-1 sm:gap-1.5">
                <button
                  id="reader-reflow-btn-focus"
                  onClick={() => handleReaderModeChange(readerMode === 'pdf' ? 'reflow' : 'pdf')}
                  className={`rounded-full p-2 sm:p-2.5 transition-all cursor-pointer border ${
                    readerMode === 'reflow' 
                      ? 'bg-orange-600 text-white font-bold border-orange-500' 
                      : isDark ? 'text-slate-400 border-white/5 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-700 border-slate-200 bg-white hover:bg-slate-100 hover:text-slate-900 shadow-xs')
                  }`}
                  title="Toggle Reflow Text"
                >
                  <WrapText className="h-4 w-4" />
                </button>

                {readerMode === 'pdf' && (
                  <button
                    id="reader-fit-btn-focus"
                    onClick={() => {
                      setSettings(prev => ({
                        ...prev,
                        pageFit: prev.pageFit === 'fit-page' ? 'fit-width' : 'fit-page',
                        zoom: 1.0
                      }));
                      localStorage.setItem('reader_fit_preference_v2', 'true');
                    }}
                    className={`rounded-full p-2 sm:p-2.5 transition-all cursor-pointer border flex items-center justify-center ${
                      settings.pageFit === 'fit-page'
                        ? 'bg-orange-600 text-white font-bold border-orange-500 shadow-xs' 
                        : isDark ? 'text-slate-400 border-white/5 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-700 border-slate-200 bg-white hover:bg-slate-100 hover:text-slate-900 shadow-xs')
                    }`}
                    title={settings.pageFit === 'fit-page' ? "Normal: Poora Page (Fit Page). Tap to Fit Width" : "Fit Width. Tap for Poora Page (Fit Page)"}
                  >
                    {settings.pageFit === 'fit-page' ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
                  </button>
                )}

                <button
                  onClick={handleToggleBookmark}
                  className={`rounded-full p-2 sm:p-2.5 transition-all cursor-pointer border ${
                    isCurrentPageBookmarked 
                      ? 'bg-orange-600 text-white font-bold border-orange-500' 
                      : isDark ? 'text-slate-400 border-white/5 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-700 border-slate-200 bg-white hover:bg-slate-100 hover:text-slate-900 shadow-xs')
                  }`}
                  title={isCurrentPageBookmarked ? "Remove Bookmark" : "Bookmark this Page"}
                >
                  <Bookmark className={`h-4 w-4 ${isCurrentPageBookmarked ? 'fill-current' : ''}`} />
                </button>

                <button
                  onClick={() => {
                    setActivePanel(activePanel === 'highlights' ? 'none' : 'highlights');
                    setShowTextSettings(false);
                    setShowMoreMenu(false);
                  }}
                  className={`rounded-full p-2 sm:p-2.5 transition-all cursor-pointer border ${
                    activePanel === 'highlights' 
                      ? 'bg-orange-600 text-white font-bold' 
                      : isDark ? 'text-slate-400 border-white/5 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-700 border-slate-200 bg-white hover:bg-slate-100 hover:text-slate-900 shadow-xs')
                  }`}
                  title="Highlights"
                >
                  <Highlighter className="h-4 w-4" />
                </button>

                <button
                  onClick={() => {
                    setActivePanel(activePanel === 'search' ? 'none' : 'search');
                    setShowTextSettings(false);
                    setShowMoreMenu(false);
                  }}
                  className={`rounded-full p-2 sm:p-2.5 transition-all cursor-pointer border ${
                    activePanel === 'search' 
                      ? 'bg-orange-600 text-white font-bold' 
                      : isDark ? 'text-slate-400 border-white/5 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-700 border-slate-200 bg-white hover:bg-slate-100 hover:text-slate-900 shadow-xs')
                  }`}
                  title="Find in Book"
                >
                  <Search className="h-4 w-4" />
                </button>

                {/* Overflow Menu for Focus Mode */}
                <div className="relative">
                  <button
                    onClick={() => {
                      setShowMoreMenu(!showMoreMenu);
                      setShowTextSettings(false);
                      setActivePanel('none');
                    }}
                    className={`rounded-full p-2 transition-all cursor-pointer border ${
                      showMoreMenu 
                        ? 'bg-orange-600 text-white' 
                        : isDark ? 'text-slate-400 border-white/5 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-500 border-slate-200 bg-white hover:bg-slate-100 hover:text-slate-900 shadow-sm')
                    }`}
                  >
                    <MoreVertical className="h-4.5 w-4.5" />
                  </button>
                  {renderMoreMenu()}
                  {renderSettingsPopover()}
                </div>

                <div className={`h-5 w-[1px] mx-1 ${isDark ? 'bg-white/10' : 'bg-slate-200'}`} />

                <button
                  id="reader-exit-focus-btn"
                  onClick={() => {
                    setFocusMode(false);
                    setShowControls(true);
                  }}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-orange-600 text-white hover:bg-orange-700 transition-all cursor-pointer shadow-md select-none shrink-0"
                  title="Exit Full Screen Mode"
                >
                  <Eye className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Exit Focus</span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="w-full max-w-full overflow-hidden">
            {/* 1. MOBILE RESPONSIVE TOOLBAR (< md) */}
            <div className="flex flex-col w-full md:hidden gap-1.5 py-0.5 max-w-full">
              {/* Row 1: Back + Title + Utilities (Reflow, Bookmark, Search, Highlights, More) */}
              <div className="flex items-center justify-between w-full min-w-0 gap-1 sm:gap-2">
                {/* Left: Back button & Title */}
                <div className="flex items-center gap-1 sm:gap-1.5 min-w-0 flex-1">
                  <button
                    id="reader-back-btn"
                    onClick={handleBackSafely}
                    className={`p-1.5 sm:p-2 rounded-full transition-colors cursor-pointer shrink-0 active:scale-95 touch-manipulation ${
                      isDark ? 'text-slate-300 hover:bg-white/10 active:bg-white/15' : 'text-slate-700 hover:bg-slate-100 active:bg-slate-200'
                    }`}
                    title="Back to Library"
                    aria-label="Back to Library"
                  >
                    <ArrowLeft className="h-4 w-4 sm:h-4.5 sm:w-4.5" />
                  </button>
                  <div className="min-w-0 flex-1 pr-1">
                    <h2 
                      className={`truncate font-sans font-bold text-xs sm:text-sm leading-tight select-none ${
                        isDark ? 'text-white' : (isSepia ? 'text-[#5B4636]' : 'text-slate-900')
                      }`}
                      title={book.title}
                    >
                      {book.title}
                    </h2>
                  </div>
                </div>

                {/* Right utility buttons: Reflow + Bookmark + Search + Highlights + More */}
                <div className="flex items-center gap-1 shrink-0">
                  {/* Reflow Toggle */}
                  <button
                    id="reader-reflow-btn"
                    onClick={() => handleReaderModeChange(readerMode === 'pdf' ? 'reflow' : 'pdf')}
                    className={`p-1.5 sm:p-2 rounded-full transition-all cursor-pointer border shrink-0 active:scale-95 touch-manipulation ${
                      readerMode === 'reflow' 
                        ? 'bg-orange-600 text-white border-orange-500 font-bold shadow-xs' 
                        : isDark ? 'text-slate-100 border-white/20 bg-white/10 hover:bg-white/20' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-900 border-slate-300 bg-white hover:bg-slate-100 shadow-2xs')
                    }`}
                    title="Toggle Reflow Text"
                    aria-label="Toggle Reflow Text"
                  >
                    <WrapText className="h-4 w-4 sm:h-4.5 sm:w-4.5" strokeWidth={2.2} />
                  </button>

                  {/* Bookmark Toggle */}
                  <button
                    id="reader-bookmark-btn"
                    onClick={handleToggleBookmark}
                    className={`p-1.5 sm:p-2 rounded-full transition-all cursor-pointer border shrink-0 active:scale-95 touch-manipulation ${
                      isCurrentPageBookmarked 
                        ? 'bg-orange-600 text-white border-orange-500 font-bold shadow-xs' 
                        : isDark ? 'text-slate-100 border-white/20 bg-white/10 hover:bg-white/20' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-900 border-slate-300 bg-white hover:bg-slate-100 shadow-2xs')
                    }`}
                    title={isCurrentPageBookmarked ? "Remove Bookmark" : "Bookmark this Page"}
                    aria-label="Bookmark this Page"
                  >
                    <Bookmark className={`h-4 w-4 sm:h-4.5 sm:w-4.5 ${isCurrentPageBookmarked ? 'fill-current' : ''}`} strokeWidth={2.2} />
                  </button>

                  {/* Search */}
                  <button
                    id="reader-search-btn"
                    onClick={() => {
                      if (searchQuery) {
                        setSearchQuery('');
                        setActivePanel('none');
                      } else {
                        setActivePanel(activePanel === 'search' ? 'none' : 'search');
                      }
                      setShowTextSettings(false);
                      setShowMoreMenu(false);
                    }}
                    className={`p-1.5 sm:p-2 rounded-full transition-all cursor-pointer border shrink-0 relative active:scale-95 touch-manipulation ${
                      activePanel === 'search' || searchQuery
                        ? 'bg-orange-600 text-white border-orange-500 font-bold shadow-xs' 
                        : isDark ? 'text-slate-100 border-white/20 bg-white/10 hover:bg-white/20' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-900 border-slate-300 bg-white hover:bg-slate-100 shadow-2xs')
                    }`}
                    title={searchQuery ? "Clear Search" : "Find in Book"}
                    aria-label="Find in Book"
                  >
                    {searchQuery ? <X className="h-4 w-4 sm:h-4.5 sm:w-4.5" strokeWidth={2.2} /> : <Search className="h-4 w-4 sm:h-4.5 sm:w-4.5" strokeWidth={2.2} />}
                  </button>

                  {/* Highlights */}
                  <button
                    id="reader-highlights-btn"
                    onClick={() => {
                      setActivePanel(activePanel === 'highlights' ? 'none' : 'highlights');
                      setShowTextSettings(false);
                      setShowMoreMenu(false);
                    }}
                    className={`p-1.5 sm:p-2 rounded-full transition-all cursor-pointer border shrink-0 active:scale-95 touch-manipulation ${
                      activePanel === 'highlights' 
                        ? 'bg-orange-600 text-white border-orange-500 font-bold shadow-xs' 
                        : isDark ? 'text-slate-100 border-white/20 bg-white/10 hover:bg-white/20' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-900 border-slate-300 bg-white hover:bg-slate-100 shadow-2xs')
                    }`}
                    title="Highlights"
                    aria-label="Highlights"
                  >
                    <Highlighter className="h-4 w-4 sm:h-4.5 sm:w-4.5" strokeWidth={2.2} />
                  </button>

                  {/* Mobile More Menu */}
                  <div className="relative shrink-0">
                    <button
                      id="reader-more-btn"
                      onClick={() => {
                        setShowMoreMenu(!showMoreMenu);
                        setShowTextSettings(false);
                        setActivePanel('none');
                      }}
                      className={`p-1.5 sm:p-2 rounded-full transition-all cursor-pointer border active:scale-95 touch-manipulation ${
                        showMoreMenu 
                          ? 'bg-orange-600 text-white border-orange-500 shadow-xs' 
                          : isDark ? 'text-slate-100 border-white/20 bg-white/10 hover:bg-white/20' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-900 border-slate-300 bg-white hover:bg-slate-100 shadow-2xs')
                      }`}
                      title="More Options"
                      aria-label="More Options"
                    >
                      <MoreVertical className="h-4 w-4 sm:h-4.5 sm:w-4.5" strokeWidth={2.2} />
                    </button>
                    {renderMoreMenu()}
                    {renderSettingsPopover()}
                  </div>
                </div>
              </div>

              {/* Row 2: Page Navigation + Action Controls (Fit, Speak, Hinglish) */}
              <div className="flex flex-wrap items-center justify-between w-full gap-x-2 gap-y-1.5 pt-1 border-t border-black/5 dark:border-white/5 min-w-0 max-w-full">
                {/* Dedicated Page Number & Navigation Pill */}
                <div className={`flex items-center gap-0.5 rounded-full p-0.5 border shadow-2xs shrink-0 max-w-full ${
                  isDark ? 'border-white/10 bg-white/5 text-slate-200' : 'border-slate-200/90 bg-slate-50 text-slate-800'
                }`}>
                  <button
                    id="mobile-prev-page-btn"
                    onClick={() => handlePageNavigation(currentPage - 1)}
                    disabled={currentPage <= 1 || loading}
                    className="p-1 sm:p-1.5 rounded-full hover:bg-black/5 dark:hover:bg-white/10 active:scale-90 transition-all disabled:opacity-25 disabled:pointer-events-none cursor-pointer touch-manipulation"
                    title="Previous Page"
                    aria-label="Previous Page"
                  >
                    <ChevronLeft className="h-3.5 w-3.5" />
                  </button>

                  <div 
                    id="mobile-page-number"
                    onClick={() => {
                      const input = window.prompt(`Go to page (1 - ${totalPages || 1}):`, `${currentPage}`);
                      if (input) {
                        const num = parseInt(input, 10);
                        if (!isNaN(num) && num >= 1 && num <= (totalPages || 1)) {
                          handlePageNavigation(num);
                        }
                      }
                    }}
                    className="px-1.5 sm:px-2 py-0.5 text-center cursor-pointer select-none active:opacity-75 transition-opacity"
                    title="Tap to jump to page"
                    role="button"
                    tabIndex={0}
                  >
                    <span className="text-[11px] sm:text-xs font-mono font-bold whitespace-nowrap tracking-tight">
                      {currentPage} <span className="opacity-40">/</span> {totalPages || '?'}
                    </span>
                  </div>

                  <button
                    id="mobile-next-page-btn"
                    onClick={() => handlePageNavigation(currentPage + 1)}
                    disabled={currentPage >= totalPages || loading}
                    className="p-1 sm:p-1.5 rounded-full hover:bg-black/5 dark:hover:bg-white/10 active:scale-90 transition-all disabled:opacity-25 disabled:pointer-events-none cursor-pointer touch-manipulation"
                    title="Next Page"
                    aria-label="Next Page"
                  >
                    <ChevronRight className="h-3.5 w-3.5" />
                  </button>
                </div>

                {/* Right Reading Action Tools */}
                <div className="flex items-center gap-1 sm:gap-1.5 shrink-0 min-w-0">
                  {/* Fit Mode Button in PDF mode */}
                  {readerMode === 'pdf' && (
                    <button
                      id="reader-fit-mode-btn"
                      onClick={() => {
                        setSettings(prev => ({
                          ...prev,
                          pageFit: prev.pageFit === 'fit-page' ? 'fit-width' : 'fit-page',
                          zoom: 1.0
                        }));
                        localStorage.setItem('reader_fit_preference_v2', 'true');
                      }}
                      className={`px-2 py-1 rounded-full text-[10px] sm:text-[11px] font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center gap-1 shrink-0 shadow-2xs active:scale-95 touch-manipulation ${
                        settings.pageFit === 'fit-page'
                          ? 'bg-orange-600 text-white border-orange-500'
                          : isDark ? 'text-slate-300 border-white/10 bg-white/5 hover:bg-white/10' : 'text-slate-700 border-slate-200 bg-white hover:bg-slate-100'
                      }`}
                      title={settings.pageFit === 'fit-page' ? "Normal: Poora Page (Fit Page). Tap to Fit Width" : "Fit Width. Tap for Poora Page"}
                    >
                      {settings.pageFit === 'fit-page' ? <Minimize2 className="h-3 w-3 shrink-0" /> : <Maximize2 className="h-3 w-3 shrink-0" />}
                      <span>{settings.pageFit === 'fit-page' ? 'Page' : 'Width'}</span>
                    </button>
                  )}

                  {/* Speak Mode Toggle */}
                  <button
                    id="reader-speak-btn"
                    onClick={handleToggleSpeakMode}
                    className={`px-2.5 py-1 rounded-full text-[10px] sm:text-[11px] font-bold uppercase tracking-wider transition-all cursor-pointer border-2 flex items-center gap-1.5 shrink-0 shadow-2xs active:scale-95 touch-manipulation ${
                      isSpeakMode 
                        ? 'bg-emerald-600 text-white border-emerald-400 font-bold shadow-emerald-600/30' 
                        : isDark ? 'text-emerald-400 border-emerald-500/40 bg-emerald-500/10 hover:bg-emerald-500/20' : 'text-emerald-700 border-emerald-600/30 bg-emerald-50 hover:bg-emerald-100'
                    }`}
                    title={isSpeakMode ? "Stop Speak Mode" : "Play / Suniye (Bol kar suniye)"}
                  >
                    {isSpeakMode ? (
                      <Volume2 className="h-3.5 w-3.5 shrink-0 text-white" strokeWidth={2.4} />
                    ) : (
                      <Play className="h-3.5 w-3.5 shrink-0 fill-current ml-0.5" strokeWidth={2.4} />
                    )}
                    <span>{isSpeakMode ? 'Speaking' : 'Play / Suno'}</span>
                  </button>

                  {/* Full Page Hindi Translation */}
                  <button
                    id="reader-full-page-trans-btn"
                    onClick={handleTranslateFullPage}
                    disabled={isTranslatingPage}
                    className={`px-2.5 py-1 rounded-full text-[10px] sm:text-[11px] font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center gap-1 shrink-0 shadow-2xs active:scale-95 touch-manipulation ${
                      showFullPageTranslation
                        ? 'bg-orange-600 text-white border-orange-600 font-bold shadow-orange-600/20'
                        : isDark ? 'text-orange-400 border-orange-500/30 bg-orange-500/10 hover:bg-orange-500/20' : 'text-orange-700 border-orange-200 bg-orange-50 hover:bg-orange-100'
                    }`}
                    title="Translate Full Page to Hindi (पूरा पेज अनुवाद)"
                  >
                    <BookOpen className="h-3 w-3 text-orange-500 shrink-0" />
                    <span>{isTranslatingPage ? 'Translating...' : 'Hindi Page'}</span>
                  </button>

                  {/* AI Hinglish Explainer */}
                  <button
                    id="reader-hinglish-btn"
                    onClick={() => {
                      setActivePanel(activePanel === 'hinglish' ? 'none' : 'hinglish');
                      setShowTextSettings(false);
                      setShowMoreMenu(false);
                    }}
                    className={`px-2.5 py-1 rounded-full text-[10px] sm:text-[11px] font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center gap-1 shrink-0 shadow-2xs active:scale-95 touch-manipulation ${
                      activePanel === 'hinglish' 
                        ? 'bg-amber-500 text-white border-amber-600 font-bold shadow-amber-500/20' 
                        : isDark ? 'text-amber-400 border-amber-500/20 bg-amber-500/5 hover:bg-amber-500/10' : (isSepia ? 'text-amber-700 border-[#E2D1B3] bg-amber-500/10' : 'text-amber-700 border-amber-200 bg-amber-50 hover:bg-amber-100')
                    }`}
                    title="AI Hinglish Explain & Summary"
                  >
                    <Languages className="h-3 w-3 text-amber-500 shrink-0" />
                    <span>Hinglish</span>
                  </button>
                </div>
              </div>
            </div>

            {/* 2. DESKTOP & TABLET TOOLBAR (>= md) */}
            <div className="hidden md:flex w-full items-center justify-between">
              <div className="flex items-center gap-2 sm:gap-4 min-w-0 mr-2">
                <button
                  id="reader-back-btn-desktop"
                  onClick={handleBackSafely}
                  className={`rounded-full p-2.5 sm:p-3 transition-colors cursor-pointer shrink-0 ${
                    isDark ? 'text-slate-400 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] hover:bg-[#5B4636]/5' : 'text-slate-500 hover:bg-slate-100 hover:text-slate-900')
                  }`}
                >
                  <ArrowLeft className="h-4.5 w-4.5" />
                </button>
                <div className="min-w-0">
                  <h2 className={`truncate font-sans font-bold text-sm max-w-[120px] sm:max-w-xs ${
                    isDark ? 'text-white' : (isSepia ? 'text-[#5B4636]' : 'text-slate-900')
                  }`}>{book.title}</h2>
                  <p className={`text-[10px] uppercase tracking-widest font-medium ${
                    isDark ? 'text-slate-500' : (isSepia ? 'text-[#5B4636]/60' : 'text-slate-400')
                  }`}>Page {currentPage} of {totalPages || '?'}</p>
                </div>
              </div>

              {/* Toolbar Controls */}
              <div className="flex items-center gap-1 sm:gap-2 md:gap-3">
                <div className="flex items-center gap-1 sm:gap-1.5">
                  <button
                    onClick={() => handleReaderModeChange(readerMode === 'pdf' ? 'reflow' : 'pdf')}
                    className={`rounded-full p-2.5 sm:p-3 transition-all cursor-pointer border ${
                      readerMode === 'reflow' 
                        ? 'bg-orange-600 text-white border-orange-500 font-bold' 
                        : isDark ? 'text-slate-400 border-white/5 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-500 border-slate-200 bg-white hover:bg-slate-100 hover:text-slate-900 shadow-sm')
                    }`}
                    title="Toggle Reflow Text"
                  >
                    <WrapText className="h-4 w-4 sm:h-4.5 sm:w-4.5" />
                  </button>

                  <button
                    onClick={handleToggleBookmark}
                    className={`rounded-full p-2.5 sm:p-3 transition-all cursor-pointer border ${
                      isCurrentPageBookmarked 
                        ? 'bg-orange-600 text-white border-orange-500 font-bold' 
                        : isDark ? 'text-slate-400 border-white/5 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-500 border-slate-200 bg-white hover:bg-slate-100 hover:text-slate-900 shadow-sm')
                    }`}
                    title={isCurrentPageBookmarked ? "Remove Bookmark" : "Bookmark this Page"}
                  >
                    <Bookmark className={`h-4 w-4 sm:h-4.5 sm:w-4.5 ${isCurrentPageBookmarked ? 'fill-current' : ''}`} />
                  </button>

                  <button
                    onClick={() => {
                      setActivePanel(activePanel === 'highlights' ? 'none' : 'highlights');
                      setShowTextSettings(false);
                      setShowMoreMenu(false);
                    }}
                    className={`rounded-full p-2.5 sm:p-3 transition-all cursor-pointer border ${
                      activePanel === 'highlights' 
                        ? 'bg-orange-600 text-white border-orange-500 font-bold' 
                        : isDark ? 'text-slate-400 border-white/5 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-500 border-slate-200 bg-white hover:bg-slate-100 hover:text-slate-900 shadow-sm')
                    }`}
                    title="Highlights"
                  >
                    <Highlighter className="h-4 w-4 sm:h-4.5 sm:w-4.5" />
                  </button>

                  <button
                    onClick={() => {
                      if (searchQuery) {
                        setSearchQuery('');
                        setActivePanel('none');
                      } else {
                        setActivePanel(activePanel === 'search' ? 'none' : 'search');
                      }
                      setShowTextSettings(false);
                      setShowMoreMenu(false);
                    }}
                    className={`rounded-full p-2.5 sm:p-3 transition-all cursor-pointer border relative ${
                      activePanel === 'search' || searchQuery
                        ? 'bg-orange-600 text-white border-orange-500 font-bold' 
                        : isDark ? 'text-slate-400 border-white/5 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-500 border-slate-200 bg-white hover:bg-slate-100 hover:text-slate-900 shadow-sm')
                    }`}
                    title={searchQuery ? "Clear Search" : "Find in Book"}
                  >
                    {searchQuery ? <X className="h-4 w-4 sm:h-4.5 sm:w-4.5" /> : <Search className="h-4 w-4 sm:h-4.5 sm:w-4.5" />}
                  </button>
                </div>

                {/* Desktop Zoom & Controls */}
                <div className="flex items-center gap-1.5 md:gap-3">
                  <div className={`h-6 w-[1px] mx-1 ${isDark ? 'bg-white/5' : 'bg-slate-200'}`} />
                  
                  {readerMode === 'pdf' && (
                    <div className={`flex items-center gap-1 px-2 py-1 rounded-full border ${
                      isDark ? 'border-white/10 bg-white/5' : 'border-slate-200 bg-slate-50'
                    }`}>
                      <button
                        onClick={() => handleZoomChange(-0.1)}
                        className={`p-1.5 rounded-full transition-colors cursor-pointer ${
                          isDark ? 'hover:bg-white/10 text-slate-400 hover:text-white' : 'hover:bg-slate-200 text-slate-600'
                        }`}
                        title="Zoom Out (-10%)"
                      >
                        <ZoomOut className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={handleResetZoom}
                        className={`px-2 py-0.5 text-[10px] font-mono font-bold rounded transition-colors cursor-pointer ${
                          pageFitMode === 'fit-page'
                            ? 'text-orange-500 bg-orange-500/10 font-bold'
                            : isDark ? 'hover:bg-white/10 text-slate-300' : 'hover:bg-slate-200 text-slate-700'
                        }`}
                        title={pageFitMode === 'fit-page' ? "Poora Page Mode: 100% Fit" : "Reset Zoom to Poora Page (100%)"}
                      >
                        {pageFitMode === 'fit-page' ? 'Fit Page' : `${Math.round(currentZoom * 100)}%`}
                      </button>
                      <button
                        onClick={() => handleZoomChange(0.1)}
                        className={`p-1.5 rounded-full transition-colors cursor-pointer ${
                          isDark ? 'hover:bg-white/10 text-slate-400 hover:text-white' : 'hover:bg-slate-200 text-slate-600'
                        }`}
                        title="Zoom In (+10%)"
                      >
                        <ZoomIn className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  )}

                  {readerMode === 'pdf' && (
                    <button
                      id="desktop-fit-mode-btn"
                      onClick={() => {
                        setSettings(prev => ({
                          ...prev,
                          pageFit: prev.pageFit === 'fit-page' ? 'fit-width' : 'fit-page',
                          zoom: 1.0
                        }));
                        localStorage.setItem('reader_fit_preference_v2', 'true');
                      }}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all cursor-pointer ${
                        settings.pageFit === 'fit-page'
                          ? 'bg-orange-600 text-white border-orange-500 shadow-xs'
                          : isDark ? 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10' : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                      }`}
                      title={settings.pageFit === 'fit-page' ? "Currently: Poora Page (Fit Page). Tap to Switch to Fit Width" : "Currently: Fit Width. Tap to Switch to Poora Page"}
                    >
                      {settings.pageFit === 'fit-page' ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
                      <span>{settings.pageFit === 'fit-page' ? 'Poora Page' : 'Fit Width'}</span>
                    </button>
                  )}

                  <button
                    id="desktop-speak-btn"
                    onClick={handleToggleSpeakMode}
                    className={`flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold border-2 transition-all cursor-pointer shadow-xs ${
                      isSpeakMode
                        ? 'bg-emerald-600 text-white border-emerald-400 font-bold shadow-emerald-600/30'
                        : isDark ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20' : 'border-emerald-600/30 bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                    }`}
                    title={isSpeakMode ? "Stop Speak Mode" : "Play / Suniye (Bol kar suniye)"}
                  >
                    {isSpeakMode ? (
                      <Volume2 className="h-4 w-4 text-white" strokeWidth={2.4} />
                    ) : (
                      <Play className="h-4 w-4 fill-current ml-0.5" strokeWidth={2.4} />
                    )}
                    <span>{isSpeakMode ? 'Speaking' : 'Play / Suniye'}</span>
                  </button>

                  {/* Full Page Hindi Translation */}
                  <button
                    id="desktop-full-page-trans-btn"
                    onClick={handleTranslateFullPage}
                    disabled={isTranslatingPage}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all cursor-pointer shadow-xs ${
                      showFullPageTranslation
                        ? 'bg-orange-600 text-white border-orange-600 font-bold shadow-orange-600/20'
                        : isDark ? 'text-orange-400 border-orange-500/30 bg-orange-500/10 hover:bg-orange-500/20' : 'text-orange-700 border-orange-200 bg-orange-50 hover:bg-orange-100'
                    }`}
                    title="Translate Full Page into Hindi (पूरा पेज अनुवाद)"
                  >
                    <BookOpen className="h-3.5 w-3.5 text-orange-500 shrink-0" />
                    <span>{isTranslatingPage ? 'Translating...' : 'Hindi Page'}</span>
                  </button>

                  <button
                    id="desktop-hinglish-btn"
                    onClick={() => {
                      setActivePanel(activePanel === 'hinglish' ? 'none' : 'hinglish');
                      setShowTextSettings(false);
                      setShowMoreMenu(false);
                    }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all cursor-pointer shadow-xs ${
                      activePanel === 'hinglish'
                        ? 'bg-amber-500 text-white border-amber-600 font-bold shadow-amber-500/20'
                        : isDark ? 'text-amber-400 border-amber-500/20 bg-amber-500/5 hover:bg-amber-500/10' : 'text-amber-700 border-amber-200 bg-amber-50 hover:bg-amber-100'
                    }`}
                    title="AI Hinglish Explain & Summary"
                  >
                    <Languages className="h-3.5 w-3.5 text-amber-500 shrink-0" />
                    <span>Hinglish</span>
                  </button>
                  
                  <button
                    onClick={() => {
                      setActivePanel(activePanel === 'notes' ? 'none' : 'notes');
                      setShowTextSettings(false);
                      setShowMoreMenu(false);
                    }}
                    className={`rounded-full p-3 transition-all cursor-pointer ${
                      activePanel === 'notes' 
                        ? 'bg-orange-600 text-white' 
                        : isDark ? 'text-slate-400 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] hover:bg-[#5B4636]/5' : 'text-slate-500 hover:bg-slate-100 hover:text-slate-900')
                    }`}
                    title="Notes"
                  >
                    <FileText className="h-4 w-4" />
                  </button>

                  <div className="relative">
                    <button
                      onClick={() => {
                        setShowTextSettings(!showTextSettings);
                        setActivePanel('none');
                      }}
                      className={`rounded-full p-3 transition-all cursor-pointer border ${
                        showTextSettings 
                          ? 'bg-orange-600 text-white border-orange-500' 
                          : isDark ? 'text-slate-400 border-white/5 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] border-[#E2D1B3] bg-[#FDF6E3] hover:bg-[#E2D1B3]' : 'text-slate-500 border-slate-200 bg-white hover:bg-slate-100 hover:text-slate-900 shadow-sm')
                      }`}
                      title="Reader Settings"
                    >
                      <Sliders className="h-4 w-4" />
                    </button>
                    {renderSettingsPopover()}
                  </div>

                  <button
                    onClick={() => {
                      setFocusMode(!focusMode);
                      setShowControls(!focusMode ? false : true);
                      setActivePanel('none');
                      setShowTextSettings(false);
                    }}
                    className={`rounded-full p-3 transition-all cursor-pointer ${
                      focusMode 
                        ? 'bg-orange-600 text-white' 
                        : isDark ? 'text-slate-400 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] hover:bg-[#5B4636]/5' : 'text-slate-500 hover:bg-slate-100 hover:text-slate-900')
                    }`}
                    title={focusMode ? "Disable Focus Mode" : "Enable Focus Mode"}
                  >
                    {focusMode ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                  </button>

                  {onToggleTheme && (
                    <button
                      onClick={onToggleTheme}
                      className={`rounded-full p-3 transition-all cursor-pointer ${
                        isDark ? 'text-slate-400 hover:bg-white/5 hover:text-white' : (isSepia ? 'text-[#5B4636] hover:bg-[#5B4636]/5' : 'text-slate-500 hover:bg-slate-100 hover:text-slate-900')
                      }`}
                      title={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
                    >
                      {isDark ? <Sun className="h-4 w-4 text-orange-400" /> : <Moon className="h-4 w-4" />}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Main Container - Page & Panel Drawer */}
      <div className={`relative flex flex-1 overflow-hidden transition-colors duration-300 ${
        isDark ? 'bg-[#121212]' : (isSepia ? 'bg-[#FAF3E0]' : 'bg-[#EAE5DA]')
      }`}>
        
         {/* PDF Page Viewport Wrapper with Inline Document Flow Navigation */}
        <div className="relative flex-1 flex flex-col min-h-0">
          <div 
            ref={viewportContainerRef}
            className={`relative flex-1 ${pageFitMode === 'fit-page' ? 'overflow-x-hidden overflow-y-auto' : 'overflow-auto'} focus:outline-hidden transition-all duration-300 ${
              isDark ? 'bg-[#161616]' : (isSepia ? 'bg-[#FAF3E0]' : 'bg-[#F6F4EF]')
            }`}
            style={{
              paddingLeft: `max(${paddingLeftVal}, env(safe-area-inset-left))`,
              paddingRight: `max(${paddingRightVal}, env(safe-area-inset-right))`,
              paddingTop: `max(${paddingTopVal}, env(safe-area-inset-top))`,
              paddingBottom: `max(${paddingBottomVal}, env(safe-area-inset-bottom))`,
              WebkitOverflowScrolling: 'touch',
              scrollBehavior: 'smooth',
            }}
            onClick={handleViewportClick}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
            onWheel={handleWheel}
          >
            {/* Mobile Reflow Suggestion Banner */}
            {showReflowBanner && readerMode === 'pdf' && isMobile && (
              <div className={`sticky top-2 left-0 right-0 z-50 mx-4 p-4 rounded-2xl shadow-xl border animate-in slide-in-from-top-4 duration-500 ${
                isDark ? 'bg-orange-600 text-white border-orange-500' : (isSepia ? 'bg-[#FDF6E3] text-[#5B4636] border-[#E2D1B3]' : 'bg-orange-50 text-orange-900 border-orange-200')
              }`}>
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-xl ${isDark ? 'bg-white/20' : 'bg-orange-100'}`}>
                      <WrapText className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="text-[11px] font-bold leading-tight">Having trouble reading small text?</h4>
                      <p className="text-[9px] opacity-80 leading-tight">Try Reflow Text for a better experience.</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => handleReaderModeChange('reflow')}
                      className={`px-3 py-1.5 text-[9px] font-black uppercase tracking-widest rounded-lg transition-all active:scale-95 ${
                        isDark ? 'bg-white text-orange-600' : 'bg-orange-600 text-white'
                      }`}
                    >
                      Switch
                    </button>
                    <button 
                      onClick={() => setShowReflowBanner(false)}
                      className={`p-1.5 rounded-lg ${isDark ? 'hover:bg-white/10' : 'hover:bg-orange-200'}`}
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            )}
            {pdfError && (
              <div className="absolute inset-0 z-50 flex flex-col items-center justify-center p-6 text-center backdrop-blur-md bg-white/95 dark:bg-black/95">
                <AlertCircle className="h-10 w-10 text-rose-500 mb-3" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">Unable to Load Document</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mb-4 leading-relaxed">{pdfError}</p>
                <div className="flex gap-2">
                  <button
                    onClick={handleBackSafely}
                    className="px-4 py-2 rounded-xl text-xs font-semibold bg-orange-600 text-white hover:bg-orange-700 cursor-pointer shadow-md transition-all active:scale-95"
                  >
                    Back to Library
                  </button>
                </div>
              </div>
            )}
            {loading && !pdfError && (
              <div className="absolute inset-0 z-50 flex flex-col items-center justify-center space-y-4 backdrop-blur-xs">
                <div className="h-1.5 w-24 rounded-full bg-orange-500/20 overflow-hidden">
                  <div className="h-full w-2/3 bg-orange-500 rounded-full" />
                </div>
                <p className={`text-[10px] uppercase tracking-widest ${
                  isDark ? 'text-slate-500' : 'text-slate-400'
                }`}>Loading document...</p>
              </div>
            )}

            <div 
              id="document-alignment-container"
              className={`flex flex-col min-h-full w-full items-center justify-start ${pageMarginMode === 'none' ? 'py-1 sm:py-2' : 'py-2 sm:py-4'}`}
            >
                {/* Floating Tooltip Highlight Color Picker */}
                {tooltip.visible && (
                  <div 
                    className={`absolute z-50 flex items-center gap-2 rounded-full p-2 shadow-2xl backdrop-blur-md border pointer-events-auto max-w-[calc(100vw-24px)] overflow-x-auto no-scrollbar ${
                      isDark ? 'bg-[#0D0D0D]/95 border-white/10' : 'bg-white/95 border-slate-200'
                    }`}
                    style={{ 
                      left: `${tooltip.x}px`, 
                      top: `${tooltip.y}px`,
                      transform: 'translateX(-50%)'
                    }}
                    onMouseDown={(e) => e.stopPropagation()}
                    onMouseUp={(e) => e.stopPropagation()}
                    onTouchStart={(e) => e.stopPropagation()}
                    onTouchEnd={(e) => e.stopPropagation()}
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button 
                      id="highlight-color-yellow-btn"
                      onClick={() => handleAddHighlightClick('yellow')}
                      className="h-6 w-6 rounded-full bg-yellow-300 border border-yellow-400 shadow-sm hover:scale-110 active:scale-90 transition-transform cursor-pointer"
                      title="Highlight Yellow"
                    />
                    <button 
                      id="highlight-color-green-btn"
                      onClick={() => handleAddHighlightClick('green')}
                      className="h-6 w-6 rounded-full bg-emerald-300 border border-emerald-400 shadow-sm hover:scale-110 active:scale-90 transition-transform cursor-pointer"
                      title="Highlight Green"
                    />
                    <button 
                      id="highlight-color-blue-btn"
                      onClick={() => handleAddHighlightClick('blue')}
                      className="h-6 w-6 rounded-full bg-sky-300 border border-sky-400 shadow-sm hover:scale-110 active:scale-90 transition-transform cursor-pointer"
                      title="Highlight Blue"
                    />
                    <button 
                      id="highlight-color-pink-btn"
                      onClick={() => handleAddHighlightClick('pink')}
                      className="h-6 w-6 rounded-full bg-rose-300 border border-rose-400 shadow-sm hover:scale-110 active:scale-90 transition-transform cursor-pointer"
                      title="Highlight Pink"
                    />
                    <button 
                      id="highlight-color-orange-btn"
                      onClick={() => handleAddHighlightClick('orange')}
                      className="h-6 w-6 rounded-full bg-orange-400 border border-orange-500 shadow-sm hover:scale-110 active:scale-90 transition-transform cursor-pointer"
                      title="Highlight Orange"
                    />

                    <div className="h-4 w-[1px] bg-slate-300 dark:bg-white/20 mx-0.5" />

                    {/* Quick Add Note to Selection */}
                    <button 
                      id="highlight-note-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        setInitialQuoteForNote(tooltip.text);
                        setActivePanel('notes');
                        resetSelectionState();
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800 dark:bg-white text-white dark:text-slate-900 text-[10px] font-bold shadow-md hover:scale-105 active:scale-95 transition-all cursor-pointer whitespace-nowrap"
                      title="Attach a note to this passage"
                    >
                      <FileText className="h-3 w-3 text-orange-400 dark:text-orange-500" />
                      <span>Note</span>
                    </button>

                    {/* Quick Speak Selection */}
                    <button 
                      id="highlight-speak-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        setCustomTextForSpeak(tooltip.text);
                        const detected = detectLanguage(tooltip.text);
                        setSpeakLanguageHint(detected);
                        setIsSpeakMode(true);
                        resetSelectionState();
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-600 text-white text-[10px] font-bold shadow-md hover:scale-105 active:scale-95 transition-all cursor-pointer whitespace-nowrap"
                      title="Speak selected text aloud"
                    >
                      <Volume2 className="h-3 w-3" />
                      <span>Speak</span>
                    </button>

                    {/* Explain Action */}
                    <button 
                      id="highlight-explain-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedQuoteForHinglish(tooltip.text);
                        setHinglishMode('explain');
                        setActivePanel('hinglish');
                        resetSelectionState();
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-purple-100 dark:bg-purple-500/20 text-purple-700 dark:text-purple-300 text-[10px] font-bold hover:scale-105 active:scale-95 transition-all cursor-pointer whitespace-nowrap border border-purple-300 dark:border-purple-500/30"
                      title="Explain difficult concepts in simple language"
                    >
                      <span>Explain</span>
                    </button>

                    {/* Summarize Action */}
                    <button 
                      id="highlight-summarize-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedQuoteForHinglish(tooltip.text);
                        setHinglishMode('summary');
                        setActivePanel('hinglish');
                        resetSelectionState();
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold hover:scale-105 active:scale-95 transition-all cursor-pointer whitespace-nowrap border border-emerald-300 dark:border-emerald-500/30"
                      title="Summarize in bullet points"
                    >
                      <span>Summary</span>
                    </button>

                    {/* Hinglish Action */}
                    <button 
                      id="highlight-hinglish-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedQuoteForHinglish(tooltip.text);
                        setHinglishMode('hinglish');
                        setActivePanel('hinglish');
                        resetSelectionState();
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-white text-[10px] font-bold shadow-md hover:scale-105 active:scale-95 transition-all cursor-pointer whitespace-nowrap"
                      title="Explain/convert this quote in Hinglish (Roman Hindi)"
                    >
                      <Languages className="h-3 w-3" />
                      <span>Hinglish</span>
                    </button>
                  </div>
                )}

                {/* Page Wrapper */}
                {readerMode === 'reflow' ? (
                  <div key="reflow-mode-container" className={`flex flex-col items-center w-full mx-auto ${getReadingWidthContainerClass(settings.readingWidth || 'full')}`}>
                    <div 
                      ref={pageContainerRef}
                      className={`relative w-full ${getReadingWidthClass(settings.readingWidth || 'full')} py-6 sm:py-10 rounded-2xl shadow-xl border transition-all duration-300 ${
                        settings.theme === 'amoled'
                          ? 'bg-black border-white/10 text-white'
                          : settings.theme === 'dark' || (settings.theme === 'light' ? false : isDark)
                            ? 'bg-[#1C1C1C] border-white/5 text-[#E3E3E3]'
                            : (settings.theme === 'sepia' || isSepia ? 'bg-[#FDF6E3] border-[#E2D1B3] text-[#5B4636]' : 'bg-[#FAF8F5] border-slate-200/50 text-slate-800')
                      } ${renderingPage ? 'opacity-40' : 'opacity-100'}`}
                      style={{
                        paddingLeft: settings.pageMargin === 'spacious' ? '36px' : (settings.pageMargin === 'normal' ? '24px' : (settings.pageMargin === 'compact' ? '14px' : 'max(10px, env(safe-area-inset-left))')),
                        paddingRight: settings.pageMargin === 'spacious' ? '36px' : (settings.pageMargin === 'normal' ? '24px' : (settings.pageMargin === 'compact' ? '14px' : 'max(10px, env(safe-area-inset-right))')),
                      }}
                    >
                      {/* Reading Flow Mode Switch Bar */}
                      <div className="relative z-10 flex flex-wrap items-center justify-between gap-2.5 mb-6 pb-4 border-b border-black/5 dark:border-white/10 select-none">
                        <div className="flex items-center gap-2">
                          <div className={`p-1.5 rounded-lg ${showLineByLineHinglish ? 'bg-orange-500/10 text-orange-600 dark:text-orange-400' : 'bg-slate-100 dark:bg-white/10 text-slate-500'}`}>
                            <Languages className="h-4 w-4" />
                          </div>
                          <div>
                            <span className="text-xs font-bold block leading-tight">Reading Flow</span>
                            <span className="text-[10px] text-slate-400">
                              {showLineByLineHinglish ? 'Original Text + Line-by-Line Hinglish' : 'Standard Book Text'}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            id="reader-reading-flow-toggle"
                            onClick={() => {
                              const next = !showLineByLineHinglish;
                              setShowLineByLineHinglish(next);
                              localStorage.setItem('reader_line_by_line_hinglish', String(next));
                            }}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer border ${
                              showLineByLineHinglish
                                ? 'bg-orange-600 text-white border-orange-500 shadow-xs hover:bg-orange-700'
                                : isDark ? 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                            }`}
                            title="Toggle Original + Hinglish line by line"
                          >
                            <Languages className="h-3 w-3" />
                            <span>{showLineByLineHinglish ? '✓ Line-by-Line Hinglish' : 'Enable Hinglish Flow'}</span>
                          </button>
                        </div>
                      </div>

                      <div className={`relative z-10 space-y-6 ${activeFontClass} ${getFontSizeClass(settings.fontSize || 'md')} ${getLineHeightClass(settings.lineHeight || 'relaxed')} ${
                        settings.letterSpacing === 'tight' ? 'tracking-tight' : (settings.letterSpacing === 'wide' ? 'tracking-wide' : (settings.letterSpacing === 'wider' ? 'tracking-widest' : 'tracking-normal'))
                      } ${
                        settings.textAlign === 'center' ? 'text-center' : (settings.textAlign === 'justify' ? 'text-justify' : 'text-left')
                      }`}>
                        {(() => {
                          if (!extractedText) {
                            return (
                              <div className="text-center py-24 text-slate-400 dark:text-white/20">
                                {renderingPage ? 'Extracting text...' : 'This page has no selectable text. Try reading in PDF Mode!'}
                              </div>
                            );
                          }

                          // 1. Line-by-Line Hinglish Reading Flow
                          if (showLineByLineHinglish) {
                            const items = hinglishLinesMap[currentPage] || [];
                            return (
                              <div className="space-y-5">
                                {loadingHinglishLines && items.length === 0 && (
                                  <div className="py-12 text-center space-y-2">
                                    <p className="text-xs text-orange-600 dark:text-orange-400 font-semibold">
                                      Preparing line-by-line Hinglish...
                                    </p>
                                  </div>
                                )}

                                {items.map((item, idx) => {
                                  const isCurrentActive = isSpeakMode && currentSpokenSentence && (
                                    item.original.toLowerCase().includes(currentSpokenSentence.toLowerCase()) || 
                                    currentSpokenSentence.toLowerCase().includes(item.original.slice(0, Math.min(25, item.original.length)).toLowerCase())
                                  );

                                  return (
                                    <div 
                                      key={idx}
                                      className={`py-2.5 transition-colors group ${
                                        isCurrentActive
                                          ? 'bg-orange-500/10 px-3 -mx-3 rounded-lg ring-1 ring-orange-500/30'
                                          : ''
                                      }`}
                                    >
                                      {/* ORIGINAL BOOK TEXT */}
                                      <div className="flex items-start justify-between gap-3">
                                        <p className="text-base sm:text-lg font-serif leading-relaxed select-text flex-1">
                                          {highlightText(item.original, searchQuery, isSpeakMode ? currentSpokenSentence : undefined)}
                                        </p>
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setCustomTextForSpeak(item.original);
                                            setSpeakLanguageHint('english');
                                            setIsSpeakMode(true);
                                          }}
                                          className="opacity-60 hover:opacity-100 group-hover:opacity-100 p-1 rounded-md text-slate-400 hover:text-emerald-600 transition-all shrink-0 cursor-pointer"
                                          title="Speak Original English"
                                          aria-label="Speak Original English"
                                        >
                                          <Volume2 className="h-3.5 w-3.5" />
                                        </button>
                                      </div>

                                      {/* HINGLISH DIRECTLY UNDERNEATH */}
                                      <div className="mt-1 flex items-start justify-between gap-3">
                                        <p className="text-[14px] sm:text-[15px] font-sans leading-relaxed text-amber-800/90 dark:text-amber-300/85 select-text flex-1">
                                          {item.hinglish}
                                        </p>
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setCustomTextForSpeak(item.hinglish);
                                            setSpeakLanguageHint('hinglish');
                                            setIsSpeakMode(true);
                                          }}
                                          className="opacity-60 hover:opacity-100 group-hover:opacity-100 p-1 rounded-md text-slate-400 hover:text-amber-600 transition-all shrink-0 cursor-pointer"
                                          title="Speak Hinglish"
                                          aria-label="Speak Hinglish"
                                        >
                                          <Volume2 className="h-3.5 w-3.5" />
                                        </button>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            );
                          }

                          // 2. Standard Paragraph Reflow View (Existing offset highlighter code)
                          const highlightsWithOffsets = currentPageHighlights.filter(h => h.startIndex !== undefined);
                          
                          if (highlightsWithOffsets.length === 0) {
                            return extractedText.split('\n').map((para, idx) => {
                              const trimmed = para.trim();
                              if (!trimmed) return null;
                              return (
                                <p key={idx} className="leading-relaxed break-words mb-6 last:mb-0">
                                  {highlightText(trimmed, searchQuery, isSpeakMode ? currentSpokenSentence : undefined)}
                                </p>
                              );
                            });
                          }

                          // Sort highlights by startIndex to render text parts sequentially
                          const sorted = [...highlightsWithOffsets].sort((a, b) => (a.startIndex || 0) - (b.startIndex || 0));
                          
                          let lastIndex = 0;
                          const parts: React.ReactNode[] = [];
                          
                          sorted.forEach((h) => {
                            const start = h.startIndex || 0;
                            const end = h.endIndex || 0;
                            
                            // Text before the highlight
                            if (start > lastIndex) {
                              const textPart = extractedText.substring(lastIndex, start);
                              parts.push(<span key={`text-${lastIndex}`}>{highlightText(textPart, searchQuery, isSpeakMode ? currentSpokenSentence : undefined)}</span>);
                            }
                            
                            // The highlight itself
                            parts.push(
                              <mark 
                                key={`highlight-${h.id}`} 
                                style={{ backgroundColor: getHighlightColorHex(h.color) }}
                                className={`rounded-sm px-0.5 mix-blend-multiply dark:mix-blend-screen opacity-100 dark:opacity-80 transition-all ${
                                  targetHighlightId === h.id ? 'ring-2 ring-orange-500 shadow-md font-semibold' : ''
                                }`}
                              >
                                {highlightText(extractedText.substring(start, end), searchQuery, isSpeakMode ? currentSpokenSentence : undefined)}
                              </mark>
                            );
                            
                            lastIndex = end;
                          });
                          
                          // Remaining text after the last highlight
                          if (lastIndex < extractedText.length) {
                            const remainingText = extractedText.substring(lastIndex);
                            parts.push(<span key={`text-${lastIndex}`}>{highlightText(remainingText, searchQuery, isSpeakMode ? currentSpokenSentence : undefined)}</span>);
                          }

                          return (
                            <div className="whitespace-pre-wrap leading-relaxed break-words">
                              {parts}
                            </div>
                          );
                        })()}
                      </div>

                      {/* Render Highlights Overlay for Reflow mode - Only used for legacy highlights without offsets */}
                      <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-2xl z-20">
                        {currentPageHighlights
                          .filter(h => h.startIndex === undefined)
                          .map(h => 
                            h.rects.map((rect, idx) => (
                              <div
                                 key={`${h.id}-${idx}`}
                                 style={{
                                   position: 'absolute',
                                   left: `${rect.left}%`,
                                   top: `${rect.top}%`,
                                   width: `${rect.width}%`,
                                   height: `${rect.height}%`,
                                   backgroundColor: getHighlightColorHex(h.color),
                                   mixBlendMode: isDark ? 'screen' : 'multiply',
                                   opacity: isDark ? 0.5 : 1
                                 }}
                              />
                            ))
                        )}
                      </div>
                    </div>

                    {/* Reflow Mode Document Flow Navigation */}
                    <div 
                      id="reflow-inline-nav-bar"
                      className={`flex items-center justify-between w-full mt-6 ${isSpeakMode ? 'mb-52' : 'mb-12'} gap-4 px-2`}
                    >
                      <button
                        id="reflow-prev-btn"
                        onClick={() => handlePageNavigation(currentPage - 1)}
                        disabled={currentPage <= 1 || loading}
                        className={`flex items-center justify-center gap-2 py-2.5 px-5 rounded-xl border font-bold text-xs transition-all duration-200 shadow-sm cursor-pointer disabled:opacity-30 disabled:pointer-events-none select-none ${
                          isDark
                            ? 'bg-[#1a1a1a] border-white/10 text-slate-200 hover:bg-[#262626]'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                        title="Previous Page"
                      >
                        <ArrowLeft className="h-4 w-4" />
                        <span>Previous Page</span>
                      </button>
                      
                      <div className={`flex flex-col items-center justify-center px-4 py-1.5 rounded-xl font-mono font-bold text-xs select-none border shadow-inner ${
                        isDark 
                          ? 'bg-neutral-905/40 border-white/5 text-slate-400' 
                          : 'bg-slate-50/50 border-slate-200/50 text-slate-600'
                      }`}
                        style={{ minWidth: '90px' }}
                      >
                        <span className="text-[9px] uppercase tracking-wider opacity-60 mb-0.5">Progress</span>
                        <span className="tabular-nums">{currentPage} / {totalPages || '?'}</span>
                      </div>

                      <button
                        id="reflow-next-btn"
                        onClick={() => handlePageNavigation(currentPage + 1)}
                        disabled={currentPage >= totalPages || loading}
                        className="flex items-center justify-center gap-2 py-2.5 px-5 rounded-xl font-bold text-xs transition-all duration-200 shadow-lg cursor-pointer disabled:opacity-30 disabled:pointer-events-none select-none text-white bg-orange-500 hover:bg-orange-600 border border-transparent shadow-orange-500/15"
                        title="Next Page"
                      >
                        <span>Next Page</span>
                        <ArrowRight className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ) : (
                    <div 
                      key="pdf-mode-container"
                      ref={documentWrapperRef}
                      id="pdf-viewer-container"
                      className="pdf-viewer-container flex flex-col items-center justify-start w-full my-0 py-1 sm:py-2"
                    >
                      {/* PDF Page container (Single & Two-Page spread) */}
                      <div className={`flex items-center justify-center gap-4 ${settings.pageFit === 'two-page' && windowWidth >= 768 ? 'flex-row' : 'flex-col'} mx-auto`}>
                        <div 
                          ref={pageContainerRef}
                          className={`relative shadow-2xl ${pageMarginMode === 'none' ? 'rounded-none border-0' : 'rounded-sm border'} shrink-0 select-none ${
                            isDark 
                              ? 'bg-[#181818] border-white/10' 
                              : (isSepia ? 'bg-[#FDF6E3] border-[#E2D1B3]' : 'bg-white border-slate-200/80')
                          }`}
                          style={{ 
                            width: dimensions.width ? `${dimensions.width}px` : '100%',
                            height: dimensions.height ? `${dimensions.height}px` : 'auto',
                            maxWidth: pageFitMode === 'fit-page' ? '100%' : undefined,
                            ['--scale-factor' as any]: `${currentScaleFactor || 1}`,
                          }}
                        >
                          {/* PDF Canvas with per-page key to eliminate canvas concurrency collisions */}
                          <canvas 
                            ref={canvasRef} 
                            key={`pdf-canvas-${currentPage}`}
                            className={`block select-none ${pageMarginMode === 'none' ? 'rounded-none' : 'rounded-sm shadow-md'} mx-auto max-w-full ${
                              isDark 
                                ? 'contrast-[1.04] brightness-[0.98]' 
                                : (isSepia ? 'sepia-[.20] contrast-[1.02] brightness-[0.99]' : '')
                            }`}
                            style={{
                              width: dimensions.width ? `${dimensions.width}px` : '100%',
                              height: dimensions.height ? `${dimensions.height}px` : 'auto',
                              maxWidth: pageFitMode === 'fit-page' ? '100%' : undefined
                            }}
                          />

                          {/* Text Layer for Selection & Highlight detection */}
                          <div 
                            ref={textLayerRef} 
                            className={`textLayer ${activeFontClass}`}
                            style={{
                              width: dimensions.width ? `${dimensions.width}px` : '100%',
                              height: dimensions.height ? `${dimensions.height}px` : '100%',
                              ['--scale-factor' as any]: `${currentScaleFactor || 1}`,
                            }}
                          />

                          {/* Render Highlights Overlay */}
                          <div className="absolute inset-0 pointer-events-none overflow-hidden">
                            {currentPageHighlights.map(h => {
                              const rects = dynamicHighlightRects[h.id] || h.rects;
                              return rects.map((rect, idx) => (
                                <div
                                   key={`${h.id}-${idx}`}
                                   className={`transition-all ${targetHighlightId === h.id ? 'ring-2 ring-orange-500 shadow-md' : ''}`}
                                   style={{
                                     position: 'absolute',
                                     left: `${rect.left}%`,
                                     top: `${rect.top}%`,
                                     width: `${rect.width}%`,
                                     height: `${rect.height}%`,
                                     backgroundColor: getHighlightColorHex(h.color),
                                     mixBlendMode: 'multiply'
                                   }}
                                />
                              ));
                            })}
                          </div>
                        </div>

                        {/* Page 2 for Two-Page Spread */}
                        {settings.pageFit === 'two-page' && windowWidth >= 768 && (
                          <div 
                            className={`relative shadow-2xl ${pageMarginMode === 'none' ? 'rounded-none border-0' : 'rounded-sm border'} shrink-0 select-none ${
                              isDark 
                                ? 'bg-[#181818] border-white/10' 
                                : (isSepia ? 'bg-[#FDF6E3] border-[#E2D1B3]' : 'bg-white border-slate-200/80')
                            }`}
                            style={{ 
                              width: dimensions.width ? `${dimensions.width}px` : '100%',
                              height: dimensions.height ? `${dimensions.height}px` : 'auto',
                            }}
                          >
                            {currentPage < totalPages ? (
                              <>
                                <canvas 
                                  ref={secondCanvasRef} 
                                  key={`pdf-canvas-${currentPage + 1}`}
                                  className={`block select-none ${pageMarginMode === 'none' ? 'rounded-none' : 'rounded-sm shadow-md'} mx-auto max-w-full ${
                                    isDark 
                                      ? 'contrast-[1.04] brightness-[0.98]' 
                                      : (isSepia ? 'sepia-[.20] contrast-[1.02] brightness-[0.99]' : '')
                                  }`}
                                  style={{
                                    width: dimensions.width ? `${dimensions.width}px` : '100%',
                                    height: dimensions.height ? `${dimensions.height}px` : 'auto',
                                  }}
                                />
                                <div 
                                  ref={secondTextLayerRef} 
                                  className={`textLayer ${activeFontClass}`}
                                  style={{
                                    width: dimensions.width ? `${dimensions.width}px` : '100%',
                                    height: dimensions.height ? `${dimensions.height}px` : '100%'
                                  }}
                                />
                              </>
                            ) : (
                              <div className="flex flex-col items-center justify-center h-full min-h-[360px] text-slate-400 p-8 text-center">
                                <BookOpen className="h-10 w-10 mb-2 opacity-30 text-orange-500" />
                                <p className="text-xs font-semibold">End of Document</p>
                              </div>
                            )}
                          </div>
                        )}
                      </div>

                    {/* PDF Mode Document Flow Navigation Bar */}
                    <div 
                      id="reader-inline-nav-bar"
                      className="flex items-center justify-between w-full max-w-2xl mt-4 sm:mt-6 mb-12 gap-3 sm:gap-4 px-2 mx-auto text-sm py-2"
                    >
                      <button
                        id="inline-prev-btn"
                        onClick={() => handlePageNavigation(currentPage - 1)}
                        disabled={currentPage <= 1 || loading}
                        className={`flex items-center justify-center gap-2 font-bold transition-all duration-200 shadow-sm cursor-pointer disabled:opacity-30 disabled:pointer-events-none select-none px-3 sm:px-4 py-2 rounded-xl border ${
                          isDark 
                            ? 'border-white/10 bg-[#1a1a1a] text-slate-300 hover:bg-[#262626]' 
                            : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                        }`}
                        title="Previous Page"
                      >
                        <ArrowLeft className="h-4 w-4" />
                        <span className="text-xs sm:text-sm">Previous</span>
                      </button>
                      
                      <div 
                        className={`flex flex-col items-center justify-center font-mono font-bold border shadow-inner select-none px-4 sm:px-5 py-1.5 rounded-xl min-w-[80px] ${
                          isDark 
                            ? 'border-white/5 bg-black/20 text-slate-400' 
                            : 'border-slate-200 bg-slate-50/50 text-slate-600'
                        }`}
                      >
                        <span className="text-[9px] opacity-60 uppercase tracking-wider mb-0.5">Progress</span>
                        <span className="tabular-nums text-xs">{currentPage} / {totalPages || '?'}</span>
                      </div>

                      <button
                        id="inline-next-btn"
                        onClick={() => handlePageNavigation(currentPage + 1)}
                        disabled={currentPage >= totalPages || loading}
                        className="flex items-center justify-center gap-2 font-bold transition-all duration-200 shadow-lg cursor-pointer disabled:opacity-30 disabled:pointer-events-none select-none text-white bg-orange-500 hover:bg-orange-600 shadow-orange-500/15 px-3 sm:px-4 py-2 rounded-xl"
                        title="Next Page"
                      >
                        <span className="text-xs sm:text-sm">Next Page</span>
                        <ArrowRight className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
          </div>
        </div>

        {/* Side Drawers */}
        {activePanel !== 'none' && (
          <div 
            className={`absolute top-0 right-0 bottom-0 z-30 w-72 border-l shadow-2xl md:relative md:w-80 transition-all duration-300 ${activeFontClass} ${
              isDark ? 'border-white/5 bg-[#0D0D0D]' : (isSepia ? 'border-[#E2D1B3] bg-[#FAF3E0]' : 'border-slate-200 bg-white')
            }`}
            style={{
              paddingTop: focusMode ? `${topBarHeight}px` : (showControls ? `${topBarHeight}px` : '0px')
            }}
          >
            {activePanel === 'bookmarks' && (
              <BookmarksPanel
                bookmarks={bookmarks}
                currentPage={currentPage}
                theme={theme}
                onAddBookmark={(label) => onAddBookmark({ bookId: book.id, pageNumber: currentPage, label })}
                onDeleteBookmark={onDeleteBookmark}
                onJumpToPage={handlePageNavigation}
                onClose={() => setActivePanel('none')}
              />
            )}
            {activePanel === 'notes' && (
              <NotesPanel
                notes={notes}
                currentPage={currentPage}
                bookTitle={book.title}
                theme={theme}
                fontFamily={activeFontClass}
                initialQuoteForNote={initialQuoteForNote}
                onSaveNote={(page, content, quote) => {
                  onSaveNote(page, content, quote);
                  setInitialQuoteForNote('');
                }}
                onDeleteNote={onDeleteNote}
                onJumpToPage={handlePageNavigation}
                onClose={() => {
                  setActivePanel('none');
                  setInitialQuoteForNote('');
                }}
              />
            )}
            {activePanel === 'highlights' && (
              <HighlightsPanel
                highlights={highlights}
                currentPage={currentPage}
                bookTitle={book.title}
                theme={theme}
                fontFamily={activeFontClass}
                onDeleteHighlight={onDeleteHighlight}
                onUpdateHighlightColor={onUpdateHighlightColor}
                onJumpToPage={(p, hId) => {
                  handlePageNavigation(p);
                  if (hId) {
                    setTargetHighlightId(hId);
                    setTimeout(() => setTargetHighlightId(null), 3500);
                  }
                }}
                onClose={() => setActivePanel('none')}
              />
            )}
            {activePanel === 'annotations' && (
              <AnnotationsPanel
                book={book}
                highlights={highlights}
                notes={notes}
                bookmarks={bookmarks}
                currentPage={currentPage}
                initialTab="all"
                theme={theme}
                fontFamily={activeFontClass}
                onJumpToPage={(p, hId) => {
                  handlePageNavigation(p);
                  if (hId) {
                    setTargetHighlightId(hId);
                    setTimeout(() => setTargetHighlightId(null), 3500);
                  }
                }}
                onDeleteHighlight={onDeleteHighlight}
                onUpdateHighlightColor={onUpdateHighlightColor}
                onDeleteNote={onDeleteNote}
                onDeleteBookmark={onDeleteBookmark}
                onOpenExport={() => setShowExportModal(true)}
                onClose={() => setActivePanel('none')}
              />
            )}
            {activePanel === 'search' && (
              <SearchPanel
                pdf={pdf}
                currentPage={currentPage}
                theme={theme}
                searchQuery={searchQuery}
                onSearchQueryChange={setSearchQuery}
                onJumpToPage={(pageNum, snippet) => {
                  handlePageNavigation(pageNum);
                  setTemporarySearchSnippet(snippet || '');
                  setTemporarySearchPage(pageNum);
                  setTimeout(() => {
                    const marks = document.querySelectorAll('.textLayer mark, #document-alignment-container mark');
                    if (marks.length > 0) {
                      marks[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                  }, 300);
                }}
                onClose={() => setActivePanel('none')}
              />
            )}
            {activePanel === 'hinglish' && (
              <HinglishPanel
                bookTitle={book.title}
                pageNumber={currentPage}
                pageText={extractedText}
                selectedText={selectedQuoteForHinglish}
                initialMode={hinglishMode}
                isDark={isDark}
                isSepia={isSepia}
                onClose={() => {
                  setActivePanel('none');
                  setSelectedQuoteForHinglish('');
                }}
                onSaveNote={onSaveNote}
                onSpeak={(textToSpeak, hint) => {
                  setCustomTextForSpeak(textToSpeak);
                  setSpeakLanguageHint(hint || 'hinglish');
                  setIsSpeakMode(true);
                }}
              />
            )}
          </div>
        )}
      </div>

      {/* Reader Bottom Navigation Bar */}
      <div 
        className={`fixed bottom-0 left-0 right-0 z-40 flex h-14 sm:h-16 items-center justify-between border-t px-2 sm:px-6 transition-all duration-300 transform backdrop-blur-xl ${
          showControls ? 'translate-y-0 opacity-100' : 'translate-y-full opacity-0 pointer-events-none'
        } ${
          isDark ? 'border-white/10 bg-[#0D0D11]/90 text-[#E0E0E0]' : (isSepia ? 'border-[#E2D1B3] bg-[#FAF3E0]/90 text-[#5B4636]' : 'border-black/5 bg-white/95 text-slate-800 shadow-xs')
        }`}
      >
        {/* Previous Page Button */}
        <button
          id="reader-prev-btn"
          disabled={currentPage <= 1 || loading}
          onClick={() => handlePageNavigation(currentPage - 1)}
          className={`rounded-full p-2 sm:p-2.5 disabled:opacity-25 transition-colors cursor-pointer active:scale-95 touch-manipulation shrink-0 ${
            isDark ? 'text-slate-100 hover:bg-white/10 hover:text-white' : 'text-slate-900 hover:bg-slate-100 hover:text-black'
          }`}
          title="Previous Page"
          aria-label="Previous Page"
        >
          <ChevronLeft className="h-5 w-5 sm:h-5.5 sm:w-5.5" strokeWidth={2.5} />
        </button>

        {/* Center Page Scrubber Slider */}
        <div className="flex flex-1 max-w-xs sm:max-w-md mx-1 sm:mx-4 items-center gap-1.5 sm:gap-3 min-w-0">
          <input
            id="reader-page-slider"
            type="range"
            min="1"
            max={totalPages || 1}
            value={currentPage}
            disabled={totalPages <= 1 || loading}
            onChange={(e) => handlePageNavigation(parseInt(e.target.value))}
            className={`flex-1 min-w-[50px] sm:min-w-[80px] h-2 rounded-full appearance-none cursor-pointer accent-orange-600 ${
              isDark ? 'bg-white/20' : 'bg-slate-300'
            }`}
          />
          <div className={`flex items-center gap-1 sm:gap-1.5 shrink-0 text-xs font-semibold ${
            isDark ? 'text-slate-200' : 'text-slate-800'
          }`}>
            <input
              id="reader-page-input"
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              value={pageInputVal}
              disabled={totalPages <= 1 || loading}
              onChange={(e) => {
                const raw = e.target.value;
                setPageInputVal(raw);
                const val = parseInt(raw, 10);
                if (!isNaN(val) && val >= 1 && val <= totalPages) {
                  handlePageNavigation(val);
                }
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  const val = parseInt(pageInputVal, 10);
                  if (!isNaN(val)) {
                    handlePageNavigation(Math.max(1, Math.min(totalPages, val)));
                  }
                }
              }}
              onBlur={() => {
                const val = parseInt(pageInputVal, 10);
                if (!isNaN(val)) {
                  handlePageNavigation(Math.max(1, Math.min(totalPages, val)));
                } else {
                  setPageInputVal(String(currentPage));
                }
              }}
              className={`w-9 sm:w-13 text-center rounded-lg border py-0.5 sm:py-1 px-0.5 sm:px-1 outline-hidden font-mono text-[11px] sm:text-xs focus:border-orange-500 font-bold transition-colors ${
                isDark ? 'border-white/20 bg-[#121212] text-white' : 'border-slate-300 bg-white text-slate-900 shadow-2xs'
              }`}
              title="Enter page number to jump immediately"
            />
            <span className={`font-mono text-[10px] sm:text-[11px] whitespace-nowrap font-bold ${
              isDark ? 'text-slate-400' : 'text-slate-500'
            }`}>/ {totalPages || '?'}</span>

            {/* Bottom Bar 1-Tap Fit Mode Toggle */}
            {readerMode === 'pdf' && (
              <button
                id="bottom-fit-mode-btn"
                onClick={() => {
                  setSettings(prev => ({
                    ...prev,
                    pageFit: prev.pageFit === 'fit-page' ? 'fit-width' : 'fit-page',
                    zoom: 1.0
                  }));
                  localStorage.setItem('reader_fit_preference_v2', 'true');
                }}
                className={`p-1.5 sm:px-2.5 sm:py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider border transition-all cursor-pointer shadow-xs active:scale-95 shrink-0 flex items-center gap-1 ${
                  settings.pageFit === 'fit-page'
                    ? 'bg-orange-600 text-white border-orange-500 font-bold'
                    : isDark ? 'border-white/20 bg-white/10 text-slate-100 hover:bg-white/20' : 'border-slate-300 bg-slate-100 text-slate-900 hover:bg-slate-200'
                }`}
                title={settings.pageFit === 'fit-page' ? "Normal: Poora Page (Fit Page). Tap for Fit Width" : "Fit Width. Tap for Poora Page"}
              >
                {settings.pageFit === 'fit-page' ? <Minimize2 className="h-3.5 w-3.5 shrink-0" strokeWidth={2.2} /> : <Maximize2 className="h-3.5 w-3.5 shrink-0" strokeWidth={2.2} />}
                <span className="hidden sm:inline whitespace-nowrap">{settings.pageFit === 'fit-page' ? 'Page' : 'Width'}</span>
              </button>
            )}

            {/* Bottom Bar 1-Tap Play / Speak Mode Toggle */}
            <button
              id="bottom-speak-btn"
              onClick={handleToggleSpeakMode}
              className={`p-1.5 sm:px-2.5 sm:py-1 rounded-lg text-[10px] sm:text-[11px] font-bold uppercase tracking-wider border-2 transition-all cursor-pointer shadow-xs active:scale-95 shrink-0 flex items-center gap-1.5 ${
                isSpeakMode
                  ? 'bg-emerald-600 text-white border-emerald-400 font-bold shadow-emerald-600/30'
                  : isDark ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20' : 'border-emerald-600/30 bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
              }`}
              title={isSpeakMode ? "Stop Speak Mode (Bolna band karein)" : "Play / Suniye (Bol kar suniye)"}
              aria-label={isSpeakMode ? "Stop Speech" : "Play Speech"}
            >
              {isSpeakMode ? (
                <Volume2 className="h-3.5 w-3.5 shrink-0 text-white" strokeWidth={2.4} />
              ) : (
                <Play className="h-3.5 w-3.5 shrink-0 fill-current ml-0.5" strokeWidth={2.4} />
              )}
              <span className="font-bold whitespace-nowrap">{isSpeakMode ? 'Speaking' : 'Play / Suno'}</span>
            </button>
          </div>
        </div>

        {/* Next Page Button */}
        <button
          id="reader-next-btn"
          disabled={currentPage >= totalPages || loading}
          onClick={() => handlePageNavigation(currentPage + 1)}
          className={`rounded-full p-2 sm:p-2.5 disabled:opacity-25 transition-colors cursor-pointer active:scale-95 touch-manipulation shrink-0 ${
            isDark ? 'text-slate-100 hover:bg-white/10 hover:text-white' : 'text-slate-900 hover:bg-slate-100 hover:text-black'
          }`}
          title="Next Page"
          aria-label="Next Page"
        >
          <ChevronRight className="h-5 w-5 sm:h-5.5 sm:w-5.5" strokeWidth={2.5} />
        </button>
      </div>

      {/* Speak Mode Floating Audio Player */}
      {isSpeakMode && (
        <SpeakPlayerBar
          pdfDoc={pdf}
          pageText={extractedText || customTextForSpeak}
          customText={customTextForSpeak}
          languageHint={speakLanguageHint}
          currentPage={currentPage}
          totalPages={totalPages}
          isDark={isDark}
          isSepia={isSepia}
          showControls={showControls}
          onPageChange={handlePageNavigation}
          onClose={() => {
            if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
              window.speechSynthesis.cancel();
            }
            setIsSpeakMode(false);
            setCustomTextForSpeak('');
            setSpeakLanguageHint(undefined);
            setCurrentSpokenSentence('');
          }}
          onCurrentSentenceChange={setCurrentSpokenSentence}
        />
      )}

      {/* Full Page Hindi Translation Modal View */}
      {showFullPageTranslation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-white/10 rounded-2xl w-full max-w-xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="p-4 border-b border-slate-200 dark:border-white/10 flex items-center justify-between bg-orange-500/5">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-orange-600 text-white shadow-xs">
                  <BookOpen className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">
                    Page {currentPage} — पूरा पेज अनुवाद (Hindi)
                  </h3>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">
                    Authentic Devanagari translation & voice ready
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowFullPageTranslation(false)}
                className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-white/10 text-slate-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Translation Content */}
            <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-3 font-hindi text-sm sm:text-base leading-relaxed text-slate-800 dark:text-slate-100 selection:bg-orange-500/20">
              {fullPageTranslation ? (
                <div className="whitespace-pre-wrap leading-relaxed font-sans font-medium">
                  {fullPageTranslation}
                </div>
              ) : (
                <div className="text-center py-8 text-slate-400">
                  अनुवाद तैयार किया जा रहा है...
                </div>
              )}
            </div>

            {/* Actions footer */}
            <div className="p-3 border-t border-slate-200 dark:border-white/10 flex items-center justify-between gap-2 bg-slate-50 dark:bg-zinc-900/80">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(fullPageTranslation);
                }}
                className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/5 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer"
              >
                Copy Text (कॉपी करें)
              </button>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setShowFullPageTranslation(false);
                    localStorage.setItem(`reader_page_trans_${currentPage}`, fullPageTranslation);
                    localStorage.setItem('reader_voice_mode', 'hi-IN');
                    localStorage.setItem('reader_voice_user_chosen', 'true');
                    setCustomTextForSpeak('');
                    setSpeakLanguageHint('hindi');
                    setIsSpeakMode(true);
                  }}
                  className="px-4 py-1.5 rounded-lg bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95"
                >
                  <Volume2 className="h-3.5 w-3.5" />
                  <span>Listen in Hindi (सुनें)</span>
                </button>
                <button
                  onClick={() => setShowFullPageTranslation(false)}
                  className="px-3 py-1.5 rounded-lg border text-xs font-medium text-slate-500 dark:text-slate-400 cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {renderTutorial()}

      <ExportAnnotationsModal
        isOpen={showExportModal}
        book={book}
        notes={notes}
        highlights={highlights}
        theme={theme}
        onClose={() => setShowExportModal(false)}
      />
    </div>
  );
}

function escapeRegExp(string: string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function highlightTextLayer(container: HTMLDivElement, query: string) {
  const children = container.getElementsByTagName('span');
  const q = query.trim().toLowerCase();
  
  for (let i = 0; i < children.length; i++) {
    const span = children[i];
    const originalText = span.getAttribute('data-original-text') || span.textContent || '';
    if (!span.hasAttribute('data-original-text')) {
      span.setAttribute('data-original-text', originalText);
    }
    
    if (q && originalText.toLowerCase().includes(q)) {
      const escapedText = originalText
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
      
      const regex = new RegExp(`(${escapeRegExp(q)})`, 'gi');
      const highlighted = escapedText.replace(regex, `<mark class="bg-amber-300 dark:bg-amber-600/80 text-black dark:text-white px-0.5 rounded border border-amber-500/30 font-bold font-sans">$1</mark>`);
      span.innerHTML = highlighted;
    } else {
      span.innerHTML = originalText;
    }
  }
}


/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useMemo } from 'react';
import { 
  Upload, Search, Trash2, ArrowUpDown, BookOpen, MoreVertical, Star, 
  Edit3, X, FileText, FolderPlus, Folder as FolderIcon, Plus, ChevronRight, 
  Check, AlertCircle, ShieldCheck, Bookmark, CheckCircle2, Clock, Sparkles, 
  Filter, Copy, Tag, FolderCheck, BookMarked, Layers, User, Calendar
} from 'lucide-react';
import { PDFBook, Collection, Folder, BookNote, Highlight } from '../types';
import { getAllNotes, getAllHighlights } from '../lib/db';

interface LibraryProps {
  books: PDFBook[];
  collections: Collection[];
  folders?: Folder[];
  onUpload: (file: File) => Promise<{ isDuplicate?: boolean; duplicateOf?: string; title?: string } | void>;
  onOpenBook: (id: string, initialPage?: number) => void;
  onDeleteBook: (id: string) => void;
  onUpdateBook: (id: string, updates: Partial<PDFBook>) => void;
  onSaveCollection: (name: string, id?: string) => Promise<string>;
  onDeleteCollection: (id: string) => Promise<void>;
  onSaveFolder?: (name: string, id?: string, color?: string) => Promise<string>;
  onDeleteFolder?: (id: string) => Promise<void>;
  onOpenDataSafety?: () => void;
}

// Phase 2 Library Smart Views
type SmartView = 
  | 'all' 
  | 'reading' 
  | 'want-to-read' 
  | 'finished' 
  | 'favorites' 
  | 'recently-added' 
  | 'recently-opened' 
  | 'folders' 
  | 'collections';

// Phase 2 Sorting
type SortOption = 'title' | 'author' | 'added' | 'opened' | 'progress';

// Phase 2 Filtering
type FormatFilter = 'all' | 'pdf' | 'epub' | 'other';
type StatusFilter = 'all' | 'reading' | 'finished' | 'unread';

type DeleteStep = 'initial' | 'confirm' | 'success';

const FOLDER_COLORS = [
  '#ea580c', // Orange
  '#2563eb', // Blue
  '#10b981', // Emerald
  '#8b5cf6', // Purple
  '#f59e0b', // Amber
  '#ec4899', // Pink
  '#64748b'  // Slate
];

export default function Library({ 
  books, 
  collections,
  folders = [],
  onUpload, 
  onOpenBook, 
  onDeleteBook, 
  onUpdateBook,
  onSaveCollection,
  onDeleteCollection,
  onSaveFolder,
  onDeleteFolder,
  onOpenDataSafety
}: LibraryProps) {
  // Navigation & View Mode
  const [activeView, setActiveView] = useState<SmartView>('all');
  const [selectedCollectionId, setSelectedCollectionId] = useState<string | null>(null);
  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(null);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('added');
  const [formatFilter, setFormatFilter] = useState<FormatFilter>('all');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [showDuplicateFilterOnly, setShowDuplicateFilterOnly] = useState(false);
  const [searchHistory, setSearchHistory] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('smart_pdf_library_search_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [libraryDeepResults, setLibraryDeepResults] = useState<{
    bookId: string;
    bookTitle: string;
    author?: string;
    matches: Array<{
      type: 'note' | 'highlight';
      pageNumber: number;
      text: string;
      color?: string;
    }>;
  }[]>([]);

  // Library-wide deep search across Book title, author, file name, notes, and highlights
  React.useEffect(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q || q.length < 2) {
      setLibraryDeepResults([]);
      return;
    }

    let active = true;
    const runDeepSearch = async () => {
      try {
        const [allNotes, allHighlights] = await Promise.all([
          getAllNotes(),
          getAllHighlights()
        ]);
        if (!active) return;

        const matchingNotes = allNotes.filter(n => 
          (n.content && n.content.toLowerCase().includes(q)) ||
          (n.quote && n.quote.toLowerCase().includes(q))
        );

        const matchingHighlights = allHighlights.filter(h => 
          h.text && h.text.toLowerCase().includes(q)
        );

        const bookMap = new Map<string, {
          bookId: string;
          bookTitle: string;
          author?: string;
          matches: Array<{
            type: 'note' | 'highlight';
            pageNumber: number;
            text: string;
            color?: string;
          }>;
        }>();

        for (const n of matchingNotes) {
          const b = books.find(item => item.id === n.bookId);
          const title = b?.title || 'Unknown Book';
          if (!bookMap.has(n.bookId)) {
            bookMap.set(n.bookId, {
              bookId: n.bookId,
              bookTitle: title,
              author: b?.author,
              matches: []
            });
          }
          bookMap.get(n.bookId)!.matches.push({
            type: 'note',
            pageNumber: n.pageNumber,
            text: n.content
          });
        }

        for (const h of matchingHighlights) {
          const b = books.find(item => item.id === h.bookId);
          const title = b?.title || 'Unknown Book';
          if (!bookMap.has(h.bookId)) {
            bookMap.set(h.bookId, {
              bookId: h.bookId,
              bookTitle: title,
              author: b?.author,
              matches: []
            });
          }
          bookMap.get(h.bookId)!.matches.push({
            type: 'highlight',
            pageNumber: h.pageNumber,
            text: h.text,
            color: h.color
          });
        }

        if (active) {
          setLibraryDeepResults(Array.from(bookMap.values()));
          try {
            setSearchHistory(prev => {
              const filtered = prev.filter(item => item.toLowerCase() !== q);
              const updated = [searchQuery.trim(), ...filtered].slice(0, 6);
              localStorage.setItem('smart_pdf_library_search_history', JSON.stringify(updated));
              return updated;
            });
          } catch {
            // ignore
          }
        }
      } catch (err) {
        console.warn('Deep search error:', err);
      }
    };

    const timer = setTimeout(runDeepSearch, 200);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [searchQuery, books]);

  const clearSearchHistory = () => {
    try {
      localStorage.removeItem('smart_pdf_library_search_history');
      setSearchHistory([]);
    } catch {
      // ignore
    }
  };

  // Upload & Drag State
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [lastUploadNotice, setLastUploadNotice] = useState<{
    title: string;
    isDuplicate: boolean;
    duplicateOf?: string;
    error?: string;
  } | null>(null);

  // Active Context Menu
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  // Edit / Organize Book Modal State
  const [organizingBook, setOrganizingBook] = useState<PDFBook | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editAuthor, setEditAuthor] = useState('');
  const [editFolderId, setEditFolderId] = useState<string | null>(null);
  const [editReadingStatus, setEditReadingStatus] = useState<'unread' | 'want-to-read' | 'reading' | 'finished'>('unread');
  const [editCollectionIds, setEditCollectionIds] = useState<string[]>([]);

  // Folder Management State
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);
  const [isRenamingFolderId, setIsRenamingFolderId] = useState<string | null>(null);
  const [folderNameInput, setFolderNameInput] = useState('');
  const [folderColorInput, setFolderColorInput] = useState(FOLDER_COLORS[0]);

  // Collection Management State
  const [isCreatingCollection, setIsCreatingCollection] = useState(false);
  const [isRenamingCollectionId, setIsRenamingCollectionId] = useState<string | null>(null);
  const [collectionNameInput, setCollectionNameInput] = useState('');

  // Multi-step Delete State
  const [deleteStep, setDeleteStep] = useState<DeleteStep>('initial');
  const [collectionToDelete, setCollectionToDelete] = useState<Collection | null>(null);
  const [folderToDelete, setFolderToDelete] = useState<Folder | null>(null);
  const [bookToDelete, setBookToDelete] = useState<PDFBook | null>(null);

  // Multi-select for Add Books to Shelf or Folder
  const [selectingShelfForBooks, setSelectingShelfForBooks] = useState(false);
  const [selectingFolderForBooks, setSelectingFolderForBooks] = useState(false);
  const [showFabMenu, setShowFabMenu] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // ----------------- DUPLICATE DETECTION LOGIC -----------------
  // Detect duplicate books without automatically deleting anything
  const duplicateBookIds = useMemo(() => {
    const ids = new Set<string>();
    for (let i = 0; i < books.length; i++) {
      for (let j = i + 1; j < books.length; j++) {
        const a = books[i];
        const b = books[j];
        const sameFile = a.fileSize === b.fileSize && a.fileName.toLowerCase() === b.fileName.toLowerCase();
        const sameTitle = a.title.trim().toLowerCase() === b.title.trim().toLowerCase();
        const sameAuthor = (a.author || '').trim().toLowerCase() === (b.author || '').trim().toLowerCase();
        
        if (sameFile || (sameTitle && (sameAuthor || (!a.author && !b.author)))) {
          ids.add(a.id);
          ids.add(b.id);
        }
      }
    }
    return ids;
  }, [books]);

  // ----------------- SMART VIEW COUNTS -----------------
  const counts = useMemo(() => {
    const reading = books.filter(b => b.readingStatus === 'reading' || (b.progressPercent > 0 && b.progressPercent < 100)).length;
    const wantToRead = books.filter(b => b.readingStatus === 'want-to-read' || (!b.readingStatus && b.progressPercent === 0)).length;
    const finished = books.filter(b => b.readingStatus === 'finished' || b.progressPercent >= 100).length;
    const favorites = books.filter(b => !!b.isFavorite).length;
    const recentlyAdded = books.filter(b => {
      if (b.isNewImport) return true;
      const days = (Date.now() - new Date(b.addedAt).getTime()) / (1000 * 60 * 60 * 24);
      return days <= 30;
    }).length;
    const recentlyOpened = books.filter(b => !!b.lastOpened).length;
    return {
      all: books.length,
      reading,
      wantToRead,
      finished,
      favorites,
      recentlyAdded,
      recentlyOpened,
      folders: folders.length,
      collections: collections.length,
      duplicates: duplicateBookIds.size
    };
  }, [books, folders, collections, duplicateBookIds]);

  // ----------------- UPLOAD HANDLERS -----------------
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const triggerUpload = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = async (file: File) => {
    setUploading(true);
    try {
      const res = await onUpload(file);
      if (res && typeof res === 'object') {
        setLastUploadNotice({
          title: res.title || file.name,
          isDuplicate: !!res.isDuplicate,
          duplicateOf: res.duplicateOf
        });
      }
    } catch (err) {
      console.error('Upload error:', err);
      setLastUploadNotice({
        title: file.name,
        isDuplicate: false,
        error: "Failed to parse and upload book. Please make sure it's a valid PDF or EPUB document."
      });
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // ----------------- FILTERING & SEARCH -----------------
  const filteredBooks = useMemo(() => {
    return books.filter(book => {
      // 1. Duplicate filter mode
      if (showDuplicateFilterOnly) {
        if (!duplicateBookIds.has(book.id)) return false;
      }

      // 2. Specific Collection or Folder drilldown
      if (activeView === 'collections' && selectedCollectionId) {
        if (!book.collectionIds?.includes(selectedCollectionId)) return false;
      }
      if (activeView === 'folders' && selectedFolderId) {
        if (book.folderId !== selectedFolderId) return false;
      }

      // 3. Smart Views
      if (!selectedCollectionId && !selectedFolderId && !showDuplicateFilterOnly) {
        if (activeView === 'reading') {
          const isReading = book.readingStatus === 'reading' || (book.progressPercent > 0 && book.progressPercent < 100);
          if (!isReading) return false;
        } else if (activeView === 'want-to-read') {
          const isWant = book.readingStatus === 'want-to-read' || (!book.readingStatus && book.progressPercent === 0);
          if (!isWant) return false;
        } else if (activeView === 'finished') {
          const isFinished = book.readingStatus === 'finished' || book.progressPercent >= 100;
          if (!isFinished) return false;
        } else if (activeView === 'favorites') {
          if (!book.isFavorite) return false;
        } else if (activeView === 'recently-added') {
          // Included in recently added
        } else if (activeView === 'recently-opened') {
          if (!book.lastOpened) return false;
        }
      }

      // 4. Library Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const folderName = folders.find(f => f.id === book.folderId)?.name.toLowerCase() || '';
        const inCollection = collections.some(c => book.collectionIds?.includes(c.id) && c.name.toLowerCase().includes(q));
        const inDeepResults = libraryDeepResults.some(g => g.bookId === book.id);
        const matches = 
          book.title.toLowerCase().includes(q) ||
          (book.author && book.author.toLowerCase().includes(q)) ||
          book.fileName.toLowerCase().includes(q) ||
          folderName.includes(q) ||
          inCollection ||
          inDeepResults;
        if (!matches) return false;
      }

      // 5. Format Filter
      if (formatFilter !== 'all') {
        const ext = book.fileName.split('.').pop()?.toLowerCase() || '';
        const format = book.fileFormat || (ext === 'pdf' ? 'pdf' : (ext === 'epub' ? 'epub' : 'other'));
        if (formatFilter === 'pdf' && format !== 'pdf') return false;
        if (formatFilter === 'epub' && format !== 'epub') return false;
        if (formatFilter === 'other' && format !== 'other') return false;
      }

      // 6. Status Filter
      if (statusFilter !== 'all') {
        const isFinished = book.readingStatus === 'finished' || book.progressPercent >= 100;
        const isReading = !isFinished && (book.readingStatus === 'reading' || book.progressPercent > 0);
        const isUnread = !isFinished && !isReading;
        if (statusFilter === 'finished' && !isFinished) return false;
        if (statusFilter === 'reading' && !isReading) return false;
        if (statusFilter === 'unread' && !isUnread) return false;
      }

      return true;
    });
  }, [
    books, activeView, selectedCollectionId, selectedFolderId, 
    searchQuery, formatFilter, statusFilter, showDuplicateFilterOnly, 
    duplicateBookIds, folders, collections
  ]);

  // ----------------- SORTING -----------------
  const sortedBooks = useMemo(() => {
    return [...filteredBooks].sort((a, b) => {
      // If Recently Added view is active, force date added desc
      if (activeView === 'recently-added') {
        return new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime();
      }
      // If Recently Opened view is active, force last opened desc
      if (activeView === 'recently-opened') {
        const timeA = a.lastOpened ? new Date(a.lastOpened).getTime() : 0;
        const timeB = b.lastOpened ? new Date(b.lastOpened).getTime() : 0;
        return timeB - timeA;
      }

      if (sortBy === 'title') {
        return a.title.localeCompare(b.title);
      }
      if (sortBy === 'author') {
        const authA = a.author || 'ZZZ';
        const authB = b.author || 'ZZZ';
        return authA.localeCompare(authB);
      }
      if (sortBy === 'opened') {
        const timeA = a.lastOpened ? new Date(a.lastOpened).getTime() : 0;
        const timeB = b.lastOpened ? new Date(b.lastOpened).getTime() : 0;
        return timeB - timeA;
      }
      if (sortBy === 'progress') {
        return (b.progressPercent || 0) - (a.progressPercent || 0);
      }
      // Default: Date Added
      return new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime();
    });
  }, [filteredBooks, activeView, sortBy]);

  // ----------------- HELPERS -----------------
  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const getInitials = (title: string) => {
    const words = title.split(' ');
    if (words.length === 1) return words[0].substring(0, 2).toUpperCase();
    return (words[0][0] + (words[1] ? words[1][0] : '')).toUpperCase();
  };

  const isBookNew = (book: PDFBook) => {
    if (book.isNewImport) return true;
    const days = (Date.now() - new Date(book.addedAt).getTime()) / (1000 * 60 * 60 * 24);
    return days <= 7;
  };

  const getStatusBadge = (book: PDFBook) => {
    const isFinished = book.readingStatus === 'finished' || book.progressPercent >= 100;
    const isReading = !isFinished && (book.readingStatus === 'reading' || book.progressPercent > 0);
    const isWantToRead = book.readingStatus === 'want-to-read';

    if (isFinished) {
      return (
        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 backdrop-blur-md px-2 py-0.5 text-[8px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
          <CheckCircle2 className="h-2.5 w-2.5" />
          Finished
        </span>
      );
    }
    if (isReading) {
      return (
        <span className="inline-flex items-center gap-1 rounded-full bg-orange-500/15 backdrop-blur-md px-2 py-0.5 text-[8px] font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400 border border-orange-500/20">
          <BookOpen className="h-2.5 w-2.5" />
          Reading ({Math.round(book.progressPercent)}%)
        </span>
      );
    }
    if (isWantToRead) {
      return (
        <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/15 backdrop-blur-md px-2 py-0.5 text-[8px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 border border-amber-500/20">
          <BookMarked className="h-2.5 w-2.5" />
          Want to Read
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-slate-500/15 backdrop-blur-md px-2 py-0.5 text-[8px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border border-slate-500/20">
        Unread
      </span>
    );
  };

  // ----------------- ACTIONS -----------------
  const openOrganizeModal = (book: PDFBook) => {
    setOrganizingBook(book);
    setEditTitle(book.title);
    setEditAuthor(book.author || '');
    setEditFolderId(book.folderId || null);
    setEditReadingStatus(book.readingStatus || (book.progressPercent >= 100 ? 'finished' : (book.progressPercent > 0 ? 'reading' : 'unread')));
    setEditCollectionIds(book.collectionIds || []);
    setActiveMenuId(null);
  };

  const handleSaveOrganize = (e: React.FormEvent) => {
    e.preventDefault();
    if (!organizingBook) return;

    onUpdateBook(organizingBook.id, {
      title: editTitle.trim() || organizingBook.title,
      author: editAuthor.trim() || undefined,
      folderId: editFolderId,
      readingStatus: editReadingStatus,
      collectionIds: editCollectionIds,
      isNewImport: false
    });

    setOrganizingBook(null);
  };

  const toggleBookCollection = (book: PDFBook, collectionId: string) => {
    const currentIds = book.collectionIds || [];
    const isSelected = currentIds.includes(collectionId);
    const newIds = isSelected
      ? currentIds.filter(id => id !== collectionId)
      : [...currentIds, collectionId];
    onUpdateBook(book.id, { collectionIds: newIds });
  };

  const toggleBookFolder = (book: PDFBook, folderId: string | null) => {
    onUpdateBook(book.id, { folderId });
  };

  const handleFolderAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (folderNameInput.trim() && onSaveFolder) {
      await onSaveFolder(folderNameInput.trim(), isRenamingFolderId || undefined, folderColorInput);
      setIsCreatingFolder(false);
      setIsRenamingFolderId(null);
      setFolderNameInput('');
    }
  };

  const handleCollectionAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (collectionNameInput.trim()) {
      await onSaveCollection(collectionNameInput.trim(), isRenamingCollectionId || undefined);
      setIsCreatingCollection(false);
      setIsRenamingCollectionId(null);
      setCollectionNameInput('');
    }
  };

  const handleConfirmDeleteCollection = async () => {
    if (collectionToDelete) {
      await onDeleteCollection(collectionToDelete.id);
      setDeleteStep('success');
    }
  };

  const handleConfirmDeleteFolder = async () => {
    if (folderToDelete && onDeleteFolder) {
      await onDeleteFolder(folderToDelete.id);
      setDeleteStep('success');
    }
  };

  const handleConfirmDeleteBook = async () => {
    if (bookToDelete) {
      await onDeleteBook(bookToDelete.id);
      setDeleteStep('success');
    }
  };

  return (
    <div className="mx-auto w-full max-w-7xl px-3 sm:px-6 py-4 sm:py-8 lg:py-10 relative">
      
      {/* ----------------- TOP HEADER ----------------- */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between border-b border-slate-200/60 dark:border-white/5 pb-4 sm:pb-6">
        <div>
          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            <h1 className="font-sans text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              {activeView === 'folders' && selectedFolderId ? (
                <span className="flex items-center gap-2">
                  <span className="text-slate-400 font-medium">Folders</span>
                  <ChevronRight className="h-5 w-5 text-slate-300" />
                  <span className="text-orange-600 dark:text-orange-500">
                    {folders.find(f => f.id === selectedFolderId)?.name}
                  </span>
                </span>
              ) : activeView === 'collections' && selectedCollectionId ? (
                <span className="flex items-center gap-2">
                  <span className="text-slate-400 font-medium">Collections</span>
                  <ChevronRight className="h-5 w-5 text-slate-300" />
                  <span className="text-orange-600 dark:text-orange-500">
                    {collections.find(c => c.id === selectedCollectionId)?.name}
                  </span>
                </span>
              ) : (
                'Library'
              )}
            </h1>

            {showDuplicateFilterOnly && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20 text-xs font-bold">
                <Copy className="h-3 w-3" />
                Duplicate Detection Mode ({duplicateBookIds.size} copies)
              </span>
            )}
          </div>
          <p className="text-[11px] text-slate-400 dark:text-white/40 mt-1 uppercase tracking-widest font-semibold">
            {activeView === 'folders' 
              ? 'Directory & category folders' 
              : (activeView === 'collections' ? 'Thematic reading shelves' : 'Phase 2 Advanced Library')}
          </p>
        </div>

        {/* Top Header Actions */}
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          {activeView === 'folders' && !selectedFolderId && onSaveFolder && (
            <button
              onClick={() => {
                setIsCreatingFolder(true);
                setFolderNameInput('');
              }}
              className="rounded-full border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 hover:bg-orange-50 dark:hover:bg-white/10 text-[10px] font-black uppercase tracking-widest transition-all px-4 py-2.5 cursor-pointer inline-flex items-center gap-1.5 shadow-sm active:scale-95"
            >
              <FolderPlus className="h-3.5 w-3.5 text-orange-600" />
              New Folder
            </button>
          )}

          {activeView === 'collections' && !selectedCollectionId && (
            <button
              onClick={() => {
                setIsCreatingCollection(true);
                setCollectionNameInput('');
              }}
              className="rounded-full border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 hover:bg-orange-50 dark:hover:bg-white/10 text-[10px] font-black uppercase tracking-widest transition-all px-4 py-2.5 cursor-pointer inline-flex items-center gap-1.5 shadow-sm active:scale-95"
            >
              <Plus className="h-3.5 w-3.5 text-orange-600" />
              New Shelf
            </button>
          )}

          {onOpenDataSafety && (
            <button
              onClick={onOpenDataSafety}
              className="rounded-full border border-emerald-500/30 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 text-[10px] font-black uppercase tracking-widest transition-all px-4 py-2.5 cursor-pointer inline-flex items-center gap-1.5 shadow-xs active:scale-95"
              title="Data Safety, Backup & Restore"
            >
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>Backup</span>
            </button>
          )}

          <button
            onClick={triggerUpload}
            disabled={uploading}
            className="rounded-full border border-slate-400 dark:border-white/10 bg-slate-900 dark:bg-zinc-900 hover:bg-orange-600 dark:hover:bg-orange-600 text-white text-[10px] font-black uppercase tracking-widest transition-all px-5 py-2.5 sm:px-6 sm:py-3 cursor-pointer inline-flex items-center gap-2 shadow-md active:scale-95"
          >
            <Upload className="h-3.5 w-3.5" />
            {uploading ? 'Importing...' : 'Import Book'}
          </button>

          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange}
            accept=".pdf,.epub,application/pdf"
            className="hidden" 
          />
        </div>
      </div>

      {/* ----------------- DUPLICATE DETECTION BANNER ----------------- */}
      {duplicateBookIds.size > 0 && !showDuplicateFilterOnly && (
        <div className="mt-4 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-amber-900 dark:text-amber-200 animate-in fade-in duration-300">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 shrink-0">
              <Copy className="h-4 w-4" />
            </div>
            <div>
              <p className="text-xs font-bold leading-tight">
                Duplicate Books Detected: {duplicateBookIds.size} copies found
              </p>
              <p className="text-[11px] opacity-80 mt-0.5">
                Both copies are safely preserved without deleting anything. You can review and organize them.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setShowDuplicateFilterOnly(true)}
              className="px-3.5 py-1.5 rounded-full bg-amber-600 hover:bg-amber-700 text-white text-[10px] font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-sm"
            >
              Review Duplicates
            </button>
          </div>
        </div>
      )}

      {/* ----------------- LAST IMPORT NOTICE ----------------- */}
      {lastUploadNotice && (
        <div className={`mt-4 p-3.5 rounded-2xl flex items-center justify-between gap-3 animate-in slide-in-from-top-2 duration-300 ${
          lastUploadNotice.error 
            ? 'bg-rose-500/10 border border-rose-500/25 text-rose-900 dark:text-rose-200' 
            : 'bg-emerald-500/10 border border-emerald-500/25 text-emerald-900 dark:text-emerald-200'
        }`}>
          <div className="flex items-center gap-2.5 min-w-0">
            {lastUploadNotice.error ? (
              <AlertCircle className="h-4 w-4 text-rose-500 shrink-0" />
            ) : (
              <Sparkles className="h-4 w-4 text-emerald-500 shrink-0" />
            )}
            <p className="text-xs font-bold truncate">
              {lastUploadNotice.error ? (
                lastUploadNotice.error
              ) : (
                <>
                  Imported "{lastUploadNotice.title}" successfully!
                  {lastUploadNotice.isDuplicate && (
                    <span className="ml-2 font-normal text-amber-600 dark:text-amber-400">
                      (Note: A book with this name/size already exists. Both copies kept safely.)
                    </span>
                  )}
                </>
              )}
            </p>
          </div>
          <button
            onClick={() => setLastUploadNotice(null)}
            className="opacity-75 hover:opacity-100 p-1 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* ----------------- SMART VIEW TABS ----------------- */}
      <div className="mt-4 sm:mt-6 overflow-x-auto pb-1 scrollbar-none">
        <div className="flex items-center gap-2 min-w-max border-b border-black/5 dark:border-white/5 pb-3">
          {[
            { id: 'all', label: 'All Books', count: counts.all, icon: Layers },
            { id: 'reading', label: 'Currently Reading', count: counts.reading, icon: BookOpen },
            { id: 'want-to-read', label: 'Want to Read', count: counts.wantToRead, icon: BookMarked },
            { id: 'finished', label: 'Finished', count: counts.finished, icon: CheckCircle2 },
            { id: 'favorites', label: 'Favorites', count: counts.favorites, icon: Star },
            { id: 'recently-added', label: 'Recently Added', count: counts.recentlyAdded, icon: Sparkles },
            { id: 'recently-opened', label: 'Recently Opened', count: counts.recentlyOpened, icon: Clock },
            { id: 'folders', label: 'Folders', count: counts.folders, icon: FolderIcon },
            { id: 'collections', label: 'Collections', count: counts.collections, icon: Tag },
          ].map((tab) => {
            const isActive = activeView === tab.id && !showDuplicateFilterOnly;
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveView(tab.id as SmartView);
                  setShowDuplicateFilterOnly(false);
                  if (tab.id !== 'folders') setSelectedFolderId(null);
                  if (tab.id !== 'collections') setSelectedCollectionId(null);
                }}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-full text-xs font-bold transition-all cursor-pointer select-none ${
                  isActive 
                    ? 'bg-orange-600 text-white shadow-md shadow-orange-600/20 scale-[1.02]' 
                    : 'liquid-glass-card border text-slate-700 dark:text-slate-300 hover:border-orange-500/40 hover:text-orange-600 shadow-xs'
                }`}
              >
                <Icon className={`h-3.5 w-3.5 ${isActive ? 'text-white' : 'text-slate-400 dark:text-slate-500'}`} />
                <span>{tab.label}</span>
                <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                  isActive ? 'bg-white/20 text-white' : 'bg-black/5 dark:bg-white/10 text-slate-500 dark:text-slate-400'
                }`}>
                  {tab.count}
                </span>
              </button>
            );
          })}

          {showDuplicateFilterOnly && (
            <button
              onClick={() => setShowDuplicateFilterOnly(false)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-amber-600 text-white text-xs font-bold shadow-md cursor-pointer"
            >
              <X className="h-3.5 w-3.5" />
              <span>Exit Duplicates Mode</span>
            </button>
          )}
        </div>
      </div>

      {/* ----------------- SEARCH & FILTERS BAR (For book list views) ----------------- */}
      {(activeView !== 'folders' || selectedFolderId) && (activeView !== 'collections' || selectedCollectionId) && (
        <div className="mt-4 flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-black/5 dark:border-white/5 pb-4">
          
          {/* Library Search */}
          <div className="flex flex-col gap-1.5 w-full md:w-96">
            <div className="relative group w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 group-focus-within:text-orange-600 transition-colors" />
              <input
                type="text"
                placeholder="Search books, authors, notes, highlights..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full liquid-glass-card border pl-10 pr-9 py-2.5 rounded-2xl text-xs sm:text-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 placeholder:text-slate-400 dark:text-white dark:placeholder:text-white/30 shadow-xs transition-all"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
                  title="Clear search"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>

            {/* Search History Chips */}
            {(!searchQuery || searchQuery.trim().length === 0) && searchHistory.length > 0 && (
              <div className="flex items-center gap-1.5 flex-wrap text-xs pt-0.5">
                <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center gap-1">
                  <Clock className="h-3 w-3" /> Recent:
                </span>
                {searchHistory.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSearchQuery(item)}
                    className="px-2.5 py-0.5 rounded-full border border-black/5 dark:border-white/10 bg-black/5 dark:bg-white/5 hover:border-orange-500/50 text-[11px] text-slate-600 dark:text-slate-300 transition-colors cursor-pointer truncate max-w-[130px]"
                  >
                    {item}
                  </button>
                ))}
                <button
                  onClick={clearSearchHistory}
                  className="text-[10px] text-slate-400 hover:text-red-500 ml-1 cursor-pointer font-medium"
                  title="Clear recent searches"
                >
                  Clear
                </button>
              </div>
            )}
          </div>

          {/* Sort & Format Controls */}
          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            {/* Format Filter */}
            <div className="flex items-center gap-1.5 px-3 py-2 rounded-2xl liquid-glass-card border text-xs font-bold">
              <Filter className="h-3.5 w-3.5 text-slate-400" />
              <select
                value={formatFilter}
                onChange={(e) => setFormatFilter(e.target.value as FormatFilter)}
                className="bg-transparent border-none text-[11px] font-bold text-slate-700 dark:text-slate-300 focus:ring-0 p-0 cursor-pointer"
              >
                <option value="all">All Formats</option>
                <option value="pdf">PDF only</option>
                <option value="epub">EPUB only</option>
                <option value="other">Other formats</option>
              </select>
            </div>

            {/* Reading Status Filter */}
            <div className="flex items-center gap-1.5 px-3 py-2 rounded-2xl liquid-glass-card border text-xs font-bold">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
                className="bg-transparent border-none text-[11px] font-bold text-slate-700 dark:text-slate-300 focus:ring-0 p-0 cursor-pointer"
              >
                <option value="all">All Progress</option>
                <option value="reading">In Progress</option>
                <option value="finished">Finished</option>
                <option value="unread">Unread</option>
              </select>
            </div>

            {/* Sort Selector */}
            <div className="flex items-center gap-2 px-3 py-2 rounded-2xl liquid-glass-card border text-xs font-bold">
              <ArrowUpDown className="h-3.5 w-3.5 text-orange-600" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="bg-transparent border-none text-[11px] font-bold text-slate-700 dark:text-slate-300 focus:ring-0 p-0 cursor-pointer"
              >
                <option value="added">Sort: Date Added</option>
                <option value="title">Sort: Title (A-Z)</option>
                <option value="author">Sort: Author</option>
                <option value="opened">Sort: Last Opened</option>
                <option value="progress">Sort: Reading Progress</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* ----------------- FOLDERS GRID VIEW ----------------- */}
      {activeView === 'folders' && !selectedFolderId && (
        <div className="mt-8 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <FolderIcon className="h-5 w-5 text-orange-600" />
              <span>Library Folders</span>
            </h2>
            {onSaveFolder && (
              <button
                onClick={() => {
                  setIsCreatingFolder(true);
                  setFolderNameInput('');
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-orange-600 text-white rounded-full text-xs font-bold uppercase tracking-wider hover:bg-orange-700 transition-colors shadow-sm"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Create Folder</span>
              </button>
            )}
          </div>

          {folders.length === 0 ? (
            <div className="py-20 text-center bg-slate-50 dark:bg-white/5 rounded-3xl border border-dashed border-slate-200 dark:border-white/10">
              <FolderIcon className="h-10 w-10 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
              <h3 className="font-bold text-slate-700 dark:text-slate-300">No Folders Created Yet</h3>
              <p className="text-xs text-slate-400 dark:text-white/40 max-w-sm mx-auto mt-1 mb-6">
                Create folders like "Self Development", "Course Work", or "Class Notes" to categorize your reading library.
              </p>
              {onSaveFolder && (
                <button
                  onClick={() => setIsCreatingFolder(true)}
                  className="inline-flex items-center gap-2 px-6 py-2.5 bg-orange-600 text-white rounded-full text-xs font-bold shadow-md hover:bg-orange-700"
                >
                  <FolderPlus className="h-4 w-4" />
                  Create First Folder
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {folders.map(folder => {
                const folderBooks = books.filter(b => b.folderId === folder.id);
                return (
                  <div
                    key={folder.id}
                    onClick={() => setSelectedFolderId(folder.id)}
                    className="group relative bg-white dark:bg-[#161616] rounded-2xl border-2 border-slate-200 dark:border-white/10 p-6 hover:border-orange-500/60 hover:shadow-xl transition-all cursor-pointer overflow-hidden shadow-sm"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div 
                        className="rounded-2xl p-4 text-white shadow-md flex items-center justify-center"
                        style={{ backgroundColor: folder.color || '#ea580c' }}
                      >
                        <FolderIcon className="h-7 w-7" />
                      </div>

                      <div className="relative">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveMenuId(activeMenuId === folder.id ? null : folder.id);
                          }}
                          className="rounded-full p-2 text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5 transition-colors"
                        >
                          <MoreVertical className="h-4 w-4" />
                        </button>

                        {activeMenuId === folder.id && (
                          <>
                            <div className="fixed inset-0 z-20" onClick={(e) => { e.stopPropagation(); setActiveMenuId(null); }} />
                            <div className="absolute right-0 mt-1 w-44 origin-top-right rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1A1A1A] py-1.5 shadow-xl z-30 overflow-hidden text-xs">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setIsRenamingFolderId(folder.id);
                                  setFolderNameInput(folder.name);
                                  setFolderColorInput(folder.color || FOLDER_COLORS[0]);
                                  setActiveMenuId(null);
                                }}
                                className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5"
                              >
                                <Edit3 className="h-3.5 w-3.5 text-orange-600" />
                                <span>Rename Folder</span>
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedFolderId(folder.id);
                                  setSelectingFolderForBooks(true);
                                  setActiveMenuId(null);
                                }}
                                className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5"
                              >
                                <Plus className="h-3.5 w-3.5 text-orange-600" />
                                <span>Add Books</span>
                              </button>
                              <div className="h-px bg-slate-100 dark:bg-white/5 my-1" />
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setFolderToDelete(folder);
                                  setDeleteStep('initial');
                                  setActiveMenuId(null);
                                }}
                                className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                                <span>Delete Folder</span>
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    </div>

                    <h3 className="font-bold text-base text-slate-900 dark:text-white group-hover:text-orange-600 transition-colors truncate">
                      {folder.name}
                    </h3>
                    <p className="text-[11px] font-semibold text-slate-400 dark:text-white/40 mt-1">
                      {folderBooks.length} {folderBooks.length === 1 ? 'book' : 'books'}
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ----------------- INSIDE FOLDER VIEW HEADER ----------------- */}
      {activeView === 'folders' && selectedFolderId && (
        <div className="mt-6 flex items-center justify-between p-5 rounded-2xl bg-orange-500/10 border border-orange-500/20">
          <div className="flex items-center gap-3">
            <div 
              className="p-3 rounded-xl text-white shadow-sm"
              style={{ backgroundColor: folders.find(f => f.id === selectedFolderId)?.color || '#ea580c' }}
            >
              <FolderIcon className="h-6 w-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg text-slate-900 dark:text-white">
                {folders.find(f => f.id === selectedFolderId)?.name}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {filteredBooks.length} {filteredBooks.length === 1 ? 'Book' : 'Books'} in this folder
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectingFolderForBooks(true)}
              className="px-4 py-2 bg-orange-600 text-white rounded-full text-xs font-bold uppercase tracking-wider hover:bg-orange-700 shadow-sm"
            >
              + Add Books
            </button>
            <button
              onClick={() => setSelectedFolderId(null)}
              className="px-4 py-2 border border-slate-300 dark:border-white/10 rounded-full text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-orange-600"
            >
              All Folders
            </button>
          </div>
        </div>
      )}

      {/* ----------------- COLLECTIONS GRID VIEW ----------------- */}
      {activeView === 'collections' && !selectedCollectionId && (
        <div className="mt-8 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Tag className="h-5 w-5 text-orange-600" />
              <span>Reading Collections</span>
            </h2>
            <button
              onClick={() => {
                setIsCreatingCollection(true);
                setCollectionNameInput('');
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-orange-600 text-white rounded-full text-xs font-bold uppercase tracking-wider hover:bg-orange-700 transition-colors shadow-sm"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Create Collection</span>
            </button>
          </div>

          {collections.length === 0 ? (
            <div className="py-20 text-center bg-slate-50 dark:bg-white/5 rounded-3xl border border-dashed border-slate-200 dark:border-white/10">
              <Tag className="h-10 w-10 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
              <h3 className="font-bold text-slate-700 dark:text-slate-300">No Collections Created Yet</h3>
              <p className="text-xs text-slate-400 dark:text-white/40 max-w-sm mx-auto mt-1 mb-6">
                Group books thematically across genres, favorites, or projects without altering folders.
              </p>
              <button
                onClick={() => setIsCreatingCollection(true)}
                className="inline-flex items-center gap-2 px-6 py-2.5 bg-orange-600 text-white rounded-full text-xs font-bold shadow-md hover:bg-orange-700"
              >
                <Plus className="h-4 w-4" />
                Create First Collection
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {collections.map(collection => {
                const collectionBooks = books.filter(b => b.collectionIds?.includes(collection.id));
                const thumbnail = collectionBooks.find(b => b.thumbnail)?.thumbnail;

                return (
                  <div
                    key={collection.id}
                    onClick={() => setSelectedCollectionId(collection.id)}
                    className="group relative bg-white dark:bg-[#161616] rounded-2xl border-2 border-slate-200 dark:border-white/10 p-6 hover:border-orange-500/60 hover:shadow-xl transition-all cursor-pointer overflow-hidden shadow-sm"
                  >
                    <div className="flex items-start justify-between mb-4">
                      {thumbnail ? (
                        <div className="w-16 h-20 rounded-lg overflow-hidden shadow-md border border-white/50 group-hover:scale-105 transition-transform duration-300">
                          <img src={thumbnail} alt={collection.name} className="w-full h-full object-cover" />
                        </div>
                      ) : (
                        <div className="rounded-2xl bg-orange-500/10 p-4 text-orange-600 border border-orange-500/20">
                          <Tag className="h-7 w-7" />
                        </div>
                      )}

                      <div className="relative">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveMenuId(activeMenuId === collection.id ? null : collection.id);
                          }}
                          className="rounded-full p-2 text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5 transition-colors"
                        >
                          <MoreVertical className="h-4 w-4" />
                        </button>

                        {activeMenuId === collection.id && (
                          <>
                            <div className="fixed inset-0 z-20" onClick={(e) => { e.stopPropagation(); setActiveMenuId(null); }} />
                            <div className="absolute right-0 mt-1 w-44 origin-top-right rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1A1A1A] py-1.5 shadow-xl z-30 overflow-hidden text-xs">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setIsRenamingCollectionId(collection.id);
                                  setCollectionNameInput(collection.name);
                                  setActiveMenuId(null);
                                }}
                                className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5"
                              >
                                <Edit3 className="h-3.5 w-3.5 text-orange-600" />
                                <span>Rename Shelf</span>
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedCollectionId(collection.id);
                                  setSelectingShelfForBooks(true);
                                  setActiveMenuId(null);
                                }}
                                className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5"
                              >
                                <Plus className="h-3.5 w-3.5 text-orange-600" />
                                <span>Add Books</span>
                              </button>
                              <div className="h-px bg-slate-100 dark:bg-white/5 my-1" />
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setCollectionToDelete(collection);
                                  setDeleteStep('initial');
                                  setActiveMenuId(null);
                                }}
                                className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                                <span>Delete Shelf</span>
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    </div>

                    <h3 className="font-bold text-base text-slate-900 dark:text-white group-hover:text-orange-600 transition-colors truncate">
                      {collection.name}
                    </h3>
                    <p className="text-[11px] font-semibold text-slate-400 dark:text-white/40 mt-1">
                      {collectionBooks.length} {collectionBooks.length === 1 ? 'book' : 'books'}
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ----------------- INSIDE COLLECTION VIEW HEADER ----------------- */}
      {activeView === 'collections' && selectedCollectionId && (
        <div className="mt-6 flex items-center justify-between p-5 rounded-2xl bg-orange-500/10 border border-orange-500/20">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-orange-600 text-white shadow-sm">
              <Tag className="h-6 w-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg text-slate-900 dark:text-white">
                {collections.find(c => c.id === selectedCollectionId)?.name}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {filteredBooks.length} {filteredBooks.length === 1 ? 'Book' : 'Books'} in this shelf
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectingShelfForBooks(true)}
              className="px-4 py-2 bg-orange-600 text-white rounded-full text-xs font-bold uppercase tracking-wider hover:bg-orange-700 shadow-sm"
            >
              + Add Books
            </button>
            <button
              onClick={() => setSelectedCollectionId(null)}
              className="px-4 py-2 border border-slate-300 dark:border-white/10 rounded-full text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-orange-600"
            >
              All Shelves
            </button>
          </div>
        </div>
      )}

      {/* ----------------- BOOKS GRID VIEW ----------------- */}
      {(activeView !== 'folders' || selectedFolderId) && (activeView !== 'collections' || selectedCollectionId) && (
        <div className="mt-6">
          {/* ----------------- SEARCH RESULTS IN NOTES & HIGHLIGHTS ----------------- */}
          {searchQuery.trim().length >= 2 && libraryDeepResults.length > 0 && (
            <div className="mb-8 p-4 sm:p-6 rounded-3xl border border-orange-500/25 bg-orange-500/5 shadow-xs space-y-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between">
                <h3 className="text-xs sm:text-sm font-extrabold uppercase tracking-wider text-orange-600 dark:text-orange-400 flex items-center gap-2">
                  <Search className="h-4 w-4" />
                  <span>Search Results in Notes & Highlights</span>
                </h3>
                <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-orange-500/10 text-orange-500 border border-orange-500/20">
                  {libraryDeepResults.reduce((acc, g) => acc + g.matches.length, 0)} {libraryDeepResults.reduce((acc, g) => acc + g.matches.length, 0) === 1 ? 'match' : 'matches'}
                </span>
              </div>

              <div className="space-y-4">
                {libraryDeepResults.map((group) => (
                  <div 
                    key={group.bookId}
                    className="bg-white dark:bg-[#161616] rounded-2xl border border-slate-200 dark:border-white/10 p-4 sm:p-5 shadow-xs space-y-3"
                  >
                    <div 
                      onClick={() => onOpenBook(group.bookId)}
                      className="flex items-center justify-between cursor-pointer group"
                    >
                      <div className="min-w-0 pr-3">
                        <h4 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white group-hover:text-orange-500 transition-colors truncate">
                          {group.bookTitle}
                        </h4>
                        {group.author && (
                          <p className="text-[11px] text-slate-400 truncate">{group.author}</p>
                        )}
                      </div>
                      <span className="text-[11px] font-bold text-orange-500 group-hover:underline flex items-center gap-0.5 shrink-0">
                        Open Book <ChevronRight className="h-3.5 w-3.5" />
                      </span>
                    </div>

                    <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-white/5">
                      {group.matches.map((match, mIdx) => (
                        <div
                          key={mIdx}
                          onClick={() => onOpenBook(group.bookId, match.pageNumber)}
                          className="p-3 rounded-xl border border-slate-100 dark:border-white/5 hover:border-orange-500/40 bg-slate-50/80 dark:bg-white/5 cursor-pointer transition-all flex flex-col gap-1 text-xs"
                        >
                          <div className="flex items-center justify-between">
                            <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider ${
                              match.type === 'highlight' 
                                ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400' 
                                : 'bg-blue-500/10 text-blue-600 dark:text-blue-400'
                            }`}>
                              {match.type === 'highlight' ? 'Highlight' : 'Note'}
                            </span>
                            <span className="font-mono text-[10px] font-bold text-orange-500">
                              Page {match.pageNumber}
                            </span>
                          </div>
                          <p className="text-[11px] leading-relaxed line-clamp-2 text-slate-700 dark:text-slate-300 italic">
                            "{match.text}"
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {sortedBooks.length === 0 ? (
            <div className="py-24 text-center rounded-3xl border-2 border-dashed border-slate-200 dark:border-white/10 bg-slate-50/50 dark:bg-white/5 p-8">
              <BookOpen className="h-12 w-12 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
                {searchQuery 
                  ? 'No books match your search' 
                  : (showDuplicateFilterOnly ? 'No duplicate books found' : 'No books in this view')}
              </h3>
              <p className="text-xs text-slate-400 dark:text-white/40 max-w-sm mx-auto mt-1 mb-6">
                {searchQuery 
                  ? 'Try searching for another book title, author, or folder.' 
                  : 'Import a PDF or EPUB book to expand your reading library.'}
              </p>
              {searchQuery ? (
                <button
                  onClick={() => setSearchQuery('')}
                  className="px-5 py-2.5 rounded-full bg-slate-200 dark:bg-white/10 text-xs font-bold"
                >
                  Clear Search
                </button>
              ) : (
                <button
                  onClick={triggerUpload}
                  className="px-6 py-2.5 rounded-full bg-orange-600 text-white text-xs font-bold uppercase tracking-wider hover:bg-orange-700 shadow-md"
                >
                  Import Book
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4 sm:gap-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
              {sortedBooks.map(book => {
                const isDuplicate = duplicateBookIds.has(book.id);
                const isNewlyImported = isBookNew(book);
                const bookFolder = folders.find(f => f.id === book.folderId);

                return (
                  <div 
                    key={book.id} 
                    className="group flex flex-col gap-1.5 animate-in fade-in duration-300 relative"
                  >
                    {/* Visual Book Cover */}
                    <div 
                      onClick={() => onOpenBook(book.id)}
                      className="relative aspect-[3/4] w-full bg-white dark:bg-zinc-900 rounded-xl book-spine-3d border border-black/5 dark:border-white/10 transition-all duration-300 group-hover:border-orange-500/60 group-hover:-translate-y-2 overflow-hidden cursor-pointer shadow-md hover:shadow-2xl"
                    >
                      {/* Actual Cover or Fallback */}
                      {book.thumbnail ? (
                        <img 
                          src={book.thumbnail} 
                          alt={book.title}
                          className="absolute inset-0 w-full h-full object-cover opacity-95 group-hover:opacity-100 transition-opacity"
                          loading="lazy"
                        />
                      ) : (
                        <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-slate-100 to-slate-200 dark:from-zinc-800 dark:to-zinc-900 p-3 text-center">
                          <FileText className="h-10 w-10 text-slate-400 dark:text-slate-600 mb-1" />
                          <div className="text-[10px] font-extrabold text-slate-600 dark:text-slate-300 line-clamp-2 px-1">
                            {book.title}
                          </div>
                          <div className="absolute inset-0 flex items-center justify-center opacity-5 font-black text-6xl pointer-events-none">
                            {getInitials(book.title)}
                          </div>
                        </div>
                      )}

                      {/* Top Overlay Badges */}
                      <div className="absolute top-2 left-2 right-2 flex items-start justify-between z-10 gap-1">
                        <div className="flex flex-col gap-1 items-start">
                          {getStatusBadge(book)}

                          {isNewlyImported && (
                            <span className="inline-flex items-center gap-0.5 rounded-full bg-orange-600 px-1.5 py-0.5 text-[7px] font-black uppercase tracking-wider text-white shadow-xs">
                              <Sparkles className="h-2 w-2" />
                              New
                            </span>
                          )}

                          {isDuplicate && (
                            <span 
                              className="inline-flex items-center gap-0.5 rounded-full bg-amber-500/90 text-white px-1.5 py-0.5 text-[7px] font-bold uppercase tracking-wider shadow-xs"
                              title="Duplicate copy detected in library (safely preserved)"
                            >
                              <Copy className="h-2 w-2" />
                              Copy
                            </span>
                          )}
                        </div>

                        {/* Top Right Action Pill */}
                        <div className="flex items-center gap-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onUpdateBook(book.id, { isFavorite: !book.isFavorite });
                            }}
                            className={`rounded-full p-1.5 backdrop-blur-md transition-all ${
                              book.isFavorite 
                                ? 'bg-orange-600 text-white shadow-md' 
                                : 'bg-black/40 text-white/70 hover:text-white hover:bg-black/60'
                            }`}
                            title={book.isFavorite ? 'Favorited' : 'Add to Favorites'}
                          >
                            <Star className={`h-3 w-3 ${book.isFavorite ? 'fill-current' : ''}`} />
                          </button>

                          {/* Quick Menu */}
                          <div className="relative">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setActiveMenuId(activeMenuId === book.id ? null : book.id);
                              }}
                              className="rounded-full p-1.5 bg-black/40 text-white hover:bg-black/60 backdrop-blur-md transition-colors"
                            >
                              <MoreVertical className="h-3 w-3" />
                            </button>

                            {activeMenuId === book.id && (
                              <>
                                <div 
                                  className="fixed inset-0 z-20" 
                                  onClick={(e) => { e.stopPropagation(); setActiveMenuId(null); }} 
                                />
                                <div className="absolute right-0 mt-1 w-48 origin-top-right rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1A1A1A] py-1.5 shadow-2xl z-30 overflow-hidden text-xs">
                                  {/* Organize & Edit Details */}
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      openOrganizeModal(book);
                                    }}
                                    className="flex w-full items-center gap-2.5 px-4 py-2.5 text-left text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5 font-semibold"
                                  >
                                    <Edit3 className="h-3.5 w-3.5 text-orange-600" />
                                    <span>Organize & Edit</span>
                                  </button>

                                  {/* Quick Status Toggle */}
                                  <div className="px-4 py-1.5 text-[9px] uppercase tracking-wider font-bold text-slate-400 dark:text-slate-500">
                                    Reading Status
                                  </div>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onUpdateBook(book.id, { readingStatus: 'reading' });
                                      setActiveMenuId(null);
                                    }}
                                    className="flex w-full items-center gap-2 px-4 py-1.5 text-left text-[11px] text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5"
                                  >
                                    <BookOpen className="h-3 w-3 text-orange-500" />
                                    <span>Currently Reading</span>
                                  </button>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onUpdateBook(book.id, { readingStatus: 'want-to-read' });
                                      setActiveMenuId(null);
                                    }}
                                    className="flex w-full items-center gap-2 px-4 py-1.5 text-left text-[11px] text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5"
                                  >
                                    <BookMarked className="h-3 w-3 text-amber-500" />
                                    <span>Want to Read</span>
                                  </button>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onUpdateBook(book.id, { readingStatus: 'finished', progressPercent: 100 });
                                      setActiveMenuId(null);
                                    }}
                                    className="flex w-full items-center gap-2 px-4 py-1.5 text-left text-[11px] text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5"
                                  >
                                    <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                                    <span>Mark as Finished</span>
                                  </button>

                                  <div className="h-px bg-slate-100 dark:bg-white/5 my-1" />

                                  {/* Delete */}
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setBookToDelete(book);
                                      setDeleteStep('initial');
                                      setActiveMenuId(null);
                                    }}
                                    className="flex w-full items-center gap-2 px-4 py-2 text-left text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 font-semibold"
                                  >
                                    <Trash2 className="h-3.5 w-3.5" />
                                    <span>Delete Book</span>
                                  </button>
                                </div>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Bottom Progress Bar Overlay */}
                      <div className="absolute bottom-0 left-0 right-0 p-2.5 bg-gradient-to-t from-black/85 via-black/50 to-transparent z-10">
                        <div className="flex items-center justify-between text-[9px] text-white/90 font-semibold mb-1">
                          <span>{Math.round(book.progressPercent || 0)}% Read</span>
                          <span className="opacity-70">{book.currentPage}/{book.totalPages} pgs</span>
                        </div>
                        <div className="h-1 w-full bg-white/20 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-orange-500" 
                            style={{ width: `${book.progressPercent || 0}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Book Metadata Line */}
                    <div className="px-0.5">
                      <h4 
                        onClick={() => onOpenBook(book.id)}
                        className="text-xs font-bold leading-snug text-slate-800 dark:text-slate-100 group-hover:text-orange-500 transition-colors line-clamp-2 cursor-pointer"
                        title={book.title}
                      >
                        {book.title}
                      </h4>

                      {/* Author */}
                      {book.author && (
                        <p className="text-[10px] text-slate-500 dark:text-white/40 truncate flex items-center gap-1 mt-0.5">
                          <User className="h-2.5 w-2.5 shrink-0 text-slate-400" />
                          <span>{book.author}</span>
                        </p>
                      )}

                      {/* Folder / Format Badges */}
                      <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                        {bookFolder && (
                          <span 
                            className="inline-flex items-center gap-1 text-[8px] font-bold px-1.5 py-0.2 rounded-md text-white shadow-2xs"
                            style={{ backgroundColor: bookFolder.color || '#ea580c' }}
                          >
                            <FolderIcon className="h-2 w-2" />
                            <span className="truncate max-w-[70px]">{bookFolder.name}</span>
                          </span>
                        )}
                        <span className="text-[8px] uppercase tracking-wider font-bold text-slate-400 dark:text-white/30">
                          {book.fileFormat ? book.fileFormat.toUpperCase() : 'PDF'} • {formatSize(book.fileSize)}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ----------------- MANUAL ORGANIZE & EDIT BOOK MODAL ----------------- */}
      {organizingBook && (
        <div className="fixed inset-0 z-[130] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-white dark:bg-[#1A1A1A] rounded-3xl shadow-2xl border border-slate-200 dark:border-white/10 p-6 sm:p-8 scale-in-center">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
                  Organize & Edit Book
                </h3>
                <p className="text-[10px] uppercase tracking-widest font-bold text-orange-600 mt-0.5">
                  Phase 2 Library Manager
                </p>
              </div>
              <button 
                onClick={() => setOrganizingBook(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white p-1 rounded-full"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveOrganize} className="space-y-4">
              {/* Title */}
              <div>
                <label className="block text-[10px] uppercase tracking-widest font-bold text-slate-400 dark:text-white/40 mb-1">
                  Book Title
                </label>
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500/40"
                  required
                />
              </div>

              {/* Author */}
              <div>
                <label className="block text-[10px] uppercase tracking-widest font-bold text-slate-400 dark:text-white/40 mb-1">
                  Author
                </label>
                <input
                  type="text"
                  placeholder="e.g. Robert Greene, James Clear"
                  value={editAuthor}
                  onChange={(e) => setEditAuthor(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500/40"
                />
              </div>

              {/* Folder Assignment */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-[10px] uppercase tracking-widest font-bold text-slate-400 dark:text-white/40">
                    Assign to Folder
                  </label>
                  {onSaveFolder && (
                    <button
                      type="button"
                      onClick={() => setIsCreatingFolder(true)}
                      className="text-[10px] font-bold text-orange-600 hover:underline"
                    >
                      + New Folder
                    </button>
                  )}
                </div>
                <select
                  value={editFolderId || ''}
                  onChange={(e) => setEditFolderId(e.target.value ? e.target.value : null)}
                  className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500/40"
                >
                  <option value="">(No Folder / Root Library)</option>
                  {folders.map(f => (
                    <option key={f.id} value={f.id}>{f.name}</option>
                  ))}
                </select>
              </div>

              {/* Reading Status */}
              <div>
                <label className="block text-[10px] uppercase tracking-widest font-bold text-slate-400 dark:text-white/40 mb-1">
                  Reading Status
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'unread', label: 'Unread', icon: FileText },
                    { id: 'want-to-read', label: 'Want to Read', icon: BookMarked },
                    { id: 'reading', label: 'Currently Reading', icon: BookOpen },
                    { id: 'finished', label: 'Finished', icon: CheckCircle2 },
                  ].map(s => {
                    const isSelected = editReadingStatus === s.id;
                    const Icon = s.icon;
                    return (
                      <button
                        type="button"
                        key={s.id}
                        onClick={() => setEditReadingStatus(s.id as any)}
                        className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all text-left ${
                          isSelected 
                            ? 'border-orange-600 bg-orange-500/10 text-orange-600 dark:text-orange-400' 
                            : 'border-slate-200 dark:border-white/5 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-white/5'
                        }`}
                      >
                        <Icon className="h-3.5 w-3.5 shrink-0" />
                        <span className="truncate">{s.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Collections Checklist */}
              {collections.length > 0 && (
                <div>
                  <label className="block text-[10px] uppercase tracking-widest font-bold text-slate-400 dark:text-white/40 mb-1.5">
                    Shelves & Collections
                  </label>
                  <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pr-1">
                    {collections.map(c => {
                      const isIncluded = editCollectionIds.includes(c.id);
                      return (
                        <button
                          type="button"
                          key={c.id}
                          onClick={() => {
                            setEditCollectionIds(prev => 
                              isIncluded ? prev.filter(id => id !== c.id) : [...prev, c.id]
                            );
                          }}
                          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-bold transition-all ${
                            isIncluded 
                              ? 'bg-orange-600 text-white' 
                              : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-white/10'
                          }`}
                        >
                          <Tag className="h-3 w-3" />
                          <span>{c.name}</span>
                          {isIncluded && <Check className="h-3 w-3 stroke-[3px]" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Modal Action Buttons */}
              <div className="flex gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setOrganizingBook(null)}
                  className="flex-1 py-3 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5 rounded-xl transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 text-xs font-bold uppercase tracking-wider bg-orange-600 text-white hover:bg-orange-700 rounded-xl shadow-lg shadow-orange-600/20 transition-all cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- FOLDER CREATE / RENAME DIALOG ----------------- */}
      {(isCreatingFolder || isRenamingFolderId) && (
        <div className="fixed inset-0 z-[140] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-white dark:bg-[#1A1A1A] rounded-2xl shadow-2xl border border-slate-200 dark:border-white/10 p-6 scale-in-center">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <FolderIcon className="h-5 w-5 text-orange-600" />
                <span>{isRenamingFolderId ? 'Rename Folder' : 'New Folder'}</span>
              </h3>
              <button 
                onClick={() => {
                  setIsCreatingFolder(false);
                  setIsRenamingFolderId(null);
                  setFolderNameInput('');
                }}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleFolderAction}>
              <div className="mb-4">
                <label className="block text-[10px] uppercase tracking-widest font-bold text-slate-400 dark:text-white/30 mb-2">
                  Folder Name
                </label>
                <input
                  type="text"
                  autoFocus
                  value={folderNameInput}
                  onChange={(e) => setFolderNameInput(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/50 text-slate-900 dark:text-white"
                  placeholder="e.g. Science, Philosophy, Exams..."
                  required
                />
              </div>

              {/* Color Selection */}
              <div className="mb-6">
                <label className="block text-[10px] uppercase tracking-widest font-bold text-slate-400 dark:text-white/30 mb-2">
                  Folder Color
                </label>
                <div className="flex items-center gap-2">
                  {FOLDER_COLORS.map(c => (
                    <button
                      type="button"
                      key={c}
                      onClick={() => setFolderColorInput(c)}
                      className={`w-7 h-7 rounded-full transition-transform flex items-center justify-center ${
                        folderColorInput === c ? 'scale-110 ring-2 ring-offset-2 ring-orange-500' : 'hover:scale-105'
                      }`}
                      style={{ backgroundColor: c }}
                    >
                      {folderColorInput === c && <Check className="h-3.5 w-3.5 text-white stroke-[3px]" />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setIsCreatingFolder(false);
                    setIsRenamingFolderId(null);
                    setFolderNameInput('');
                  }}
                  className="flex-1 py-3 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 text-xs font-bold uppercase tracking-wider bg-orange-600 text-white hover:bg-orange-700 rounded-xl shadow-lg shadow-orange-600/20"
                >
                  {isRenamingFolderId ? 'Update' : 'Create Folder'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- COLLECTION CREATE / RENAME DIALOG ----------------- */}
      {(isCreatingCollection || isRenamingCollectionId) && (
        <div className="fixed inset-0 z-[140] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-white dark:bg-[#1A1A1A] rounded-2xl shadow-2xl border border-slate-200 dark:border-white/10 p-6 scale-in-center">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Tag className="h-5 w-5 text-orange-600" />
                <span>{isRenamingCollectionId ? 'Rename Shelf' : 'New Collection Shelf'}</span>
              </h3>
              <button 
                onClick={() => {
                  setIsCreatingCollection(false);
                  setIsRenamingCollectionId(null);
                  setCollectionNameInput('');
                }}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCollectionAction}>
              <div className="mb-6">
                <label className="block text-[10px] uppercase tracking-widest font-bold text-slate-400 dark:text-white/30 mb-2">
                  Shelf Name
                </label>
                <input
                  type="text"
                  autoFocus
                  value={collectionNameInput}
                  onChange={(e) => setCollectionNameInput(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/50 text-slate-900 dark:text-white"
                  placeholder="e.g. Must Read, Business, Fiction..."
                  required
                />
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setIsCreatingCollection(false);
                    setIsRenamingCollectionId(null);
                    setCollectionNameInput('');
                  }}
                  className="flex-1 py-3 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 text-xs font-bold uppercase tracking-wider bg-orange-600 text-white hover:bg-orange-700 rounded-xl shadow-lg shadow-orange-600/20"
                >
                  {isRenamingCollectionId ? 'Update' : 'Create Shelf'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- DELETE COLLECTION CONFIRMATION ----------------- */}
      {collectionToDelete && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-white dark:bg-[#1A1A1A] rounded-2xl shadow-2xl border border-slate-200 dark:border-white/10 p-8 scale-in-center overflow-hidden">
            {deleteStep === 'initial' && (
              <div>
                <div className="w-16 h-16 bg-red-50 dark:bg-red-500/10 rounded-full flex items-center justify-center mb-6 mx-auto">
                  <Trash2 className="h-8 w-8 text-red-500" />
                </div>
                <h3 className="text-xl font-bold text-center text-slate-900 dark:text-white mb-2">Delete Shelf?</h3>
                <p className="text-sm text-center text-slate-400 dark:text-white/40 mb-8 px-2">
                  Are you sure you want to delete <span className="font-bold text-slate-700 dark:text-slate-200">"{collectionToDelete.name}"</span>? 
                  The books inside will remain safely in your library.
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => setCollectionToDelete(null)}
                    className="flex-1 py-3 text-xs font-bold uppercase tracking-wider text-slate-500 hover:bg-slate-100 rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => setDeleteStep('confirm')}
                    className="flex-1 py-3 text-xs font-bold uppercase tracking-wider bg-red-600 text-white hover:bg-red-700 rounded-xl shadow-md"
                  >
                    Continue
                  </button>
                </div>
              </div>
            )}
            {deleteStep === 'confirm' && (
              <div>
                <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center mb-6 mx-auto shadow-lg">
                  <AlertCircle className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-center text-slate-900 dark:text-white mb-2">Confirm Delete</h3>
                <p className="text-sm text-center text-slate-400 dark:text-white/40 mb-8">
                  This shelf will be removed. Your books will not be affected.
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => setDeleteStep('initial')}
                    className="flex-1 py-3 text-xs font-bold uppercase tracking-wider text-slate-500 hover:bg-slate-100 rounded-xl"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleConfirmDeleteCollection}
                    className="flex-1 py-3 text-xs font-bold uppercase tracking-wider bg-red-600 text-white hover:bg-red-700 rounded-xl shadow-md"
                  >
                    Delete Shelf
                  </button>
                </div>
              </div>
            )}
            {deleteStep === 'success' && (
              <div>
                <div className="w-16 h-16 bg-emerald-500 rounded-full flex items-center justify-center mb-6 mx-auto shadow-lg">
                  <Check className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-center text-slate-900 dark:text-white mb-2">Shelf Deleted</h3>
                <p className="text-sm text-center text-slate-400 mb-8">Collection removed successfully.</p>
                <button
                  onClick={() => {
                    setCollectionToDelete(null);
                    setDeleteStep('initial');
                    if (selectedCollectionId === collectionToDelete.id) {
                      setSelectedCollectionId(null);
                    }
                  }}
                  className="w-full py-3 text-xs font-bold uppercase tracking-wider bg-slate-900 text-white rounded-xl"
                >
                  Done
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ----------------- DELETE FOLDER CONFIRMATION ----------------- */}
      {folderToDelete && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-white dark:bg-[#1A1A1A] rounded-2xl shadow-2xl border border-slate-200 dark:border-white/10 p-8 scale-in-center overflow-hidden">
            {deleteStep === 'initial' && (
              <div>
                <div className="w-16 h-16 bg-red-50 dark:bg-red-500/10 rounded-full flex items-center justify-center mb-6 mx-auto">
                  <Trash2 className="h-8 w-8 text-red-500" />
                </div>
                <h3 className="text-xl font-bold text-center text-slate-900 dark:text-white mb-2">Delete Folder?</h3>
                <p className="text-sm text-center text-slate-400 dark:text-white/40 mb-8 px-2">
                  Are you sure you want to delete <span className="font-bold text-slate-700 dark:text-slate-200">"{folderToDelete.name}"</span>? 
                  All books will remain safe in your library.
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => setFolderToDelete(null)}
                    className="flex-1 py-3 text-xs font-bold uppercase tracking-wider text-slate-500 hover:bg-slate-100 rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => setDeleteStep('confirm')}
                    className="flex-1 py-3 text-xs font-bold uppercase tracking-wider bg-red-600 text-white hover:bg-red-700 rounded-xl shadow-md"
                  >
                    Continue
                  </button>
                </div>
              </div>
            )}
            {deleteStep === 'confirm' && (
              <div>
                <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center mb-6 mx-auto shadow-lg">
                  <AlertCircle className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-center text-slate-900 dark:text-white mb-2">Confirm Delete</h3>
                <p className="text-sm text-center text-slate-400 dark:text-white/40 mb-8">
                  Folder will be deleted. Books inside will move to general library.
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => setDeleteStep('initial')}
                    className="flex-1 py-3 text-xs font-bold uppercase tracking-wider text-slate-500 hover:bg-slate-100 rounded-xl"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleConfirmDeleteFolder}
                    className="flex-1 py-3 text-xs font-bold uppercase tracking-wider bg-red-600 text-white hover:bg-red-700 rounded-xl shadow-md"
                  >
                    Delete Folder
                  </button>
                </div>
              </div>
            )}
            {deleteStep === 'success' && (
              <div>
                <div className="w-16 h-16 bg-emerald-500 rounded-full flex items-center justify-center mb-6 mx-auto shadow-lg">
                  <Check className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-center text-slate-900 dark:text-white mb-2">Folder Deleted</h3>
                <p className="text-sm text-center text-slate-400 mb-8">Folder removed successfully.</p>
                <button
                  onClick={() => {
                    setFolderToDelete(null);
                    setDeleteStep('initial');
                    if (selectedFolderId === folderToDelete.id) {
                      setSelectedFolderId(null);
                    }
                  }}
                  className="w-full py-3 text-xs font-bold uppercase tracking-wider bg-slate-900 text-white rounded-xl"
                >
                  Done
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ----------------- DELETE BOOK CONFIRMATION ----------------- */}
      {bookToDelete && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-white dark:bg-[#1A1A1A] rounded-2xl shadow-2xl border border-slate-200 dark:border-white/10 p-8 scale-in-center overflow-hidden">
            {deleteStep === 'initial' && (
              <div>
                <div className="w-16 h-16 bg-red-50 dark:bg-red-500/10 rounded-full flex items-center justify-center mb-6 mx-auto">
                  <Trash2 className="h-8 w-8 text-red-500" />
                </div>
                <h3 className="text-xl font-bold text-center text-slate-900 dark:text-white mb-2">Delete Book?</h3>
                <p className="text-sm text-center text-slate-400 dark:text-white/40 mb-8 px-2">
                  Are you sure you want to delete <span className="font-bold text-slate-700 dark:text-slate-200">"{bookToDelete.title}"</span>? 
                  This will remove the file and all bookmarks.
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => setBookToDelete(null)}
                    className="flex-1 py-3 text-xs font-bold uppercase tracking-wider text-slate-500 hover:bg-slate-100 rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => setDeleteStep('confirm')}
                    className="flex-1 py-3 text-xs font-bold uppercase tracking-wider bg-red-600 text-white hover:bg-red-700 rounded-xl shadow-md"
                  >
                    Continue
                  </button>
                </div>
              </div>
            )}
            {deleteStep === 'confirm' && (
              <div>
                <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center mb-6 mx-auto shadow-lg">
                  <AlertCircle className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-center text-slate-900 dark:text-white mb-2">Final Warning</h3>
                <p className="text-sm text-center text-slate-400 dark:text-white/40 mb-8">
                  This action cannot be undone. All reading progress for this copy will be deleted.
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => setDeleteStep('initial')}
                    className="flex-1 py-3 text-xs font-bold uppercase tracking-wider text-slate-500 hover:bg-slate-100 rounded-xl"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleConfirmDeleteBook}
                    className="flex-1 py-3 text-xs font-bold uppercase tracking-wider bg-red-600 text-white hover:bg-red-700 rounded-xl shadow-md"
                  >
                    Delete Book
                  </button>
                </div>
              </div>
            )}
            {deleteStep === 'success' && (
              <div>
                <div className="w-16 h-16 bg-emerald-500 rounded-full flex items-center justify-center mb-6 mx-auto shadow-lg">
                  <Check className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-center text-slate-900 dark:text-white mb-2">Book Deleted</h3>
                <p className="text-sm text-center text-slate-400 mb-8">Book has been removed.</p>
                <button
                  onClick={() => {
                    setBookToDelete(null);
                    setDeleteStep('initial');
                  }}
                  className="w-full py-3 text-xs font-bold uppercase tracking-wider bg-slate-900 text-white rounded-xl"
                >
                  Done
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ----------------- MULTI-SELECT ADD TO SHELF MODAL ----------------- */}
      {selectingShelfForBooks && selectedCollectionId && (
        <div className="fixed inset-0 z-[140] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="w-full max-w-2xl bg-white dark:bg-[#1A1A1A] rounded-3xl shadow-2xl border border-slate-200 dark:border-white/10 p-6 sm:p-8 scale-in-center max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
                  Add Books to Shelf
                </h3>
                <p className="text-xs text-orange-600 dark:text-orange-400 font-bold mt-0.5">
                  Shelf: {collections.find(c => c.id === selectedCollectionId)?.name}
                </p>
              </div>
              <button 
                onClick={() => setSelectingShelfForBooks(false)}
                className="text-slate-400 hover:text-slate-900 dark:hover:text-white p-2 rounded-full"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {books.map(book => {
                const inShelf = book.collectionIds?.includes(selectedCollectionId);
                return (
                  <button
                    key={book.id}
                    onClick={() => toggleBookCollection(book, selectedCollectionId)}
                    className={`w-full flex items-center justify-between p-3 rounded-2xl border text-left transition-all ${
                      inShelf 
                        ? 'border-orange-600 bg-orange-500/10 text-orange-700 dark:text-orange-400' 
                        : 'border-slate-100 dark:border-white/5 hover:bg-slate-50 dark:hover:bg-white/5 text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-9 h-12 bg-slate-200 dark:bg-zinc-800 rounded-lg overflow-hidden shrink-0">
                        {book.thumbnail ? (
                          <img src={book.thumbnail} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-[10px] font-bold text-slate-400">
                            {getInitials(book.title)}
                          </div>
                        )}
                      </div>
                      <div className="truncate">
                        <p className="text-xs font-bold truncate">{book.title}</p>
                        <p className="text-[10px] text-slate-400">{book.author || 'Unknown Author'}</p>
                      </div>
                    </div>
                    {inShelf && <Check className="h-4 w-4 text-orange-600 stroke-[3px]" />}
                  </button>
                );
              })}
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-white/5">
              <button
                onClick={() => setSelectingShelfForBooks(false)}
                className="w-full py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl text-xs font-bold uppercase tracking-wider"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ----------------- MULTI-SELECT ADD TO FOLDER MODAL ----------------- */}
      {selectingFolderForBooks && selectedFolderId && (
        <div className="fixed inset-0 z-[140] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="w-full max-w-2xl bg-white dark:bg-[#1A1A1A] rounded-3xl shadow-2xl border border-slate-200 dark:border-white/10 p-6 sm:p-8 scale-in-center max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
                  Add Books to Folder
                </h3>
                <p className="text-xs text-orange-600 dark:text-orange-400 font-bold mt-0.5">
                  Folder: {folders.find(f => f.id === selectedFolderId)?.name}
                </p>
              </div>
              <button 
                onClick={() => setSelectingFolderForBooks(false)}
                className="text-slate-400 hover:text-slate-900 dark:hover:text-white p-2 rounded-full"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {books.map(book => {
                const inFolder = book.folderId === selectedFolderId;
                return (
                  <button
                    key={book.id}
                    onClick={() => toggleBookFolder(book, inFolder ? null : selectedFolderId)}
                    className={`w-full flex items-center justify-between p-3 rounded-2xl border text-left transition-all ${
                      inFolder 
                        ? 'border-orange-600 bg-orange-500/10 text-orange-700 dark:text-orange-400' 
                        : 'border-slate-100 dark:border-white/5 hover:bg-slate-50 dark:hover:bg-white/5 text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-9 h-12 bg-slate-200 dark:bg-zinc-800 rounded-lg overflow-hidden shrink-0">
                        {book.thumbnail ? (
                          <img src={book.thumbnail} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-[10px] font-bold text-slate-400">
                            {getInitials(book.title)}
                          </div>
                        )}
                      </div>
                      <div className="truncate">
                        <p className="text-xs font-bold truncate">{book.title}</p>
                        <p className="text-[10px] text-slate-400">{book.author || 'Unknown Author'}</p>
                      </div>
                    </div>
                    {inFolder && <Check className="h-4 w-4 text-orange-600 stroke-[3px]" />}
                  </button>
                );
              })}
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-white/5">
              <button
                onClick={() => setSelectingFolderForBooks(false)}
                className="w-full py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl text-xs font-bold uppercase tracking-wider"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

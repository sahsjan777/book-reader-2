import React, { useState, useEffect } from 'react';
import { 
  MessageSquare, Star, Send, CheckCircle2, Sparkles, 
  ThumbsUp, Bug, Lightbulb, MessageCircle, Clock, Trash2,
  Mail, ExternalLink, Copy, Check, ArrowUpRight, HelpCircle,
  Globe, Rocket, X, Bell
} from 'lucide-react';

export interface UserFeedback {
  id: string;
  rating: number;
  category: 'general' | 'bug' | 'feature' | 'reader' | 'other';
  title?: string;
  message: string;
  userName?: string;
  email?: string;
  createdAt: number;
}

const SUPPORT_EMAIL = 'trayal168@gmail.com';
const WEBSITE_URL = 'https://www.smartbookreader.com';

const CATEGORIES: { id: UserFeedback['category']; label: string; icon: React.ReactNode }[] = [
  { id: 'general', label: 'General Review', icon: <MessageCircle className="w-3.5 h-3.5" /> },
  { id: 'feature', label: 'Feature Request', icon: <Lightbulb className="w-3.5 h-3.5" /> },
  { id: 'bug', label: 'Bug / Issue', icon: <Bug className="w-3.5 h-3.5" /> },
  { id: 'reader', label: 'Reading Experience', icon: <Sparkles className="w-3.5 h-3.5" /> },
  { id: 'other', label: 'Other Support', icon: <ThumbsUp className="w-3.5 h-3.5" /> },
];

const RATING_LABELS = ['', 'Needs Improvement', 'Fair', 'Good', 'Very Good', 'Excellent!'];

export const FeedbackSection: React.FC = () => {
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [category, setCategory] = useState<UserFeedback['category']>('general');
  const [userName, setUserName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [feedbacks, setFeedbacks] = useState<UserFeedback[]>([]);
  const [copiedEmail, setCopiedEmail] = useState(false);

  // Website Coming Soon state
  const [showWebsiteModal, setShowWebsiteModal] = useState(false);
  const [subscribeEmail, setSubscribeEmail] = useState('');
  const [subscribeSuccess, setSubscribeSuccess] = useState(false);

  // Load existing feedbacks from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem('user_feedbacks');
      if (stored) {
        setFeedbacks(JSON.parse(stored));
      }
    } catch (e) {
      console.error('Failed to load feedbacks', e);
    }
  }, []);

  const handleCopyEmail = () => {
    navigator.clipboard?.writeText(SUPPORT_EMAIL);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const getMailtoUrl = () => {
    const subject = encodeURIComponent(`Smart Book Reader Feedback - [${category.toUpperCase()}]`);
    const body = encodeURIComponent(
      `Hello,\n\nI am sharing feedback for Smart Book Reader:\n\nRating: ${rating} / 5 (${RATING_LABELS[rating]})\nCategory: ${category}\nName: ${userName || 'User'}\n\nFeedback message:\n${message || '(Write details here...)'}\n\n--\nSent from Smart Book Reader`
    );
    return `mailto:${SUPPORT_EMAIL}?subject=${subject}&body=${body}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    setIsSubmitting(true);

    const newFeedback: UserFeedback = {
      id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
      rating,
      category,
      message: message.trim(),
      userName: userName.trim() || undefined,
      email: email.trim() || undefined,
      createdAt: Date.now(),
    };

    try {
      // Send to backend API
      await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newFeedback),
      }).catch(err => console.warn('Backend feedback log error:', err));
    } catch (e) {
      console.warn('API call failed, continuing local save');
    }

    const updated = [newFeedback, ...feedbacks];
    setFeedbacks(updated);
    try {
      localStorage.setItem('user_feedbacks', JSON.stringify(updated));
    } catch (err) {
      console.error('Failed to save feedback to storage', err);
    }

    setIsSubmitting(false);
    setSubmitted(true);
  };

  const handleDeleteFeedback = (id: string) => {
    const updated = feedbacks.filter(f => f.id !== id);
    setFeedbacks(updated);
    try {
      localStorage.setItem('user_feedbacks', JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to delete feedback', e);
    }
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-orange-500/10 via-amber-500/5 to-transparent border border-orange-500/20 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-orange-500/15 text-orange-600 dark:text-orange-400 w-fit">
              <Mail className="w-3.5 h-3.5" />
              <span>Email Feedback & Support Page</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
              Send Your Feedback & Suggestions
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-300 max-w-2xl leading-relaxed">
              Humare product ko behtar banane ke liye aapka feedback zaroori hai. Aap direct form se bhej sakte hain ya seedha humare support email par mail kar sakte hain.
            </p>
          </div>

          {/* Contact Us, Email & Website options */}
          <div className="flex flex-col sm:flex-row md:flex-col gap-2.5 shrink-0">
            {/* Website Link / Contact Us Pill Card */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-orange-600/10 via-amber-500/10 to-transparent border border-orange-500/30 shadow-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="h-8 w-8 rounded-xl bg-orange-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Globe className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <div className="flex items-center gap-1.5">
                    <span className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider">Official Website</span>
                    <span className="px-1.5 py-0.5 rounded text-[8.5px] font-bold bg-amber-500/20 text-amber-600 dark:text-amber-400">Coming Soon</span>
                  </div>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                    smartbookreader.com
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowWebsiteModal(true)}
                className="px-3 py-1.5 rounded-lg bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold flex items-center gap-1 transition-transform active:scale-95 cursor-pointer shadow-xs"
              >
                <span>Open Website</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Email badge pill card */}
            <div className="p-3.5 rounded-2xl bg-white/80 dark:bg-black/40 border border-slate-200 dark:border-white/10 shadow-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="h-8 w-8 rounded-xl bg-slate-800 dark:bg-zinc-700 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Mail className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <span className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider">Contact Us Email</span>
                  <a 
                    href={`mailto:${SUPPORT_EMAIL}`}
                    className="text-xs font-bold text-orange-600 dark:text-orange-400 hover:underline select-all"
                  >
                    {SUPPORT_EMAIL}
                  </a>
                </div>
              </div>

              <button
                type="button"
                onClick={handleCopyEmail}
                className="p-1.5 rounded-lg border border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/10 text-slate-600 dark:text-slate-300 transition-colors cursor-pointer"
                title="Copy email address"
              >
                {copiedEmail ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            <a
              href={getMailtoUrl()}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold shadow-xs transition-transform active:scale-95 cursor-pointer text-center"
            >
              <span>Open in Gmail / Email App</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Feedback Form Card */}
        <div className="lg:col-span-7 rounded-3xl liquid-glass-card p-6 sm:p-8 border shadow-lg">
          {submitted ? (
            <div className="py-10 text-center flex flex-col items-center gap-4">
              <div className="h-16 w-16 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center animate-bounce">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <div className="space-y-1">
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                  Shukriya! Feedback Received
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm">
                  Aapka feedback record ho chuka hai aur <b>{SUPPORT_EMAIL}</b> team ke paas note ho gaya hai.
                </p>
              </div>

              <div className="pt-2 flex flex-wrap gap-2 justify-center">
                <a
                  href={getMailtoUrl()}
                  className="px-4 py-2 rounded-xl border border-orange-500/40 text-orange-600 dark:text-orange-400 hover:bg-orange-500/10 text-xs font-semibold inline-flex items-center gap-1.5 transition-colors"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Send via Gmail Client</span>
                </a>
                <button
                  type="button"
                  onClick={() => {
                    setSubmitted(false);
                    setMessage('');
                    setUserName('');
                    setEmail('');
                  }}
                  className="px-5 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold tracking-wide transition-all cursor-pointer shadow-xs active:scale-98"
                >
                  Submit Another Feedback
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Star Rating */}
              <div className="space-y-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Rate your experience
                </label>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => {
                      const isActive = (hoverRating || rating) >= star;
                      return (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRating(star)}
                          onMouseEnter={() => setHoverRating(star)}
                          onMouseLeave={() => setHoverRating(0)}
                          className="p-1 rounded-md transition-transform hover:scale-115 cursor-pointer text-amber-400 focus:outline-hidden"
                          aria-label={`Rate ${star} star`}
                        >
                          <Star 
                            className={`w-7 h-7 ${isActive ? 'fill-amber-400 text-amber-400' : 'text-slate-300 dark:text-slate-700'}`} 
                          />
                        </button>
                      );
                    })}
                  </div>
                  <span className="text-xs font-medium text-slate-600 dark:text-slate-300 ml-2">
                    {RATING_LABELS[hoverRating || rating]}
                  </span>
                </div>
              </div>

              {/* Category Pills */}
              <div className="space-y-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Feedback Category
                </label>
                <div className="flex flex-wrap gap-2">
                  {CATEGORIES.map((cat) => {
                    const isSelected = category === cat.id;
                    return (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setCategory(cat.id)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer border ${
                          isSelected
                            ? 'bg-orange-600 text-white border-orange-600 shadow-xs'
                            : 'border-slate-200 dark:border-white/10 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-white/5'
                        }`}
                      >
                        {cat.icon}
                        <span>{cat.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Message */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label htmlFor="feedback-message" className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Your Feedback / Suggestion *
                  </label>
                  <span className="text-[10px] text-slate-400">
                    {message.length} characters
                  </span>
                </div>
                <textarea
                  id="feedback-message"
                  required
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="App kaisa laga? Koi naya feature chahiye, ya koi dikkat aayi? Apni raye yahan likhein (will be directed to trayal168@gmail.com)..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-black/30 text-slate-900 dark:text-white placeholder:text-slate-400 text-xs sm:text-sm focus:outline-hidden focus:border-orange-500 focus:ring-1 focus:ring-orange-500 transition-all resize-y min-h-[100px]"
                />
              </div>

              {/* Optional Name & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label htmlFor="feedback-username" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                    Your Name (Optional)
                  </label>
                  <input
                    id="feedback-username"
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="e.g. Asad Ali / Rahul"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-black/30 text-slate-900 dark:text-white placeholder:text-slate-400 text-xs focus:outline-hidden focus:border-orange-500 transition-all"
                  />
                </div>
                <div className="space-y-1.5">
                  <label htmlFor="feedback-email" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                    Your Email (For reply)
                  </label>
                  <input
                    id="feedback-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your-email@example.com"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-black/30 text-slate-900 dark:text-white placeholder:text-slate-400 text-xs focus:outline-hidden focus:border-orange-500 transition-all"
                  />
                </div>
              </div>

              {/* Send Buttons (Direct & Email Client) */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting || !message.trim()}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 px-5 rounded-xl text-xs font-bold uppercase tracking-wider text-white shadow-md transition-all cursor-pointer ${
                    !message.trim() || isSubmitting
                      ? 'bg-slate-300 dark:bg-slate-800 text-slate-500 cursor-not-allowed'
                      : 'bg-orange-600 hover:bg-orange-700 active:scale-98 shadow-orange-500/20'
                  }`}
                >
                  {isSubmitting ? (
                    <span>Submitting...</span>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Submit Feedback</span>
                    </>
                  )}
                </button>

                <a
                  href={getMailtoUrl()}
                  className="flex items-center justify-center gap-1.5 py-3 px-4 rounded-xl text-xs font-semibold border border-slate-300 dark:border-white/15 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/5 transition-colors cursor-pointer text-center"
                >
                  <Mail className="w-4 h-4 text-orange-500" />
                  <span>Send via Email Client</span>
                </a>
              </div>

              <div className="flex items-center justify-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 text-center">
                <span>Direct recipient:</span>
                <span className="font-semibold text-orange-600 dark:text-orange-400">{SUPPORT_EMAIL}</span>
              </div>
            </form>
          )}
        </div>

        {/* Side Section: Contact Information & History */}
        <div className="lg:col-span-5 space-y-5">
          {/* Email Info Card */}
          <div className="rounded-3xl liquid-glass-card p-6 border shadow-lg space-y-4">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-orange-500/10 text-orange-600 dark:text-orange-400">
                <Mail className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Contact & Support
              </h3>
            </div>

            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
              <p>
                Aap seedha email bhej kar bhi support le sakte hain ya naye features ke bare mein mashwara de sakte hain:
              </p>
              <div className="p-3 rounded-xl bg-slate-100 dark:bg-white/5 flex items-center justify-between">
                <span className="font-mono font-bold text-slate-900 dark:text-white select-all">
                  {SUPPORT_EMAIL}
                </span>
                <button
                  type="button"
                  onClick={handleCopyEmail}
                  className="text-xs text-orange-600 dark:text-orange-400 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  {copiedEmail ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedEmail ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-200 dark:border-white/10 flex items-center justify-between text-[11px] text-slate-400">
              <span>Response time: Usually within 24 hours</span>
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </div>
          </div>

          {/* Previous Feedbacks Section */}
          <div className="rounded-3xl liquid-glass-card p-6 border shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-orange-500" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Your Submitted Feedbacks ({feedbacks.length})
                </h3>
              </div>
              {feedbacks.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    if (confirm('Clear your feedback history from this device?')) {
                      setFeedbacks([]);
                      localStorage.removeItem('user_feedbacks');
                    }
                  }}
                  className="text-[10px] text-slate-400 hover:text-red-500 transition-colors cursor-pointer"
                >
                  Clear All
                </button>
              )}
            </div>

            {feedbacks.length === 0 ? (
              <div className="py-8 text-center text-slate-400 space-y-1">
                <MessageSquare className="w-8 h-8 mx-auto opacity-30 stroke-1" />
                <p className="text-xs font-medium">No feedback submitted yet</p>
                <p className="text-[11px] opacity-75">Aapka send kiya hua feedback yahan save rahega.</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                {feedbacks.map((item) => (
                  <div 
                    key={item.id}
                    className="p-3.5 rounded-xl border border-slate-100 dark:border-white/5 bg-slate-50/60 dark:bg-white/5 space-y-2 relative group"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star 
                              key={s} 
                              className={`w-3 h-3 ${s <= item.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300 dark:text-slate-700'}`} 
                            />
                          ))}
                        </div>
                        <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-orange-500/10 text-orange-600 dark:text-orange-400 font-medium capitalize">
                          {item.category}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDeleteFeedback(item.id)}
                        className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500 transition-all p-1 cursor-pointer"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                      {item.message}
                    </p>

                    <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-200/50 dark:border-white/5">
                      <span>{item.userName || 'Anonymous User'}</span>
                      <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      {/* Official Website - Coming Soon Modal */}
      {showWebsiteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-white/10 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
            {/* Browser Mockup Top Bar */}
            <div className="px-4 py-3 bg-slate-100 dark:bg-zinc-800 border-b border-slate-200 dark:border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-red-400 inline-block"></span>
                <span className="w-3 h-3 rounded-full bg-amber-400 inline-block"></span>
                <span className="w-3 h-3 rounded-full bg-emerald-400 inline-block"></span>
                <div className="ml-2 px-3 py-1 rounded-full bg-white dark:bg-black/40 border border-slate-200 dark:border-white/10 text-[11px] font-mono text-slate-600 dark:text-slate-300 flex items-center gap-1.5 shadow-2xs">
                  <Globe className="w-3 h-3 text-orange-500" />
                  <span>https://www.smartbookreader.com</span>
                </div>
              </div>
              <button
                onClick={() => setShowWebsiteModal(false)}
                className="p-1 rounded-full hover:bg-slate-200 dark:hover:bg-white/10 text-slate-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Coming Soon Hero Body */}
            <div className="p-6 sm:p-8 text-center flex flex-col items-center space-y-4">
              <div className="h-16 w-16 rounded-2xl bg-orange-600/10 text-orange-600 flex items-center justify-center shadow-inner">
                <Rocket className="w-8 h-8 animate-pulse" />
              </div>

              <div className="space-y-1.5">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                  <span>🚀 Coming Soon (जल्द आ रही है)</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                  Smart Book Reader Official Website
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 max-w-sm leading-relaxed">
                  Hum abhi apni official website tayar kar rahe hain! Jald hi live hogi jahan aapko latest updates, book downloads, aur customer assistance milega.
                </p>
              </div>

              {/* Notify form */}
              <div className="w-full pt-2">
                {subscribeSuccess ? (
                  <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Shukriya! Website live hote hi aapko email bhej di jayegi.</span>
                  </div>
                ) : (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (subscribeEmail.trim()) {
                        setSubscribeSuccess(true);
                      }
                    }}
                    className="flex flex-col sm:flex-row gap-2"
                  >
                    <input
                      type="email"
                      required
                      placeholder="Apna email darj karein (e.g. user@gmail.com)"
                      value={subscribeEmail}
                      onChange={(e) => setSubscribeEmail(e.target.value)}
                      className="flex-1 text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-white/10 bg-slate-50 dark:bg-black/30 text-slate-800 dark:text-white focus:outline-orange-500"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold transition-all cursor-pointer shadow-xs whitespace-nowrap active:scale-95"
                    >
                      Notify Me
                    </button>
                  </form>
                )}
              </div>

              {/* Direct support email in modal */}
              <div className="pt-2 text-[11px] text-slate-500 dark:text-slate-400 border-t border-slate-200 dark:border-white/10 w-full flex items-center justify-between">
                <span>Direct Contact:</span>
                <a
                  href={`mailto:${SUPPORT_EMAIL}`}
                  className="font-semibold text-orange-600 dark:text-orange-400 hover:underline"
                >
                  {SUPPORT_EMAIL}
                </a>
              </div>
            </div>

            {/* Footer */}
            <div className="p-3 bg-slate-50 dark:bg-zinc-800/60 border-t border-slate-200 dark:border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setShowWebsiteModal(false)}
                className="px-4 py-1.5 rounded-xl border text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

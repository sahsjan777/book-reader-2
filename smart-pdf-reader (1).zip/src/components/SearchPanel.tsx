/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Search, X, Loader2, FileText, ChevronRight, ChevronLeft, History, Trash2, ArrowRight } from 'lucide-react';

interface SearchPanelProps {
  pdf: any; // pdfjs-dist document proxy
  currentPage: number;
  theme?: 'light' | 'dark';
  searchQuery: string;
  onSearchQueryChange: (query: string) => void;
  onJumpToPage: (pageNumber: number, snippet?: string) => void;
  onClose: () => void;
}

interface SearchOccurrence {
  pageNumber: number;
  snippet: string;
  matchIndexOnPage: number;
  globalIndex: number;
}

interface PageMatchGroup {
  pageNumber: number;
  count: number;
  occurrences: SearchOccurrence[];
}

const HISTORY_STORAGE_KEY = 'smart_pdf_inbook_search_history';

const escapeRegExp = (string: string) => {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
};

const getPageText = async (pdfDoc: any, pageNum: number): Promise<string> => {
  try {
    const page = await pdfDoc.getPage(pageNum);
    const textContent = await page.getTextContent();
    if (textContent && textContent.items) {
      return textContent.items.map((item: any) => item.str || '').join(' ');
    }
  } catch (err) {
    console.warn(`Error getting text for page ${pageNum}:`, err);
  }
  return '';
};

export default function SearchPanel({
  pdf,
  currentPage,
  theme = 'light',
  searchQuery,
  onSearchQueryChange,
  onJumpToPage,
  onClose
}: SearchPanelProps) {
  const [pageMatches, setPageMatches] = useState<PageMatchGroup[]>([]);
  const [allOccurrences, setAllOccurrences] = useState<SearchOccurrence[]>([]);
  const [currentMatchIndex, setCurrentMatchIndex] = useState<number>(0);
  const [isSearching, setIsSearching] = useState(false);
  const [progress, setProgress] = useState(0);
  const [searchHistory, setSearchHistory] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(HISTORY_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const isDark = theme === 'dark';
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Save query to search history
  const addToHistory = (query: string) => {
    const q = query.trim();
    if (!q || q.length < 2) return;
    try {
      setSearchHistory(prev => {
        const filtered = prev.filter(item => item.toLowerCase() !== q.toLowerCase());
        const updated = [q, ...filtered].slice(0, 8);
        localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updated));
        return updated;
      });
    } catch (e) {
      console.warn('Failed to save search history', e);
    }
  };

  const clearHistory = () => {
    try {
      localStorage.removeItem(HISTORY_STORAGE_KEY);
      setSearchHistory([]);
    } catch {
      // ignore
    }
  };

  // Run full-book multi-word search progressively
  useEffect(() => {
    const trimmed = searchQuery.trim();
    if (!trimmed || trimmed.length < 2 || !pdf) {
      setPageMatches([]);
      setAllOccurrences([]);
      setIsSearching(false);
      setProgress(0);
      setCurrentMatchIndex(0);
      return;
    }

    let active = true;
    setIsSearching(true);
    setProgress(0);
    setPageMatches([]);
    setAllOccurrences([]);
    setCurrentMatchIndex(0);

    const runSearch = async () => {
      const q = trimmed.toLowerCase();
      // Split into words for multi-word search
      const words = q.split(/\s+/).filter(w => w.length > 0);
      const total = pdf.numPages;
      const groups: PageMatchGroup[] = [];
      const flatOccurrences: SearchOccurrence[] = [];

      for (let pageNum = 1; pageNum <= total; pageNum++) {
        if (!active) return;

        setProgress(Math.round((pageNum / total) * 100));

        const pageText = await getPageText(pdf, pageNum);
        if (!active) return;

        const pageTextLower = pageText.toLowerCase();

        // 1. Check for exact phrase first
        let hasMatch = false;
        let matchIndices: number[] = [];

        // Exact phrase search
        let pos = pageTextLower.indexOf(q);
        while (pos !== -1) {
          matchIndices.push(pos);
          pos = pageTextLower.indexOf(q, pos + 1);
        }

        // If no exact match and multiple words, check if all words exist on the page
        if (matchIndices.length === 0 && words.length > 1) {
          const allWordsPresent = words.every(w => pageTextLower.includes(w));
          if (allWordsPresent) {
            // Find first word occurrence as anchor
            let firstWordPos = pageTextLower.indexOf(words[0]);
            while (firstWordPos !== -1) {
              matchIndices.push(firstWordPos);
              firstWordPos = pageTextLower.indexOf(words[0], firstWordPos + 1);
            }
          }
        }

        if (matchIndices.length > 0) {
          const pageOccurrences: SearchOccurrence[] = [];

          matchIndices.forEach((matchIdx, idx) => {
            const start = Math.max(0, matchIdx - 40);
            const end = Math.min(pageText.length, matchIdx + q.length + 50);
            let snippet = pageText.substring(start, end).trim();
            if (start > 0) snippet = '...' + snippet;
            if (end < pageText.length) snippet = snippet + '...';

            const occ: SearchOccurrence = {
              pageNumber: pageNum,
              snippet,
              matchIndexOnPage: idx,
              globalIndex: flatOccurrences.length
            };

            pageOccurrences.push(occ);
            flatOccurrences.push(occ);
          });

          groups.push({
            pageNumber: pageNum,
            count: matchIndices.length,
            occurrences: pageOccurrences
          });

          setPageMatches([...groups]);
          setAllOccurrences([...flatOccurrences]);
        }

        // Yield main thread every 5 pages to keep UI responsive
        if (pageNum % 5 === 0) {
          await new Promise(resolve => setTimeout(resolve, 0));
        }
      }

      if (active) {
        setIsSearching(false);
        addToHistory(trimmed);
      }
    };

    const timer = setTimeout(() => {
      runSearch();
    }, 250);

    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [searchQuery, pdf]);

  // Jump to specific occurrence
  const handleJumpToOccurrence = (index: number) => {
    if (allOccurrences.length === 0) return;
    const bounded = Math.max(0, Math.min(allOccurrences.length - 1, index));
    setCurrentMatchIndex(bounded);
    const target = allOccurrences[bounded];
    if (target) {
      onJumpToPage(target.pageNumber, target.snippet);
    }
  };

  const handleNextMatch = () => {
    if (allOccurrences.length === 0) return;
    const nextIdx = (currentMatchIndex + 1) % allOccurrences.length;
    handleJumpToOccurrence(nextIdx);
  };

  const handlePrevMatch = () => {
    if (allOccurrences.length === 0) return;
    const prevIdx = (currentMatchIndex - 1 + allOccurrences.length) % allOccurrences.length;
    handleJumpToOccurrence(prevIdx);
  };

  const highlightSnippet = (text: string, highlight: string) => {
    if (!highlight) return text;
    const terms = highlight.trim().split(/\s+/).filter(Boolean);
    const pattern = terms.map(escapeRegExp).join('|');
    if (!pattern) return text;

    const parts = text.split(new RegExp(`(${pattern})`, 'gi'));
    return (
      <>
        {parts.map((part, i) => 
          terms.some(t => t.toLowerCase() === part.toLowerCase()) ? (
            <mark key={i} className="bg-orange-500/25 dark:bg-orange-500/40 text-orange-700 dark:text-orange-300 font-bold px-0.5 rounded">
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </>
    );
  };

  const totalCount = allOccurrences.length;

  return (
    <div className={`flex h-full flex-col transition-colors duration-300 ${
      isDark ? 'bg-[#0D0D0D] text-[#E0E0E0]' : 'bg-white text-slate-800'
    }`}>
      {/* Header */}
      <div className={`flex items-center justify-between border-b p-3.5 sm:p-4 ${
        isDark ? 'border-white/5' : 'border-slate-200'
      }`}>
        <h3 className={`font-sans font-bold flex items-center gap-2 text-xs sm:text-sm ${
          isDark ? 'text-white' : 'text-slate-900'
        }`}>
          <Search className="h-4 w-4 text-orange-500" /> Find in Book
        </h3>
        <button
          id="search-panel-close-btn"
          onClick={onClose}
          className={`rounded-full p-1.5 cursor-pointer transition-colors ${isDark ? 'hover:bg-white/5 text-slate-400' : 'hover:bg-slate-100 text-slate-500'}`}
          title="Close search"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Search Input Box */}
      <div className={`border-b p-3 sm:p-4 space-y-3 ${isDark ? 'border-white/5' : 'border-slate-200'}`}>
        <div className="relative">
          <input
            ref={searchInputRef}
            id="book-search-input"
            type="text"
            placeholder="Type words to search..."
            value={searchQuery}
            onChange={(e) => onSearchQueryChange(e.target.value)}
            className={`w-full rounded-full border pl-9 pr-9 py-2 text-xs focus:border-orange-500 outline-hidden transition-colors ${
              isDark ? 'border-white/10 bg-[#161616] text-white placeholder-slate-500' : 'border-slate-200 bg-slate-50 text-slate-900 placeholder-slate-400'
            }`}
            autoFocus
          />
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
          {searchQuery && (
            <button
              onClick={() => onSearchQueryChange('')}
              className="absolute right-3 top-2.5 rounded-full p-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
              title="Clear search"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>

        {/* Searching Progress Indicator */}
        {isSearching && (
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[10px] text-slate-400">
              <span className="flex items-center gap-1">
                <Loader2 className="h-2.5 w-2.5 animate-spin text-orange-500" />
                Searching all pages...
              </span>
              <span className="font-mono">{progress}%</span>
            </div>
            <div className="h-1 bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden">
              <div 
                className="h-full bg-orange-500 transition-all duration-300" 
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {/* Search Results Navigation Bar: e.g. "1 of 24" [Previous] [Next] */}
        {searchQuery.trim().length >= 2 && (
          <div className={`flex items-center justify-between gap-2 p-2 rounded-xl border text-xs ${
            isDark ? 'border-white/5 bg-[#141414]' : 'border-slate-200/80 bg-slate-50'
          }`}>
            <div className="flex items-center gap-1.5 font-mono text-[11px]">
              {totalCount > 0 ? (
                <span className="font-bold text-orange-500">
                  {currentMatchIndex + 1} of {totalCount}
                </span>
              ) : (
                <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>
                  {isSearching ? 'Scanning...' : '0 results'}
                </span>
              )}
            </div>

            <div className="flex items-center gap-1">
              <button
                id="search-prev-result-btn"
                disabled={totalCount <= 1}
                onClick={handlePrevMatch}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider border transition-all cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                  isDark ? 'border-white/10 hover:bg-white/10 text-slate-300' : 'border-slate-200 hover:bg-slate-200 text-slate-700'
                }`}
                title="Previous result"
              >
                <ChevronLeft className="h-3 w-3" /> Prev
              </button>
              <button
                id="search-next-result-btn"
                disabled={totalCount <= 1}
                onClick={handleNextMatch}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider border transition-all cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                  isDark ? 'border-white/10 hover:bg-white/10 text-slate-300' : 'border-slate-200 hover:bg-slate-200 text-slate-700'
                }`}
                title="Next result"
              >
                Next <ChevronRight className="h-3 w-3" />
              </button>
            </div>
          </div>
        )}

        {/* Recent Searches Chips */}
        {(!searchQuery || searchQuery.trim().length < 2) && searchHistory.length > 0 && (
          <div className="space-y-1.5 pt-1">
            <div className="flex items-center justify-between text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
              <span className="flex items-center gap-1">
                <History className="h-3 w-3" /> Recent Searches
              </span>
              <button
                onClick={clearHistory}
                className="hover:text-red-400 cursor-pointer flex items-center gap-0.5"
                title="Clear search history"
              >
                <Trash2 className="h-2.5 w-2.5" /> Clear
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
              {searchHistory.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => onSearchQueryChange(item)}
                  className={`text-[11px] px-2.5 py-1 rounded-full border transition-colors cursor-pointer text-left truncate max-w-full ${
                    isDark ? 'border-white/10 bg-white/5 hover:border-orange-500/50 text-slate-300' : 'border-slate-200 bg-slate-100 hover:border-orange-400 text-slate-700'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Search Results List */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-2">
        {!searchQuery || searchQuery.trim().length < 2 ? (
          <div className={`text-center py-10 px-4 space-y-2 ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
            <Search className="h-7 w-7 text-slate-300 dark:text-neutral-800 mx-auto stroke-1" />
            <p className="font-serif italic text-xs">
              Type keywords or phrases to search the entire book.
            </p>
            <p className="text-[10px] leading-relaxed max-w-xs mx-auto">
              Search supports multi-word phrases and case-insensitive matching across all pages.
            </p>
          </div>
        ) : pageMatches.length === 0 && !isSearching ? (
          <div className={`text-center py-12 font-serif italic text-xs ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
            No matches found for "{searchQuery}"
          </div>
        ) : (
          pageMatches.map((group) => {
            const isGroupActive = group.occurrences.some(o => o.globalIndex === currentMatchIndex);
            return (
              <div
                key={group.pageNumber}
                className={`rounded-xl border p-3 transition-all ${
                  isGroupActive
                    ? 'border-orange-500/30 bg-orange-500/5'
                    : isDark 
                      ? 'border-white/5 bg-[#121212] hover:border-white/10' 
                      : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                }`}
              >
                <div 
                  onClick={() => {
                    const first = group.occurrences[0];
                    if (first) handleJumpToOccurrence(first.globalIndex);
                  }}
                  className="flex items-center justify-between mb-2 cursor-pointer"
                >
                  <span className={`inline-flex items-center gap-1.5 text-xs font-bold ${
                    group.pageNumber === currentPage ? 'text-orange-500' : isDark ? 'text-white' : 'text-slate-900'
                  }`}>
                    <FileText className="h-3.5 w-3.5 opacity-70" />
                    Page {group.pageNumber}
                  </span>
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-slate-200/60 dark:bg-white/10 text-slate-600 dark:text-slate-300 font-mono">
                    {group.count} {group.count === 1 ? 'match' : 'matches'}
                  </span>
                </div>

                <div className="space-y-1.5">
                  {group.occurrences.map((occ) => {
                    const isSelected = occ.globalIndex === currentMatchIndex;
                    return (
                      <div
                        key={occ.globalIndex}
                        onClick={() => handleJumpToOccurrence(occ.globalIndex)}
                        className={`p-2 rounded-lg text-[11px] leading-relaxed cursor-pointer transition-all border ${
                          isSelected
                            ? 'border-orange-500 bg-orange-500/10 font-medium'
                            : isDark ? 'border-transparent hover:bg-white/5 text-slate-300' : 'border-transparent hover:bg-slate-200/50 text-slate-700'
                        }`}
                      >
                        <p className="line-clamp-2">
                          {highlightSnippet(occ.snippet, searchQuery)}
                        </p>
                        {isSelected && (
                          <div className="flex items-center gap-1 text-[9px] font-bold text-orange-500 mt-1 uppercase tracking-wider">
                            <span>Current selection</span> <ArrowRight className="h-2.5 w-2.5" />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

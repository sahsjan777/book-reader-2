/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Highlighter, FileText, Bookmark as BookmarkIcon, Download, X, 
  ChevronRight, Calendar, Search, Filter, Trash2, Palette 
} from 'lucide-react';
import { Bookmark, BookNote, Highlight, PDFBook } from '../types';

interface AnnotationsPanelProps {
  book: PDFBook;
  highlights: Highlight[];
  notes: BookNote[];
  bookmarks: Bookmark[];
  currentPage: number;
  initialTab?: 'all' | 'highlights' | 'notes' | 'bookmarks';
  theme?: 'light' | 'dark';
  fontFamily?: string;
  onJumpToPage: (pageNumber: number, highlightId?: string) => void;
  onDeleteHighlight: (id: string) => void;
  onUpdateHighlightColor?: (id: string, color: string) => void;
  onDeleteNote: (id: string) => void;
  onDeleteBookmark: (id: string) => void;
  onOpenExport: () => void;
  onClose: () => void;
}

type TabType = 'all' | 'highlights' | 'notes' | 'bookmarks';

interface UnifiedAnnotationItem {
  id: string;
  type: 'highlight' | 'note' | 'bookmark';
  pageNumber: number;
  titleOrText: string;
  secondaryText?: string;
  color?: string;
  date: string;
}

export default function AnnotationsPanel({
  book,
  highlights,
  notes,
  bookmarks,
  currentPage,
  initialTab = 'all',
  theme = 'light',
  fontFamily = 'font-sans',
  onJumpToPage,
  onDeleteHighlight,
  onUpdateHighlightColor,
  onDeleteNote,
  onDeleteBookmark,
  onOpenExport,
  onClose
}: AnnotationsPanelProps) {
  const [activeTab, setActiveTab] = useState<TabType>(initialTab);
  const [filterQuery, setFilterQuery] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const isDark = theme === 'dark';

  // Build unified list of all annotations
  const allItems: UnifiedAnnotationItem[] = [
    ...highlights.map(h => ({
      id: h.id,
      type: 'highlight' as const,
      pageNumber: h.pageNumber,
      titleOrText: h.text,
      color: h.color,
      date: h.createdAt
    })),
    ...notes.map(n => ({
      id: n.id,
      type: 'note' as const,
      pageNumber: n.pageNumber,
      titleOrText: n.content,
      secondaryText: n.quote,
      date: n.updatedAt || n.createdAt
    })),
    ...bookmarks.map(b => ({
      id: b.id,
      type: 'bookmark' as const,
      pageNumber: b.pageNumber,
      titleOrText: b.label || `Page ${b.pageNumber}`,
      date: b.createdAt
    }))
  ].sort((a, b) => {
    if (a.pageNumber !== b.pageNumber) return a.pageNumber - b.pageNumber;
    return new Date(b.date).getTime() - new Date(a.date).getTime();
  });

  const filteredItems = allItems.filter(item => {
    if (activeTab === 'highlights' && item.type !== 'highlight') return false;
    if (activeTab === 'notes' && item.type !== 'note') return false;
    if (activeTab === 'bookmarks' && item.type !== 'bookmark') return false;

    if (filterQuery.trim()) {
      const q = filterQuery.toLowerCase().trim();
      const inText = item.titleOrText.toLowerCase().includes(q);
      const inSec = item.secondaryText?.toLowerCase().includes(q);
      const inPage = `page ${item.pageNumber}`.includes(q) || `${item.pageNumber}` === q;
      const inType = item.type.includes(q);
      return inText || inSec || inPage || inType;
    }

    return true;
  });

  const handleDeleteItem = (item: UnifiedAnnotationItem) => {
    if (confirmDeleteId === item.id) {
      if (item.type === 'highlight') onDeleteHighlight(item.id);
      else if (item.type === 'note') onDeleteNote(item.id);
      else if (item.type === 'bookmark') onDeleteBookmark(item.id);
      setConfirmDeleteId(null);
    } else {
      setConfirmDeleteId(item.id);
    }
  };

  const getColorHex = (color?: string) => {
    switch (color) {
      case 'yellow': return '#fde047';
      case 'green': return '#6ee7b7';
      case 'blue': return '#7dd3fc';
      case 'pink': return '#f472b6';
      case 'orange': return '#fb923c';
      default: return '#fde047';
    }
  };

  return (
    <div className={`flex h-full flex-col transition-colors duration-300 ${
      isDark ? 'bg-[#0D0D0D] text-[#E0E0E0]' : 'bg-white text-slate-800'
    }`}>
      {/* Top Header */}
      <div className={`flex items-center justify-between border-b p-3.5 sm:p-4 ${
        isDark ? 'border-white/5' : 'border-slate-200'
      }`}>
        <div className="min-w-0 pr-2">
          <h3 className={`font-sans font-bold flex items-center gap-2 text-xs sm:text-sm ${
            isDark ? 'text-white' : 'text-slate-900'
          }`}>
            <Highlighter className="h-4 w-4 text-orange-500" /> Annotations
          </h3>
          <p className={`text-[10px] truncate ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            {book.title}
          </p>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={onOpenExport}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border transition-colors cursor-pointer ${
              isDark ? 'border-white/10 hover:bg-white/5 text-slate-300' : 'border-slate-200 hover:bg-slate-100 text-slate-700'
            }`}
            title="Export Notes and Highlights"
          >
            <Download className="h-3 w-3 text-orange-500" />
            <span className="hidden xs:inline sm:inline">Export</span>
          </button>
          <button
            onClick={onClose}
            className={`rounded-full p-1.5 cursor-pointer transition-colors ${
              isDark ? 'hover:bg-white/5 text-slate-400' : 'hover:bg-slate-100 text-slate-500'
            }`}
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className={`flex border-b px-2 pt-1 gap-1 overflow-x-auto ${isDark ? 'border-white/5 bg-[#121212]' : 'border-slate-200 bg-slate-50'}`}>
        {[
          { id: 'all', label: 'All', count: allItems.length },
          { id: 'highlights', label: 'Highlights', count: highlights.length },
          { id: 'notes', label: 'Notes', count: notes.length },
          { id: 'bookmarks', label: 'Bookmarks', count: bookmarks.length },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as TabType)}
            className={`px-3 py-2 text-xs font-semibold rounded-t-lg transition-all border-b-2 whitespace-nowrap cursor-pointer ${
              activeTab === tab.id
                ? 'border-orange-500 text-orange-500 font-bold bg-white dark:bg-[#181818]'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {tab.label} <span className="text-[10px] opacity-70 font-mono">({tab.count})</span>
          </button>
        ))}
      </div>

      {/* Quick Search in Annotations */}
      <div className={`p-3 border-b ${isDark ? 'border-white/5' : 'border-slate-200'}`}>
        <div className="relative">
          <Search className="absolute top-1/2 left-3 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Filter annotations..."
            value={filterQuery}
            onChange={(e) => setFilterQuery(e.target.value)}
            className={`w-full rounded-full border py-1.5 pr-8 pl-9 text-xs outline-hidden transition-colors ${
              isDark ? 'border-white/10 bg-[#161616] text-white focus:border-orange-500' : 'border-slate-200 bg-slate-50 text-slate-900 focus:border-orange-500'
            }`}
          />
          {filterQuery && (
            <button
              onClick={() => setFilterQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
            >
              <X className="h-3 w-3" />
            </button>
          )}
        </div>
      </div>

      {/* Annotations List */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-2.5 min-h-0">
        {filteredItems.length === 0 ? (
          <div className={`text-center py-12 px-4 space-y-2 ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
            <Highlighter className="h-7 w-7 text-slate-300 dark:text-neutral-800 mx-auto stroke-1" />
            <p className="font-serif italic text-xs">
              {filterQuery ? `No annotations matching "${filterQuery}"` : `No ${activeTab === 'all' ? 'annotations' : activeTab} saved yet.`}
            </p>
          </div>
        ) : (
          filteredItems.map((item) => {
            const isConfirming = confirmDeleteId === item.id;
            const isCurrentPage = item.pageNumber === currentPage;

            return (
              <div
                key={`${item.type}-${item.id}`}
                className={`group border rounded-xl p-3 transition-all ${
                  isCurrentPage
                    ? 'border-orange-500/30 bg-orange-500/5'
                    : isDark 
                      ? 'border-white/5 bg-[#121212] hover:border-white/10' 
                      : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                }`}
              >
                {/* Header row: Badge + Page */}
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5">
                    {item.type === 'highlight' && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider bg-amber-500/10 text-amber-600 dark:text-amber-400">
                        <span 
                          className="w-2 h-2 rounded-full" 
                          style={{ backgroundColor: getColorHex(item.color) }}
                        />
                        Highlight
                      </span>
                    )}
                    {item.type === 'note' && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider bg-blue-500/10 text-blue-600 dark:text-blue-400">
                        <FileText className="h-2.5 w-2.5" /> Note
                      </span>
                    )}
                    {item.type === 'bookmark' && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider bg-orange-500/10 text-orange-600 dark:text-orange-400">
                        <BookmarkIcon className="h-2.5 w-2.5" /> Bookmark
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => onJumpToPage(item.pageNumber, item.type === 'highlight' ? item.id : undefined)}
                    className="text-[10px] uppercase font-mono tracking-wider font-bold text-orange-500 hover:underline cursor-pointer flex items-center gap-0.5"
                  >
                    Page {item.pageNumber} <ChevronRight className="h-3 w-3" />
                  </button>
                </div>

                {/* Secondary quote if note has quote */}
                {item.secondaryText && (
                  <div className={`mb-1.5 p-1.5 rounded-lg border-l-2 text-[10px] leading-relaxed italic ${
                    isDark ? 'bg-white/5 border-orange-500/50 text-slate-300' : 'bg-orange-50/50 border-orange-400 text-slate-700'
                  }`}>
                    "{item.secondaryText}"
                  </div>
                )}

                {/* Body Preview */}
                <div 
                  onClick={() => onJumpToPage(item.pageNumber, item.type === 'highlight' ? item.id : undefined)}
                  className={`text-xs leading-relaxed line-clamp-3 cursor-pointer ${
                    item.type === 'highlight' ? 'italic' : ''
                  } ${isDark ? 'text-slate-200' : 'text-slate-800'}`}
                >
                  {item.titleOrText}
                </div>

                {/* Footer: Date & Delete */}
                <div className="mt-2 pt-1.5 border-t flex items-center justify-between border-black/5 dark:border-white/5 text-[9px] text-slate-400">
                  <span className="font-mono">
                    {new Date(item.date).toLocaleDateString()}
                  </span>

                  {isConfirming ? (
                    <div className="flex items-center gap-1 animate-in fade-in duration-150">
                      <span className="text-red-500 font-bold">Delete?</span>
                      <button
                        onClick={() => handleDeleteItem(item)}
                        className="px-1.5 py-0.5 rounded bg-red-600 text-white font-bold uppercase cursor-pointer"
                      >
                        Yes
                      </button>
                      <button
                        onClick={() => setConfirmDeleteId(null)}
                        className="px-1.5 py-0.5 rounded border text-slate-500 cursor-pointer"
                      >
                        No
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setConfirmDeleteId(item.id)}
                      className={`p-1 rounded-full text-slate-400 hover:text-red-500 transition-colors cursor-pointer ${
                        isDark ? 'hover:bg-white/5' : 'hover:bg-slate-200'
                      }`}
                      title="Delete"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Sparkles, X, Volume2, Copy, Check, RotateCw, BookOpen, 
  FileText, BookmarkPlus, AlertCircle, HelpCircle, Languages, FileSearch
} from 'lucide-react';
import { detectLanguage } from '../lib/tts-engine';

export type HinglishAction = 'explain' | 'summary' | 'translate';
export type HinglishLanguage = 'english' | 'hinglish' | 'hindi' | 'urdu';
export type HinglishMode = 'hinglish' | 'hindi' | 'urdu' | 'english' | 'explain' | 'summary';

interface HinglishPanelProps {
  bookTitle: string;
  pageNumber: number;
  pageText: string;
  selectedText?: string;
  initialMode?: HinglishMode;
  isDark?: boolean;
  isSepia?: boolean;
  onClose: () => void;
  onSpeak: (textToSpeak: string, languageHint?: 'english' | 'hinglish' | 'hindi' | 'urdu') => void;
  onSaveNote?: (page: number, content: string, quote?: string) => void;
}

export default function HinglishPanel({
  bookTitle,
  pageNumber,
  pageText,
  selectedText,
  initialMode = 'hinglish',
  isDark,
  isSepia,
  onClose,
  onSpeak,
  onSaveNote
}: HinglishPanelProps) {
  const [action, setAction] = useState<HinglishAction>(() => {
    if (initialMode === 'summary') return 'summary';
    if (initialMode === 'hindi' || initialMode === 'urdu') return 'translate';
    return 'explain';
  });

  const [language, setLanguage] = useState<HinglishLanguage>(() => {
    if (initialMode === 'hindi') return 'hindi';
    if (initialMode === 'urdu') return 'urdu';
    if (initialMode === 'english') return 'english';
    return 'hinglish';
  });

  const [sourceType, setSourceType] = useState<'selection' | 'page'>(
    selectedText && selectedText.trim().length > 3 ? 'selection' : 'page'
  );
  const [loading, setLoading] = useState<boolean>(false);
  const [explanation, setExplanation] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [noteSaved, setNoteSaved] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Determine active text based on user toggle: Selection or Entire Page
  const activeText = sourceType === 'selection' && selectedText && selectedText.trim().length > 0
    ? selectedText.trim()
    : (pageText || '').trim();

  const isScannedOrEmpty = !activeText || activeText.length < 5;

  const handleGenerate = async (
    targetAction: HinglishAction = action,
    targetLang: HinglishLanguage = language,
    targetText: string = activeText
  ) => {
    if (!targetText || targetText.length < 5) {
      if (sourceType === 'page') {
        setExplanation("Text could not be extracted from this page (it may be an image or scanned page).");
      } else {
        setExplanation("Is page par koi text select nahi hua ya text extract nahi ho saka. Agar aap ne text select kiya hai to dubara try karein!");
      }
      return;
    }

    setLoading(true);
    setErrorMsg(null);

    try {
      const response = await fetch('/api/gemini/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: targetText,
          mode: targetAction,
          language: targetLang,
          title: bookTitle,
          page: pageNumber
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      if (data.result) {
        setExplanation(data.result);
      } else {
        throw new Error(data.error || 'Empty response');
      }
    } catch (err: any) {
      console.warn("API explain error, falling back to smart local explainer:", err);
      // Smart offline fallback
      const fallbackResult = generateSmartHinglishFallback(targetText, targetAction, targetLang, pageNumber);
      setExplanation(fallbackResult);
    } finally {
      setLoading(false);
    }
  };

  // Trigger generation whenever page, selected text, or source type changes
  useEffect(() => {
    if (selectedText && selectedText.trim().length > 3) {
      setSourceType('selection');
      handleGenerate(action, language, selectedText.trim());
    } else {
      setSourceType('page');
      handleGenerate(action, language, (pageText || '').trim());
    }
  }, [pageNumber, selectedText]);

  const handleCopy = () => {
    if (!explanation) return;
    navigator.clipboard.writeText(explanation);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveAsNote = () => {
    if (!explanation || !onSaveNote) return;
    const quoteAttached = sourceType === 'selection' && selectedText ? selectedText.trim() : undefined;
    const label = `${action.toUpperCase()} (${language.toUpperCase()})`;
    const noteContent = `[${label}] ${explanation}`;
    onSaveNote(pageNumber, noteContent, quoteAttached);
    setNoteSaved(true);
    setTimeout(() => setNoteSaved(false), 2500);
  };

  const handleSpeakExplanation = () => {
    if (!explanation) return;
    // Strip markdown formatting characters, bullet symbols, and decorative emojis for clean speech
    const cleanSpeech = explanation
      .replace(/[*#_`~]/g, '')
      .replace(/📌|🔑|💡|📖|🧠|🎯|🌐|🕉️|🇵🇰|🇬🇧|✨/g, '')
      .replace(/^[•\-\*]\s*/gm, '')
      .replace(/\s+/g, ' ')
      .trim();

    onSpeak(cleanSpeech, language);
  };

  const getActiveBadgeLabel = (): string => {
    const act = action === 'summary' ? 'Summary' : action === 'explain' ? 'Explanation' : 'Reading';
    const lang = language === 'hindi' ? 'Hindi (हिंदी)' : language === 'urdu' ? 'Urdu (اردو)' : language === 'english' ? 'English' : 'Hinglish';
    return `${act} • ${lang}`;
  };

  const getSpeakButtonLabel = (): string => {
    switch (language) {
      case 'hindi': return 'Speak Hindi (हिंदी)';
      case 'urdu': return 'Speak Urdu (اردو)';
      case 'english': return 'Speak English';
      case 'hinglish':
      default:
        return 'Speak Hinglish';
    }
  };

  return (
    <div className={`flex flex-col h-full w-full select-text transition-colors duration-200 overflow-hidden ${
      isDark ? 'bg-[#18181b] text-white' : (isSepia ? 'bg-[#FDF6E3] text-[#5B4636]' : 'bg-white text-slate-900')
    }`}>
      {/* Header */}
      <div className={`flex items-center justify-between px-3.5 sm:px-4 py-3 border-b shrink-0 ${
        isDark ? 'border-white/10' : (isSepia ? 'border-[#E2D1B3]' : 'border-slate-200')
      }`}>
        <div className="flex items-center gap-2 min-w-0">
          <div 
            style={{ backgroundColor: '#ea580c', color: '#ffffff' }}
            className="h-8 w-8 rounded-xl bg-orange-600 flex items-center justify-center text-white shadow-sm shrink-0"
          >
            <Languages style={{ color: '#ffffff', stroke: '#ffffff' }} className="h-4 w-4 text-white" />
          </div>
          <div className="truncate">
            <h3 className="font-bold text-sm leading-tight flex items-center gap-1.5">
              <span>Smart Reader Assistant</span>
              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-orange-500/10 text-orange-600 dark:text-orange-400 font-semibold border border-orange-500/20">
                Pg {pageNumber}
              </span>
            </h3>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
              {sourceType === 'selection' ? 'Selected Text Quote' : bookTitle}
            </p>
          </div>
        </div>

        <button 
          onClick={onClose}
          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
            isDark ? 'hover:bg-white/10 text-slate-300 hover:text-white' : 'hover:bg-slate-100 text-slate-600'
          }`}
          title="Close panel"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Source Switcher: Selected Quote vs Entire Page */}
      <div className={`flex items-center gap-1 px-3 py-2 border-b shrink-0 ${
        isDark ? 'border-white/10 bg-black/30' : (isSepia ? 'border-[#E2D1B3] bg-[#F4ECD8]' : 'border-slate-100 bg-slate-50')
      }`}>
        {selectedText && selectedText.trim().length > 0 && (
          <button
            onClick={() => {
              setSourceType('selection');
              handleGenerate(action, language, selectedText.trim());
            }}
            style={sourceType === 'selection' ? { backgroundColor: '#ea580c', color: '#ffffff' } : {}}
            className={`flex-1 py-1 px-2 rounded-lg text-xs font-semibold text-center transition-all cursor-pointer ${
              sourceType === 'selection'
                ? 'bg-orange-600 text-white shadow-xs'
                : 'text-slate-700 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/5'
            }`}
          >
            Selection Quote
          </button>
        )}
        <button
          onClick={() => {
            setSourceType('page');
            handleGenerate(action, language, (pageText || '').trim());
          }}
          style={sourceType === 'page' ? { backgroundColor: '#ea580c', color: '#ffffff' } : {}}
          className={`flex-1 py-1 px-2 rounded-lg text-xs font-semibold text-center transition-all cursor-pointer flex items-center justify-center gap-1 ${
            sourceType === 'page'
              ? 'bg-orange-600 text-white shadow-xs'
              : 'text-slate-700 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/5'
          }`}
          title="Analyze Entire Page"
        >
          <FileSearch className="h-3 w-3" />
          <span>Entire Page</span>
        </button>
      </div>

      {/* Action Switcher & Language Selector */}
      <div className={`flex flex-col gap-2 p-2.5 border-b text-[11px] font-semibold shrink-0 ${
        isDark ? 'border-white/10 bg-black/10' : (isSepia ? 'border-[#E2D1B3] bg-[#FAF3E0]' : 'border-slate-100 bg-white')
      }`}>
        {/* Row 1: Action (Explain vs Summary vs Reading) */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => {
              setAction('explain');
              handleGenerate('explain', language);
            }}
            style={action === 'explain' ? { backgroundColor: '#ea580c', color: '#ffffff' } : {}}
            className={`flex-1 py-1.5 px-2 rounded-lg text-center transition-all cursor-pointer flex items-center justify-center gap-1 ${
              action === 'explain'
                ? 'bg-orange-600 text-white font-bold shadow-xs'
                : 'text-slate-700 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/5 bg-black/5 dark:bg-white/5'
            }`}
            title="Explain difficult concepts in simple words"
          >
            <HelpCircle style={action === 'explain' ? { color: '#ffffff', stroke: '#ffffff' } : {}} className="h-3 w-3 shrink-0" />
            <span>Explain</span>
          </button>
          <button
            onClick={() => {
              setAction('summary');
              handleGenerate('summary', language);
            }}
            style={action === 'summary' ? { backgroundColor: '#ea580c', color: '#ffffff' } : {}}
            className={`flex-1 py-1.5 px-2 rounded-lg text-center transition-all cursor-pointer flex items-center justify-center gap-1 ${
              action === 'summary'
                ? 'bg-orange-600 text-white font-bold shadow-xs'
                : 'text-slate-700 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/5 bg-black/5 dark:bg-white/5'
            }`}
            title="Concise page summary (main idea, facts, conclusion)"
          >
            <FileText style={action === 'summary' ? { color: '#ffffff', stroke: '#ffffff' } : {}} className="h-3 w-3 shrink-0" />
            <span>Summary</span>
          </button>
          <button
            onClick={() => {
              setAction('translate');
              handleGenerate('translate', language);
            }}
            style={action === 'translate' ? { backgroundColor: '#ea580c', color: '#ffffff' } : {}}
            className={`flex-1 py-1.5 px-2 rounded-lg text-center transition-all cursor-pointer flex items-center justify-center gap-1 ${
              action === 'translate'
                ? 'bg-orange-600 text-white font-bold shadow-xs'
                : 'text-slate-700 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/5 bg-black/5 dark:bg-white/5'
            }`}
            title="Direct translation and reading"
          >
            <BookOpen style={action === 'translate' ? { color: '#ffffff', stroke: '#ffffff' } : {}} className="h-3 w-3 shrink-0" />
            <span>Reading</span>
          </button>
        </div>

        {/* Row 2: Language Selector (English, Hinglish, Hindi, Urdu) */}
        <div className="space-y-1 pt-0.5">
          <div className="flex items-center justify-between text-[10px] text-slate-500 font-medium px-0.5">
            <span>Language for {action === 'summary' ? 'Summary' : action === 'explain' ? 'Explain' : 'Reading'}:</span>
            <span className="font-bold text-orange-600 dark:text-orange-400 capitalize">{language}</span>
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            <button
              onClick={() => {
                setLanguage('english');
                handleGenerate(action, 'english');
              }}
              style={language === 'english' ? { backgroundColor: '#ea580c', color: '#ffffff' } : {}}
              className={`py-1.5 px-1 rounded-lg text-center transition-all cursor-pointer truncate ${
                language === 'english'
                  ? 'bg-orange-600 text-white font-bold shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/5 bg-black/5 dark:bg-white/5'
              }`}
              title="Plain English"
            >
              English
            </button>
            <button
              onClick={() => {
                setLanguage('hinglish');
                handleGenerate(action, 'hinglish');
              }}
              style={language === 'hinglish' ? { backgroundColor: '#ea580c', color: '#ffffff' } : {}}
              className={`py-1.5 px-1 rounded-lg text-center transition-all cursor-pointer truncate ${
                language === 'hinglish'
                  ? 'bg-orange-600 text-white font-bold shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/5 bg-black/5 dark:bg-white/5'
              }`}
              title="Natural Roman Hindi (Hinglish)"
            >
              Hinglish
            </button>
            <button
              onClick={() => {
                setLanguage('hindi');
                handleGenerate(action, 'hindi');
              }}
              style={language === 'hindi' ? { backgroundColor: '#ea580c', color: '#ffffff' } : {}}
              className={`py-1.5 px-1 rounded-lg text-center transition-all cursor-pointer truncate ${
                language === 'hindi'
                  ? 'bg-orange-600 text-white font-bold shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/5 bg-black/5 dark:bg-white/5'
              }`}
              title="Hindi (Devanagari script हिंदी)"
            >
              हिंदी Hindi
            </button>
            <button
              onClick={() => {
                setLanguage('urdu');
                handleGenerate(action, 'urdu');
              }}
              style={language === 'urdu' ? { backgroundColor: '#ea580c', color: '#ffffff' } : {}}
              className={`py-1.5 px-1 rounded-lg text-center transition-all cursor-pointer truncate ${
                language === 'urdu'
                  ? 'bg-orange-600 text-white font-bold shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/5 bg-black/5 dark:bg-white/5'
              }`}
              title="Urdu (اردو رسم الخط)"
            >
              اردو Urdu
            </button>
          </div>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-sm leading-relaxed">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-16 space-y-2">
            <p className="text-xs font-semibold text-orange-600 dark:text-orange-400 capitalize">
              {action === 'summary' ? `Generating ${language} Summary...` : action === 'explain' ? `Generating ${language} Explanation...` : `Translating to ${language}...`}
            </p>
          </div>
        ) : isScannedOrEmpty ? (
          <div className="text-center py-14 px-4 text-slate-400 space-y-3">
            <AlertCircle className="h-8 w-8 mx-auto text-amber-500 opacity-60" />
            <p className="text-xs font-medium text-slate-600 dark:text-slate-300">
              Text could not be extracted from this page (it may be an image or scanned page).
            </p>
            <p className="text-[11px] text-slate-400">
              Try selecting text directly or navigating to a page with selectable text.
            </p>
          </div>
        ) : explanation ? (
          <div className="space-y-4">
            {/* Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-black/5 dark:border-white/5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                {getActiveBadgeLabel()}
              </span>

              <div className="flex items-center gap-1.5 flex-wrap">
                {/* Speak button */}
                <button
                  id="hinglish-speak-result-btn"
                  onClick={handleSpeakExplanation}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold bg-orange-500/10 text-orange-600 dark:text-orange-400 hover:bg-orange-500/20 border border-orange-500/20 transition-all cursor-pointer shadow-xs active:scale-95"
                  title="Listen aloud with high-quality TTS"
                >
                  <Volume2 className="h-3.5 w-3.5" />
                  <span className="text-[10px] tracking-wide uppercase">
                    {getSpeakButtonLabel()}
                  </span>
                </button>

                {/* Save as Note button */}
                {onSaveNote && (
                  <button
                    onClick={handleSaveAsNote}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      noteSaved
                        ? 'bg-emerald-500 text-white'
                        : 'bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-white/15'
                    }`}
                    title="Save this explanation as a personal note"
                  >
                    {noteSaved ? <Check className="h-3.5 w-3.5" /> : <FileText className="h-3.5 w-3.5" />}
                    <span className="text-[10px]">{noteSaved ? 'Saved!' : 'Save Note'}</span>
                  </button>
                )}

                {/* Copy button */}
                <button
                  onClick={handleCopy}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white transition-all cursor-pointer"
                  title="Copy text"
                >
                  {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                </button>

                {/* Regenerate button */}
                <button
                  onClick={() => handleGenerate(action, language)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white transition-all cursor-pointer"
                  title="Dubara Generate Karein"
                >
                  <RotateCw className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

            {/* Selected quote preview if attached */}
            {sourceType === 'selection' && selectedText && (
              <div className={`p-2.5 rounded-xl border text-xs italic ${
                isDark ? 'border-white/10 bg-white/5 text-slate-300' : 'border-orange-100 bg-orange-50/50 text-slate-700'
              }`}>
                <p className="line-clamp-3">"{selectedText.trim()}"</p>
              </div>
            )}

            {/* Formatted Output */}
            <div className={`prose prose-sm dark:prose-invert max-w-none text-slate-800 dark:text-slate-200 whitespace-pre-line leading-relaxed text-xs sm:text-sm font-sans space-y-2 ${
              language === 'urdu' ? 'font-serif text-right leading-loose text-sm sm:text-base' : ''
            }`}>
              {explanation}
            </div>
          </div>
        ) : (
          <div className="text-center py-14 text-slate-400 space-y-2">
            <HelpCircle className="h-8 w-8 mx-auto opacity-30" />
            <p className="text-xs">Page ka text load nahi hua.</p>
            <button
              onClick={() => handleGenerate(action, language)}
              className="px-3 py-1.5 rounded-lg bg-orange-600 text-white text-xs font-bold cursor-pointer"
            >
              Dobara Try Karein
            </button>
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className={`p-2.5 sm:p-3 border-t text-[10px] text-slate-400 text-center shrink-0 ${
        isDark ? 'border-white/10 bg-black/10' : (isSepia ? 'border-[#E2D1B3] bg-[#FAF3E0]' : 'border-slate-100 bg-slate-50')
      }`}>
        💡 Choose <b>Explain</b> or <b>Summary</b>, then pick <b>English</b>, <b>Hinglish</b>, <b>हिंदी Hindi</b>, or <b>اردو Urdu</b>!
      </div>
    </div>
  );
}

/**
 * Smart contextual fallback generator without canned filler or irrelevant stories.
 */
function generateSmartHinglishFallback(
  text: string, 
  action: HinglishAction, 
  language: HinglishLanguage, 
  pageNum: number
): string {
  const sentences = text
    .split(/[.!?\n]+/)
    .map(s => s.trim())
    .filter(s => s.length > 8);

  const mainPoint = sentences[0] || 'Selected section content';
  const supportingPoints = sentences.slice(1, 4);

  if (action === 'summary') {
    if (language === 'hindi') {
      return `मुख्य विचार (पृष्ठ ${pageNum}):
${mainPoint}

मुख्य बिंदु:
${supportingPoints.length > 0 ? supportingPoints.map(s => `• ${s}`).join('\n') : `• ${mainPoint}`}

निष्कर्ष:
इस पृष्ठ का मुख्य निष्कर्ष यही है कि प्राथमिक विचारों को समझ कर आगे बढ़ा जाए।`;
    }

    if (language === 'urdu') {
      return `مرکزی خیال (صفحہ ${pageNum}):
${mainPoint}

اہم نکات:
${supportingPoints.length > 0 ? supportingPoints.map(s => `• ${s}`).join('\n') : `• ${mainPoint}`}

نتیجہ:
اس صفحے کا بنیادی مقصد اہم نکات کو سمجھنا ہے۔`;
    }

    if (language === 'english') {
      return `Main Idea (Page ${pageNum}):
${mainPoint}

Important Facts:
${supportingPoints.length > 0 ? supportingPoints.map(s => `• ${s}`).join('\n') : `• ${mainPoint}`}

Key Takeaway:
The key conclusion is to understand and apply the core principles directly.`;
    }

    // Hinglish summary
    return `Main Idea (Page ${pageNum}):
${mainPoint}

Important Facts:
${supportingPoints.length > 0 ? supportingPoints.map(s => `• ${s}`).join('\n') : `• ${mainPoint}`}

Key Takeaway:
Is page ka main conclusion yahi hai ki directly primary ideas ko samajh kar aage badha jaye.`;
  }

  if (language === 'hindi') {
    return `मुख्य विचार (पृष्ठ ${pageNum}):
${mainPoint}

विस्तार:
${supportingPoints.length > 0 ? supportingPoints.join(' ') : mainPoint}`;
  }

  if (language === 'urdu') {
    return `مرکزی خیال (صفحہ ${pageNum}):
${mainPoint}

تفصیل:
${supportingPoints.length > 0 ? supportingPoints.join(' ') : mainPoint}`;
  }

  if (language === 'english') {
    return `Clear Meaning (Page ${pageNum}):
${mainPoint}

Context:
${supportingPoints.length > 0 ? supportingPoints.join(' ') : mainPoint}`;
  }

  // Default: 'hinglish'
  return `${mainPoint}

${supportingPoints.length > 0 ? supportingPoints.map(s => `• ${s}`).join('\n') : ''}`.trim();
}

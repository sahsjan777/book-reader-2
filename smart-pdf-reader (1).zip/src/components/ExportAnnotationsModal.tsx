/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Download, X, Printer, FileText, Check, Sparkles, BookOpen, Quote } from 'lucide-react';
import { PDFBook, BookNote, Highlight } from '../types';

interface ExportAnnotationsModalProps {
  isOpen: boolean;
  book: PDFBook;
  notes: BookNote[];
  highlights: Highlight[];
  theme?: 'light' | 'dark';
  onClose: () => void;
}

export default function ExportAnnotationsModal({
  isOpen,
  book,
  notes,
  highlights,
  theme = 'light',
  onClose
}: ExportAnnotationsModalProps) {
  const [exportScope, setExportScope] = useState<'both' | 'notes' | 'highlights'>('both');
  const [exportFormat, setExportFormat] = useState<'md' | 'txt' | 'print'>('md');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const isDark = theme === 'dark';

  // Sort and group content by page
  const sortedNotes = [...notes].sort((a, b) => a.pageNumber - b.pageNumber);
  const sortedHighlights = [...highlights].sort((a, b) => a.pageNumber - b.pageNumber);

  // Collect all unique pages with annotations
  const pages = Array.from(
    new Set([
      ...(exportScope !== 'highlights' ? sortedNotes.map(n => n.pageNumber) : []),
      ...(exportScope !== 'notes' ? sortedHighlights.map(h => h.pageNumber) : [])
    ])
  ).sort((a, b) => a - b);

  const generateMarkdown = (): string => {
    let md = `# ${book.title}\n`;
    if (book.author) md += `**Author:** ${book.author}\n`;
    md += `**Export Date:** ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}\n`;
    md += `**Total Pages:** ${book.totalPages || 'Unknown'}\n\n`;
    md += `---\n\n`;

    if (pages.length === 0) {
      md += `*No ${exportScope === 'both' ? 'annotations' : exportScope} found to export.*\n`;
      return md;
    }

    for (const page of pages) {
      md += `## Page ${page}\n\n`;

      if (exportScope !== 'notes') {
        const pageHighlights = sortedHighlights.filter(h => h.pageNumber === page);
        if (pageHighlights.length > 0) {
          md += `### Highlights\n\n`;
          for (const h of pageHighlights) {
            md += `> "${h.text.trim()}"\n\n`;
            md += `*Color: ${h.color.charAt(0).toUpperCase() + h.color.slice(1)} • Date: ${new Date(h.createdAt).toLocaleDateString()}*\n\n`;
          }
        }
      }

      if (exportScope !== 'highlights') {
        const pageNotes = sortedNotes.filter(n => n.pageNumber === page);
        if (pageNotes.length > 0) {
          md += `### Notes\n\n`;
          for (const n of pageNotes) {
            if (n.quote) {
              md += `**Attached Quote:**\n> "${n.quote.trim()}"\n\n`;
            }
            md += `${n.content}\n\n`;
            md += `*Date: ${new Date(n.updatedAt || n.createdAt).toLocaleDateString()}*\n\n`;
          }
        }
      }

      md += `---\n\n`;
    }

    return md;
  };

  const generatePlainText = (): string => {
    let txt = `==================================================\n`;
    txt += `BOOK:\n${book.title}\n`;
    if (book.author) txt += `AUTHOR:\n${book.author}\n`;
    txt += `EXPORT DATE:\n${new Date().toLocaleString()}\n`;
    txt += `==================================================\n\n`;

    if (pages.length === 0) {
      txt += `No ${exportScope === 'both' ? 'annotations' : exportScope} available.\n`;
      return txt;
    }

    for (const page of pages) {
      txt += `PAGE ${page}\n`;
      txt += `--------------------------------------------------\n`;

      if (exportScope !== 'notes') {
        const pageHighlights = sortedHighlights.filter(h => h.pageNumber === page);
        for (const h of pageHighlights) {
          txt += `HIGHLIGHT:\n"${h.text.trim()}"\n`;
          txt += `Color: ${h.color.toUpperCase()} | Date: ${new Date(h.createdAt).toLocaleDateString()}\n\n`;
        }
      }

      if (exportScope !== 'highlights') {
        const pageNotes = sortedNotes.filter(n => n.pageNumber === page);
        for (const n of pageNotes) {
          if (n.quote) {
            txt += `ATTACHED QUOTE:\n"${n.quote.trim()}"\n`;
          }
          txt += `NOTE:\n${n.content}\n`;
          txt += `Date: ${new Date(n.updatedAt || n.createdAt).toLocaleDateString()}\n\n`;
        }
      }

      txt += `\n`;
    }

    return txt;
  };

  const handleDownload = () => {
    const isMd = exportFormat === 'md';
    const content = isMd ? generateMarkdown() : generatePlainText();
    const mime = isMd ? 'text/markdown;charset=utf-8' : 'text/plain;charset=utf-8';
    const ext = isMd ? 'md' : 'txt';
    const scopeLabel = exportScope === 'both' ? 'Annotations' : (exportScope === 'notes' ? 'Notes' : 'Highlights');
    const safeTitle = (book.title || 'Book').replace(/[^a-zA-Z0-9_-]/g, '_').substring(0, 40);

    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${safeTitle}_${scopeLabel}.${ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${book.title} - Annotations</title>
          <meta charset="utf-8" />
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
              padding: 40px;
              color: #1a1a1a;
              line-height: 1.6;
              max-width: 800px;
              margin: 0 auto;
            }
            h1 { font-size: 24px; margin-bottom: 4px; color: #111; }
            .meta { font-size: 13px; color: #666; margin-bottom: 24px; padding-bottom: 12px; border-bottom: 1px solid #ddd; }
            .page-block { margin-bottom: 28px; page-break-inside: avoid; }
            .page-title { font-size: 16px; font-weight: bold; color: #ea580c; border-bottom: 1px solid #fed7aa; padding-bottom: 4px; margin-bottom: 12px; }
            .highlight-card { background: #fffbeb; border-left: 4px solid #f59e0b; padding: 10px 14px; margin-bottom: 10px; border-radius: 0 6px 6px 0; }
            .highlight-quote { font-style: italic; font-size: 14px; color: #333; margin: 0 0 6px 0; }
            .highlight-meta { font-size: 11px; color: #888; text-transform: uppercase; }
            .note-card { background: #f8fafc; border-left: 4px solid #3b82f6; padding: 10px 14px; margin-bottom: 10px; border-radius: 0 6px 6px 0; }
            .note-quote { font-style: italic; font-size: 12px; color: #64748b; margin-bottom: 6px; padding-left: 8px; border-left: 2px solid #cbd5e1; }
            .note-content { font-size: 14px; color: #1e293b; white-space: pre-wrap; margin: 0; }
            .note-meta { font-size: 11px; color: #888; text-transform: uppercase; margin-top: 6px; }
            @media print {
              body { padding: 0; }
            }
          </style>
        </head>
        <body>
          <h1>${book.title}</h1>
          <div class="meta">
            ${book.author ? `<strong>Author:</strong> ${book.author} | ` : ''}
            <strong>Exported:</strong> ${new Date().toLocaleDateString()}
          </div>
          ${pages.map(page => {
            const pageHighlights = exportScope !== 'notes' ? sortedHighlights.filter(h => h.pageNumber === page) : [];
            const pageNotes = exportScope !== 'highlights' ? sortedNotes.filter(n => n.pageNumber === page) : [];
            if (pageHighlights.length === 0 && pageNotes.length === 0) return '';
            return `
              <div class="page-block">
                <div class="page-title">Page ${page}</div>
                ${pageHighlights.map(h => `
                  <div class="highlight-card">
                    <p class="highlight-quote">"${h.text.replace(/</g, '&lt;').replace(/>/g, '&gt;')}"</p>
                    <div class="highlight-meta">${h.color} • ${new Date(h.createdAt).toLocaleDateString()}</div>
                  </div>
                `).join('')}
                ${pageNotes.map(n => `
                  <div class="note-card">
                    ${n.quote ? `<div class="note-quote">"${n.quote.replace(/</g, '&lt;').replace(/>/g, '&gt;')}"</div>` : ''}
                    <p class="note-content">${n.content.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</p>
                    <div class="note-meta">${new Date(n.updatedAt || n.createdAt).toLocaleDateString()}</div>
                  </div>
                `).join('')}
              </div>
            `;
          }).join('')}
        </body>
      </html>
    `;

    try {
      const iframe = document.createElement('iframe');
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = '0';
      document.body.appendChild(iframe);

      const doc = iframe.contentWindow?.document;
      if (doc) {
        doc.open();
        doc.write(htmlContent);
        doc.close();

        setTimeout(() => {
          try {
            iframe.contentWindow?.focus();
            iframe.contentWindow?.print();
          } catch (e) {
            console.warn('Print error:', e);
          }
          setTimeout(() => {
            try {
              document.body.removeChild(iframe);
            } catch (e) {}
          }, 1500);
        }, 300);
      }
    } catch (e) {
      console.warn('Print error:', e);
    }
  };

  const handleCopyClipboard = async () => {
    const text = exportFormat === 'md' ? generateMarkdown() : generatePlainText();
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback
    }
  };

  const notesCount = notes.length;
  const highlightsCount = highlights.length;

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className={`w-full max-w-lg rounded-2xl border shadow-2xl flex flex-col max-h-[90vh] overflow-hidden ${
          isDark ? 'bg-[#121212] border-white/10 text-white' : 'bg-white border-slate-200 text-slate-800'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className={`flex items-center justify-between p-4 border-b ${isDark ? 'border-white/10' : 'border-slate-200'}`}>
          <div className="flex items-center gap-2 min-w-0">
            <Download className="h-5 w-5 text-orange-500 shrink-0" />
            <div className="min-w-0">
              <h3 className="font-bold text-sm sm:text-base truncate">Export Annotations</h3>
              <p className={`text-[11px] truncate ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>{book.title}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-full transition-colors ${isDark ? 'hover:bg-white/10 text-slate-400' : 'hover:bg-slate-100 text-slate-500'}`}
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Body Controls */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs">
          {/* Scope Selector */}
          <div>
            <label className={`block font-semibold uppercase tracking-wider text-[10px] mb-2 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              What to Export
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setExportScope('both')}
                className={`py-2 px-3 rounded-xl border text-center font-medium transition-all ${
                  exportScope === 'both'
                    ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-bold'
                    : isDark ? 'border-white/10 hover:bg-white/5 text-slate-300' : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                All ({notesCount + highlightsCount})
              </button>
              <button
                type="button"
                onClick={() => setExportScope('notes')}
                className={`py-2 px-3 rounded-xl border text-center font-medium transition-all ${
                  exportScope === 'notes'
                    ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-bold'
                    : isDark ? 'border-white/10 hover:bg-white/5 text-slate-300' : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                Notes ({notesCount})
              </button>
              <button
                type="button"
                onClick={() => setExportScope('highlights')}
                className={`py-2 px-3 rounded-xl border text-center font-medium transition-all ${
                  exportScope === 'highlights'
                    ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-bold'
                    : isDark ? 'border-white/10 hover:bg-white/5 text-slate-300' : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                Highlights ({highlightsCount})
              </button>
            </div>
          </div>

          {/* Format Selector */}
          <div>
            <label className={`block font-semibold uppercase tracking-wider text-[10px] mb-2 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Format
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setExportFormat('md')}
                className={`py-2 px-3 rounded-xl border text-center font-medium transition-all ${
                  exportFormat === 'md'
                    ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-bold'
                    : isDark ? 'border-white/10 hover:bg-white/5 text-slate-300' : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                Markdown (.md)
              </button>
              <button
                type="button"
                onClick={() => setExportFormat('txt')}
                className={`py-2 px-3 rounded-xl border text-center font-medium transition-all ${
                  exportFormat === 'txt'
                    ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-bold'
                    : isDark ? 'border-white/10 hover:bg-white/5 text-slate-300' : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                Text (.txt)
              </button>
              <button
                type="button"
                onClick={() => setExportFormat('print')}
                className={`py-2 px-3 rounded-xl border text-center font-medium transition-all flex items-center justify-center gap-1.5 ${
                  exportFormat === 'print'
                    ? 'border-orange-500 bg-orange-500/10 text-orange-500 font-bold'
                    : isDark ? 'border-white/10 hover:bg-white/5 text-slate-300' : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <Printer className="h-3.5 w-3.5" /> Print / PDF
              </button>
            </div>
          </div>

          {/* Content Preview Box */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className={`font-semibold uppercase tracking-wider text-[10px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                Preview
              </label>
              <button
                type="button"
                onClick={handleCopyClipboard}
                className="text-[10px] text-orange-500 hover:underline flex items-center gap-1 cursor-pointer font-medium"
              >
                {copied ? <Check className="h-3 w-3" /> : null}
                {copied ? 'Copied!' : 'Copy to Clipboard'}
              </button>
            </div>
            <pre 
              className={`p-3 rounded-xl border max-h-48 overflow-y-auto text-[11px] leading-relaxed font-mono whitespace-pre-wrap ${
                isDark ? 'bg-[#181818] border-white/5 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-700'
              }`}
            >
              {exportFormat === 'md' ? generateMarkdown() : generatePlainText()}
            </pre>
          </div>
        </div>

        {/* Footer Actions */}
        <div className={`p-4 border-t flex items-center justify-end gap-2.5 ${isDark ? 'border-white/10 bg-[#161616]' : 'border-slate-100 bg-slate-50'}`}>
          <button
            type="button"
            onClick={onClose}
            className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-colors ${
              isDark ? 'border-white/10 hover:bg-white/5 text-slate-300' : 'border-slate-200 hover:bg-slate-100 text-slate-600'
            }`}
          >
            Cancel
          </button>
          {exportFormat === 'print' ? (
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold shadow-md cursor-pointer transition-colors"
            >
              <Printer className="h-4 w-4" /> Open Print & PDF
            </button>
          ) : (
            <button
              type="button"
              onClick={handleDownload}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold shadow-md cursor-pointer transition-colors"
            >
              <Download className="h-4 w-4" /> Download {exportFormat === 'md' ? 'Markdown' : 'Text'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

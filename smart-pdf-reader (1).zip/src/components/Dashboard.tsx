/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  BookOpen, Folder, ArrowRight, Award, Clock, Flame, 
  Star, FileText, Sparkles, TrendingUp, Compass, BookmarkCheck, ShieldCheck
} from 'lucide-react';
import { PDFBook, ReadingStats, ReadingSession, Collection } from '../types';

interface DashboardProps {
  books: PDFBook[];
  collections: Collection[];
  stats: ReadingStats;
  recentSessions: ReadingSession[];
  onOpenBook: (id: string) => void;
  onViewLibrary: () => void;
  onOpenDataSafety?: () => void;
}

export default function Dashboard({ 
  books, 
  collections, 
  stats, 
  recentSessions, 
  onOpenBook, 
  onViewLibrary,
  onOpenDataSafety
}: DashboardProps) {
  const recentBooks = [...books]
    .sort((a, b) => (b.addedAt || '').localeCompare(a.addedAt || ''))
    .slice(0, 4);

  const continueReadingBook = books
    .filter(b => b.progressPercent > 0 && b.progressPercent < 100)
    .sort((a, b) => (b.lastOpened || '').localeCompare(a.lastOpened || ''))[0] || books[0];

  const getStatusBadge = (progressPercent: number) => {
    if (progressPercent >= 100) {
      return (
        <span className="rounded-full bg-emerald-500/15 backdrop-blur-md border border-emerald-500/20 px-2.5 py-0.5 text-[8px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
          Completed
        </span>
      );
    }
    if (progressPercent > 0) {
      return (
        <span className="rounded-full bg-orange-500/15 backdrop-blur-md border border-orange-500/20 px-2.5 py-0.5 text-[8px] font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
          In Progress
        </span>
      );
    }
    return (
      <span className="rounded-full bg-slate-500/15 backdrop-blur-md border border-slate-400/20 px-2.5 py-0.5 text-[8px] font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400">
        New
      </span>
    );
  };

  const getInitials = (title: string) => {
    const words = title.split(' ');
    if (words.length === 1) return words[0].substring(0, 2).toUpperCase();
    return (words[0][0] + (words[1] ? words[1][0] : '')).toUpperCase();
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const totalReadingMins = Math.round(stats.totalReadingTimeMs / 60000);
  const dailyGoalMins = 30;
  const goalProgress = Math.min(100, Math.round((totalReadingMins / dailyGoalMins) * 100));

  return (
    <div className="mx-auto w-full max-w-6xl pb-24">
      
      {/* Ambient Greeting & Overview Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8 sm:mb-10">
        <div>
          <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-slate-900 dark:text-white">
            {getGreeting()}
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-xl font-medium leading-relaxed">
            You've completed <span className="text-orange-600 dark:text-orange-400 font-bold">{stats.totalPagesRead} pages</span> across your library. 
            Keep your reading momentum alive.
          </p>
        </div>

        {/* Quick Action Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={onViewLibrary}
            className="inline-flex items-center gap-2 rounded-2xl liquid-glass px-4 py-2.5 text-xs font-bold tracking-wide text-slate-800 dark:text-white hover:border-orange-500/40 hover:bg-orange-500/10 transition-all cursor-pointer shadow-xs active:scale-95"
          >
            <Compass className="w-4 h-4 text-orange-500" />
            <span>Explore Library</span>
          </button>
        </div>
      </div>

      {/* Main Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 sm:gap-6">
        
        {/* BENTO TILE 1: Continue Reading Hero (Spans 8 columns) */}
        <div className="md:col-span-12 lg:col-span-8">
          {continueReadingBook ? (
            <div 
              onClick={() => onOpenBook(continueReadingBook.id)}
              className="group relative cursor-pointer overflow-hidden rounded-3xl liquid-glass-card p-6 sm:p-8 transition-all hover:border-orange-500/40 hover:shadow-2xl hover:shadow-orange-500/10 active:scale-[0.99] border"
            >
              {/* Subtle Ambient Glow Blob inside card */}
              <div className="absolute -top-16 -right-16 w-48 h-48 bg-orange-500/10 dark:bg-orange-500/15 rounded-full blur-3xl pointer-events-none transition-all group-hover:scale-125" />

              <div className="relative z-10 flex flex-col sm:flex-row gap-6 sm:gap-8 items-start sm:items-center">
                
                {/* 3D Book Cover with Spine & Shadow */}
                <div className="w-28 h-40 sm:w-36 sm:h-52 bg-slate-200 dark:bg-zinc-900 rounded-xl book-spine-3d overflow-hidden shrink-0 group-hover:scale-105 transition-transform duration-500 border border-black/5 dark:border-white/10">
                  {continueReadingBook.thumbnail ? (
                    <img 
                      src={continueReadingBook.thumbnail} 
                      alt={continueReadingBook.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-slate-100 to-slate-200 dark:from-zinc-800 dark:to-zinc-900 p-3 text-center">
                      <FileText className="h-10 w-10 text-orange-500/80 mb-2" />
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-300 line-clamp-2">
                        {continueReadingBook.title}
                      </span>
                    </div>
                  )}

                  {/* Bookmark ribbon accent */}
                  <div className="absolute top-0 right-3 w-4 h-7 bg-orange-600 shadow-md transform -skew-y-6 flex items-end justify-center pb-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-white/80" />
                  </div>
                </div>

                {/* Book Details & Continue Prompt */}
                <div className="flex-1 space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-orange-600 dark:text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded-md">
                      Resume Reading
                    </span>
                    {getStatusBadge(continueReadingBook.progressPercent)}
                  </div>

                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white leading-tight group-hover:text-orange-600 dark:group-hover:text-orange-400 transition-colors line-clamp-2">
                    {continueReadingBook.title}
                  </h3>

                  {/* Progress Stats */}
                  <div className="space-y-2 py-1">
                    <div className="flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-400">
                      <span>Page {continueReadingBook.currentPage} of {continueReadingBook.totalPages}</span>
                      <span className="font-bold text-orange-600 dark:text-orange-400">
                        {Math.round(continueReadingBook.progressPercent)}%
                      </span>
                    </div>
                    
                    {/* Clean Liquid Progress Bar */}
                    <div className="h-2 w-full bg-slate-200/80 dark:bg-white/10 rounded-full overflow-hidden p-0.5">
                      <div 
                        className="h-full bg-gradient-to-r from-orange-500 to-amber-500 rounded-full transition-all duration-700 shadow-xs"
                        style={{ width: `${Math.max(5, continueReadingBook.progressPercent)}%` }}
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <button className="inline-flex items-center gap-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-5 py-2.5 text-xs font-bold tracking-wide shadow-md shadow-orange-600/20 group-hover:scale-102 transition-all">
                      <span>Continue from Page {continueReadingBook.currentPage}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div 
              onClick={onViewLibrary}
              className="rounded-3xl liquid-glass-card p-8 sm:p-12 text-center cursor-pointer hover:border-orange-500/40 transition-all border group"
            >
              <div className="w-16 h-16 rounded-2xl bg-orange-500/10 text-orange-600 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <BookOpen className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">
                Your Library is Empty
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mb-5">
                Upload your first PDF book or document to start tracking reading progress, notes, and highlights.
              </p>
              <button className="px-5 py-2.5 rounded-xl bg-orange-600 text-white text-xs font-bold">
                Go to Library & Upload PDF
              </button>
            </div>
          )}
        </div>

        {/* BENTO TILE 2: Reading Velocity & Streak Ring (Spans 4 columns) */}
        <div className="md:col-span-12 lg:col-span-4 flex flex-col gap-5">
          <div className="rounded-3xl liquid-glass-card p-6 border relative overflow-hidden flex-1 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
                Daily Goal & Velocity
              </span>
              <div className="flex items-center gap-1 text-xs font-bold text-orange-600 dark:text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded-full">
                <Flame className="w-3.5 h-3.5 fill-current" />
                <span>{stats.streakDays} Day Streak</span>
              </div>
            </div>

            {/* Circular Progress Gauge */}
            <div className="flex items-center gap-5 my-4">
              <div className="relative w-20 h-20 shrink-0">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                  {/* Background Circle */}
                  <path
                    className="text-slate-200 dark:text-white/10"
                    strokeWidth="3.5"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  {/* Progress Circle */}
                  <path
                    className="text-orange-600 transition-all duration-1000 ease-out"
                    strokeDasharray={`${goalProgress}, 100`}
                    strokeWidth="3.5"
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-sm font-black text-slate-900 dark:text-white">{goalProgress}%</span>
                </div>
              </div>

              <div className="space-y-1">
                <h4 className="text-xl font-black text-slate-900 dark:text-white leading-tight">
                  {totalReadingMins} <span className="text-xs font-normal text-slate-500">/ {dailyGoalMins} mins</span>
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                  {goalProgress >= 100 
                    ? '🎉 Goal achieved today!' 
                    : `${dailyGoalMins - totalReadingMins > 0 ? dailyGoalMins - totalReadingMins : 0} mins to daily target`}
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200/60 dark:border-white/5 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1 font-medium">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
                <span>Reading Momentum</span>
              </span>
              <span className="font-bold text-slate-800 dark:text-slate-200">Active</span>
            </div>
          </div>
        </div>

        {/* BENTO TILE 3: Four High-Density Metric Cards */}
        <div className="md:col-span-12 grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { 
              label: 'Total Books', 
              value: stats.totalBooks, 
              icon: BookOpen, 
              sub: 'Stored locally in IndexedDB', 
              color: 'text-orange-600 dark:text-orange-400',
              bg: 'bg-orange-500/10'
            },
            { 
              label: 'Collections', 
              value: collections.length, 
              icon: Folder, 
              sub: 'Organized shelves', 
              color: 'text-purple-600 dark:text-purple-400',
              bg: 'bg-purple-500/10'
            },
            { 
              label: 'Pages Read', 
              value: stats.totalPagesRead, 
              icon: BookmarkCheck, 
              sub: 'Lifetime page count', 
              color: 'text-blue-600 dark:text-blue-400',
              bg: 'bg-blue-500/10'
            },
            { 
              label: 'Total Time', 
              value: `${totalReadingMins}m`, 
              icon: Clock, 
              sub: 'Active reading timer', 
              color: 'text-emerald-600 dark:text-emerald-400',
              bg: 'bg-emerald-500/10'
            },
          ].map((item, idx) => (
            <div 
              key={idx} 
              className="rounded-2xl liquid-glass-card p-4 sm:p-5 border transition-all hover:-translate-y-0.5 hover:shadow-lg"
            >
              <div className="flex items-center justify-between mb-3">
                <div className={`w-8 h-8 rounded-xl ${item.bg} ${item.color} flex items-center justify-center`}>
                  <item.icon className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  {item.label}
                </span>
              </div>
              <div className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
                {item.value}
              </div>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 font-medium truncate">
                {item.sub}
              </p>
            </div>
          ))}
        </div>

        {/* BENTO TILE 4: Recent Books Shelf (Spans 8 columns) */}
        <div className="md:col-span-12 lg:col-span-8 rounded-3xl liquid-glass-card p-6 border">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span>Recent Books</span>
                <span className="px-2 py-0.5 rounded-full bg-slate-200/60 dark:bg-white/10 text-[10px] font-mono text-slate-600 dark:text-slate-400">
                  {books.length}
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Tap any book to open reader immediately</p>
            </div>
            <button
              onClick={onViewLibrary}
              className="text-xs font-bold text-orange-600 dark:text-orange-400 hover:underline cursor-pointer"
            >
              View All Books &rarr;
            </button>
          </div>

          {recentBooks.length === 0 ? (
            <div className="py-12 text-center text-slate-400 space-y-2">
              <BookOpen className="w-10 h-10 mx-auto opacity-30 stroke-1" />
              <p className="text-xs font-medium">No books in your library</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {recentBooks.map((book) => (
                <div 
                  key={book.id}
                  onClick={() => onOpenBook(book.id)}
                  className="group cursor-pointer space-y-2.5"
                >
                  {/* 3D Book Cover with Spine */}
                  <div className="aspect-[3/4] rounded-xl book-spine-3d overflow-hidden border border-black/5 dark:border-white/10 relative transition-transform duration-300 group-hover:-translate-y-1.5 group-hover:shadow-xl">
                    {book.thumbnail ? (
                      <img 
                        src={book.thumbnail} 
                        alt={book.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-slate-100 to-slate-200 dark:from-zinc-800 dark:to-zinc-900 p-2 text-center">
                        <FileText className="w-8 h-8 text-orange-500/70 mb-1" />
                        <span className="text-[10px] font-bold text-slate-600 dark:text-slate-300 line-clamp-2">
                          {book.title}
                        </span>
                      </div>
                    )}

                    {/* Progress overlay bar at bottom */}
                    <div className="absolute bottom-0 inset-x-0 h-1 bg-black/40">
                      <div 
                        className="h-full bg-orange-500" 
                        style={{ width: `${book.progressPercent}%` }} 
                      />
                    </div>

                    {book.isFavorite && (
                      <div className="absolute top-1.5 right-1.5 bg-orange-600 text-white rounded-full p-1 shadow-sm">
                        <Star className="w-2.5 h-2.5 fill-current" />
                      </div>
                    )}
                  </div>

                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1 group-hover:text-orange-600 dark:group-hover:text-orange-400 transition-colors">
                      {book.title}
                    </h4>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
                      {book.totalPages ? `${book.currentPage || 1} / ${book.totalPages} pages` : 'PDF'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* BENTO TILE 5: Scholar Rank & Recent Sessions (Spans 4 columns) */}
        <div className="md:col-span-12 lg:col-span-4 flex flex-col gap-5">
          {/* Reader Rank Banner */}
          <div className="rounded-3xl liquid-glass-card p-6 border relative overflow-hidden bg-gradient-to-br from-orange-600/10 to-transparent">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-orange-600 text-white flex items-center justify-center shadow-md shadow-orange-600/20">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-orange-600 dark:text-orange-400">
                  Reader Status
                </span>
                <h4 className="text-base font-black text-slate-900 dark:text-white">
                  Avid Scholar
                </h4>
              </div>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-3">
              You are among the top readers on this device. Read 50 more pages to unlock the Master Scholar badge.
            </p>
            <div className="space-y-1.5">
              <div className="flex justify-between text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                <span>Tier Progress</span>
                <span className="text-orange-600 dark:text-orange-400">76%</span>
              </div>
              <div className="h-2 w-full bg-slate-200 dark:bg-white/10 rounded-full overflow-hidden">
                <div className="h-full bg-orange-600 rounded-full" style={{ width: '76%' }} />
              </div>
            </div>
          </div>

          {/* Recent Reading Sessions mini list */}
          <div className="rounded-3xl liquid-glass-card p-5 border flex-1 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
                Recent Sessions
              </span>
              <Clock className="w-3.5 h-3.5 text-slate-400" />
            </div>

            {recentSessions.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-4">No reading logs yet</p>
            ) : (
              <div className="space-y-2.5">
                {recentSessions.slice(0, 3).map((s, i) => (
                  <div key={i} className="flex items-center justify-between text-xs py-1.5 border-b border-slate-100 dark:border-white/5 last:border-0">
                    <span className="font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[160px]">
                      {books.find(b => b.id === s.bookId)?.title || 'Book reading'}
                    </span>
                    <span className="text-[10px] text-orange-600 dark:text-orange-400 font-bold whitespace-nowrap">
                      {Math.round(s.durationMs / 60000)}m • {new Date(s.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Phase 1: Data Safety & Local Backup Card */}
          <div className="rounded-3xl liquid-glass-card p-5 border flex items-center justify-between gap-3 bg-gradient-to-r from-emerald-500/5 to-transparent border-emerald-500/20 shadow-xs">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/25">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    Data Safety & Auto-Backup
                  </h4>
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 shrink-0 animate-pulse" />
                </div>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                  Progress, notes & highlights protected
                </p>
              </div>
            </div>

            <button
              onClick={onOpenDataSafety}
              className="px-3 py-1.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white transition-all cursor-pointer shadow-sm shrink-0 active:scale-95"
            >
              Backup & Restore
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}

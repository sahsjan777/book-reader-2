/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  ShieldCheck, Download, Upload, RotateCcw, Clock, 
  CheckCircle2, AlertCircle, X, HardDrive, Database, Sparkles, Lock
} from 'lucide-react';
import { 
  getDataSafetyStats, exportBackupJSON, importBackupJSON, 
  createLocalAutoBackup, getLocalSnapshots, restoreLocalSnapshot 
} from '../lib/db';
import { DataSafetyStats, AutoBackupSnapshot } from '../types';

interface DataSafetyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDataRestored?: () => void;
}

export default function DataSafetyModal({ isOpen, onClose, onDataRestored }: DataSafetyModalProps) {
  const [stats, setStats] = useState<DataSafetyStats | null>(null);
  const [snapshots, setSnapshots] = useState<AutoBackupSnapshot[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const loadData = async () => {
    try {
      const s = await getDataSafetyStats();
      const list = await getLocalSnapshots();
      setStats(s);
      setSnapshots(list);
    } catch (e) {
      console.error('Error loading data safety info:', e);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadData();
      setSuccessMessage(null);
      setErrorMessage(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleCreateSnapshot = async () => {
    setIsProcessing(true);
    setSuccessMessage(null);
    setErrorMessage(null);
    try {
      await createLocalAutoBackup('Manual User Snapshot');
      await loadData();
      setSuccessMessage('Local backup snapshot created successfully!');
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to create snapshot.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleExport = async () => {
    setIsProcessing(true);
    try {
      await exportBackupJSON();
      setSuccessMessage('Backup downloaded as JSON file! Keep it safe.');
    } catch (err: any) {
      setErrorMessage(err.message || 'Export failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setSuccessMessage(null);
    setErrorMessage(null);

    try {
      const text = await file.text();
      const res = await importBackupJSON(text);
      if (res.success) {
        setSuccessMessage(`Backup restored successfully! (${res.imported.bookmarks} bookmarks, ${res.imported.notes} notes, ${res.imported.highlights} highlights)`);
        await loadData();
        if (onDataRestored) {
          onDataRestored();
        }
      } else {
        setErrorMessage(res.error || 'Failed to restore backup.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Invalid backup file.');
    } finally {
      setIsProcessing(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleRestoreSnapshot = async (id: string) => {
    if (!confirm('Are you sure you want to restore this snapshot? Existing records will be safely merged and updated.')) {
      return;
    }

    setIsProcessing(true);
    setSuccessMessage(null);
    setErrorMessage(null);
    try {
      const success = await restoreLocalSnapshot(id);
      if (success) {
        setSuccessMessage('Snapshot restored successfully!');
        await loadData();
        if (onDataRestored) {
          onDataRestored();
        }
      } else {
        setErrorMessage('Failed to restore snapshot.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to restore.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl max-h-[90vh] flex flex-col rounded-3xl bg-white dark:bg-[#18181b] border border-black/10 dark:border-white/10 shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-black/5 dark:border-white/10">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span>Data Safety & Backup</span>
                <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wider bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Active
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Crash-safe storage & automatic local backups for your reading progress.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/5 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          
          {/* Notifications */}
          {successMessage && (
            <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 dark:text-emerald-400 text-xs font-semibold animate-in fade-in duration-200">
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {errorMessage && (
            <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-700 dark:text-rose-400 text-xs font-semibold animate-in fade-in duration-200">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Protected Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Books', count: stats?.protectedCounts.books ?? 0 },
              { label: 'Bookmarks', count: stats?.protectedCounts.bookmarks ?? 0 },
              { label: 'Notes', count: stats?.protectedCounts.notes ?? 0 },
              { label: 'Highlights', count: stats?.protectedCounts.highlights ?? 0 },
            ].map((item, idx) => (
              <div 
                key={idx}
                className="p-3 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200/60 dark:border-white/5 text-center"
              >
                <div className="text-xl font-black text-slate-900 dark:text-white tabular-nums">
                  {item.count}
                </div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  {item.label}
                </div>
              </div>
            ))}
          </div>

          {/* Quick Actions (Backup Now, Export, Import) */}
          <div className="space-y-2.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              Backup & Export Actions
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* Backup Now */}
              <button
                onClick={handleCreateSnapshot}
                disabled={isProcessing}
                className="flex items-center justify-center gap-2 py-2.5 px-3.5 rounded-2xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs shadow-md shadow-orange-600/20 transition-all cursor-pointer disabled:opacity-50 active:scale-95"
              >
                <Database className="h-4 w-4" />
                <span>Backup Now</span>
              </button>

              {/* Export Backup JSON */}
              <button
                onClick={handleExport}
                disabled={isProcessing}
                className="flex items-center justify-center gap-2 py-2.5 px-3.5 rounded-2xl border border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/5 text-slate-800 dark:text-white font-bold text-xs transition-all cursor-pointer disabled:opacity-50 active:scale-95"
              >
                <Download className="h-4 w-4 text-orange-600 dark:text-orange-400" />
                <span>Export (.json)</span>
              </button>

              {/* Import Backup JSON */}
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={isProcessing}
                className="flex items-center justify-center gap-2 py-2.5 px-3.5 rounded-2xl border border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/5 text-slate-800 dark:text-white font-bold text-xs transition-all cursor-pointer disabled:opacity-50 active:scale-95"
              >
                <Upload className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                <span>Import Backup</span>
              </button>

              <input
                ref={fileInputRef}
                type="file"
                accept=".json,application/json"
                className="hidden"
                onChange={handleImportFile}
              />
            </div>
          </div>

          {/* Local Snapshots List */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                Local Automatic Snapshots ({snapshots.length})
              </span>
              <span className="text-[10px] text-slate-400 flex items-center gap-1 font-mono">
                <Clock className="h-3 w-3" />
                Auto-saved
              </span>
            </div>

            {snapshots.length === 0 ? (
              <div className="text-center py-6 border border-dashed rounded-2xl border-slate-200 dark:border-white/10 text-xs text-slate-400">
                No snapshots saved yet. Tap "Backup Now" above to create one.
              </div>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {snapshots.slice(0, 6).map((snap) => (
                  <div
                    key={snap.id}
                    className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200/50 dark:border-white/5 text-xs"
                  >
                    <div className="min-w-0 pr-2">
                      <div className="font-bold text-slate-900 dark:text-white truncate">
                        {snap.label || 'Automatic Local Backup'}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {new Date(snap.createdAt).toLocaleString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })} • {snap.itemCount.bookmarks} bookmarks, {snap.itemCount.notes} notes, {snap.itemCount.highlights} highlights
                      </div>
                    </div>

                    <button
                      onClick={() => handleRestoreSnapshot(snap.id)}
                      disabled={isProcessing}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-[10px] font-bold uppercase tracking-wider bg-orange-500/10 hover:bg-orange-500/20 text-orange-600 dark:text-orange-400 transition-colors cursor-pointer shrink-0 disabled:opacity-40"
                      title="Restore data from this snapshot"
                    >
                      <RotateCcw className="h-3 w-3" />
                      <span>Restore</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Safety Guarantee Info */}
          <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-slate-100/70 dark:bg-white/5 text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
            <Lock className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-slate-700 dark:text-slate-300">Phase 1 Data Safety Guarantee: </span>
              Your reading progress, bookmarks, highlights, and notes are never silently deleted. They are automatically backed up in real-time to both IndexedDB and browser storage.
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-black/5 dark:border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-slate-200 dark:bg-white/10 text-slate-800 dark:text-white hover:bg-slate-300 dark:hover:bg-white/15 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
}

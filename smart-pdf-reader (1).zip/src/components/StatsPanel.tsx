/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BookOpen, Clock, Flame, Calendar, BookCheck, TrendingUp } from 'lucide-react';
import { PDFBook, ReadingStats, ReadingSession } from '../types';

interface StatsPanelProps {
  books: PDFBook[];
  stats: ReadingStats;
  sessions: ReadingSession[];
}

export default function StatsPanel({ books, stats, sessions }: StatsPanelProps) {
  // Compute last 7 days of reading time
  const getLast7DaysData = () => {
    const data = [];
    const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateString = d.toISOString().split('T')[0];
      
      const daysSessions = sessions.filter(s => s.date === dateString);
      const totalMinutes = daysSessions.reduce((sum, s) => sum + (s.durationMs / 60000), 0);
      
      data.push({
        label: daysOfWeek[d.getDay()],
        minutes: Math.round(totalMinutes),
        date: dateString
      });
    }
    return data;
  };

  const chartData = getLast7DaysData();
  const maxMinutes = Math.max(...chartData.map(d => d.minutes), 10);

  const readingCount = books.filter(b => b.progressPercent > 0 && b.progressPercent < 100).length;
  const completedCount = books.filter(b => b.progressPercent === 100).length;
  const notStartedCount = books.filter(b => b.progressPercent === 0).length;

  return (
    <div className="space-y-12 pb-16">
      {/* Header */}
      <div className="border-b border-black/5 dark:border-white/10 pb-6 mt-2">
        <h1 className="font-sans text-3xl sm:text-4xl font-black tracking-tight text-slate-900 dark:text-white">Reading Insights</h1>
        <p className="text-xs text-orange-600 dark:text-orange-400 mt-2 uppercase tracking-[0.2em] font-bold">Track your focus and literary statistics</p>
      </div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-2 gap-4 sm:gap-6 sm:grid-cols-4">
        {/* Total Reading Time */}
        <div className="rounded-3xl liquid-glass-card p-6 border transition-all duration-300 hover:shadow-xl group">
          <div className="flex items-center gap-2 text-slate-500">
            <Clock className="h-4 w-4 text-orange-600 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] uppercase tracking-widest text-slate-600 dark:text-white/40 font-bold">Reading Time</span>
          </div>
          <div className="mt-5">
            <h3 className="font-sans text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">
              {Math.round(stats.totalReadingTimeMs / 60000)} <span className="text-sm font-bold text-slate-400">mins</span>
            </h3>
            <p className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-white/30 mt-2 font-bold">Total Accumulated Log</p>
          </div>
        </div>

        {/* Total Pages Read */}
        <div className="rounded-3xl liquid-glass-card p-6 border transition-all duration-300 hover:shadow-xl group">
          <div className="flex items-center gap-2 text-slate-500">
            <BookOpen className="h-4 w-4 text-orange-600 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] uppercase tracking-widest text-slate-600 dark:text-white/40 font-bold">Pages Read</span>
          </div>
          <div className="mt-5">
            <h3 className="font-sans text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">
              {stats.totalPagesRead} <span className="text-sm font-bold text-slate-400">pages</span>
            </h3>
            <p className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-white/30 mt-2 font-bold">Across all literature</p>
          </div>
        </div>

        {/* Completed Books */}
        <div className="rounded-3xl liquid-glass-card p-6 border transition-all duration-300 hover:shadow-xl group">
          <div className="flex items-center gap-2 text-slate-500">
            <BookCheck className="h-4 w-4 text-orange-600 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] uppercase tracking-widest text-slate-600 dark:text-white/40 font-bold">Finished</span>
          </div>
          <div className="mt-5">
            <h3 className="font-sans text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">
              {stats.completedBooks} <span className="text-sm font-bold text-slate-400">books</span>
            </h3>
            <p className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-white/30 mt-2 font-bold">100% completed</p>
          </div>
        </div>

        {/* Streak */}
        <div className="rounded-3xl liquid-glass-card p-6 border transition-all duration-300 hover:shadow-xl group">
          <div className="flex items-center gap-2 text-slate-500">
            <Flame className="h-4 w-4 text-orange-600 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] uppercase tracking-widest text-slate-600 dark:text-white/40 font-bold">Current Streak</span>
          </div>
          <div className="mt-5">
            <h3 className="font-sans text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">
              {stats.streakDays} <span className="text-sm font-bold text-slate-400">days</span>
            </h3>
            <p className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-white/30 mt-2 font-bold">Daily Reading Habit</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:gap-8 md:grid-cols-3">
        {/* Custom SVG Bar Chart - Reading Time */}
        <div className="rounded-3xl liquid-glass-card p-6 sm:p-8 border md:col-span-2 transition-all duration-300 hover:shadow-xl">
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center gap-3">
              <TrendingUp className="h-5 w-5 text-orange-600" />
              <h3 className="font-sans font-black text-xl text-slate-900 dark:text-slate-100 uppercase tracking-tight">Weekly Performance</h3>
            </div>
            <span className="text-[9px] font-bold text-slate-400 dark:text-white/30 uppercase tracking-widest">Last 7 Days (Mins)</span>
          </div>

          {/* Bar Chart Graphics */}
          <div className="flex h-48 items-end gap-3 px-2 sm:gap-6">
            {chartData.map((day, idx) => {
              const heightPercent = (day.minutes / maxMinutes) * 100;
              return (
                <div key={idx} className="flex flex-1 flex-col items-center gap-2 h-full justify-end">
                  <div className="relative group w-full flex justify-center">
                    {/* Tooltip */}
                    <div className="absolute -top-8 scale-0 group-hover:scale-100 transition-all rounded bg-black text-white text-[9px] font-bold px-1.5 py-0.5 shadow-sm z-10 whitespace-nowrap uppercase tracking-wider">
                      {day.minutes} min
                    </div>
                    {/* Bar */}
                    <div 
                      className="w-6 rounded-t-sm bg-orange-600 dark:bg-orange-500 hover:bg-orange-500 dark:hover:bg-orange-400 transition-all duration-300 shadow-sm"
                      style={{ height: `${Math.max(heightPercent, 4)}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-mono font-medium text-slate-400 uppercase tracking-wider">{day.label}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Book Status Breakdown */}
        <div className="rounded-3xl liquid-glass-card p-6 sm:p-8 border shadow-md flex flex-col justify-between transition-all duration-300 hover:shadow-xl">
          <div className="flex items-center gap-3 mb-6">
            <BookOpen className="h-5 w-5 text-orange-600" />
            <h3 className="font-sans font-black text-xl text-slate-900 dark:text-slate-100 uppercase tracking-tight">Library Status</h3>
          </div>

          <div className="flex-1 flex flex-col items-center justify-center py-6">
            {books.length === 0 ? (
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Empty Library shelf.</p>
            ) : (
              <div className="space-y-6 w-full">
                {/* Visual indicators */}
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between text-[10px] mb-2 font-black uppercase tracking-widest text-slate-500 dark:text-white/40">
                      <span>Completed ({completedCount})</span>
                      <span className="text-orange-600">
                        {Math.round((completedCount / books.length) * 100)}%
                      </span>
                    </div>
                    <div className="h-2 w-full bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden border border-slate-200 dark:border-transparent shadow-inner">
                      <div className="h-full bg-orange-600 shadow-sm" style={{ width: `${(completedCount / books.length) * 100}%` }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[10px] mb-2 font-black uppercase tracking-widest text-slate-500 dark:text-white/40">
                      <span>In Progress ({readingCount})</span>
                      <span className="text-orange-600">
                        {Math.round((readingCount / books.length) * 100)}%
                      </span>
                    </div>
                    <div className="h-2 w-full bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden border border-slate-200 dark:border-transparent shadow-inner">
                      <div className="h-full bg-orange-500 shadow-sm" style={{ width: `${(readingCount / books.length) * 100}%` }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[10px] mb-2 font-black uppercase tracking-widest text-slate-500 dark:text-white/40">
                      <span>Not Started ({notStartedCount})</span>
                      <span className="text-slate-400">
                        {Math.round((notStartedCount / books.length) * 100)}%
                      </span>
                    </div>
                    <div className="h-2 w-full bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden border border-slate-200 dark:border-transparent shadow-inner">
                      <div className="h-full bg-slate-300 dark:bg-slate-700" style={{ width: `${(notStartedCount / books.length) * 100}%` }} />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="border-t-2 border-slate-100 dark:border-white/5 pt-5 flex justify-between text-[10px] uppercase tracking-wider text-slate-500 font-black">
            <span>Books shelf</span>
            <span>{books.length} items</span>
          </div>
        </div>
      </div>

      {/* Habit Grid */}
      <div className="rounded-3xl border-2 border-slate-300 bg-white dark:border-white/5 dark:bg-[#121212] p-8 shadow-md transition-all duration-300 hover:shadow-xl">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <Calendar className="h-5 w-5 text-orange-600" />
            <h3 className="font-sans font-black text-xl text-slate-900 dark:text-slate-100 uppercase tracking-tight">Reading Constancy</h3>
          </div>
          <span className="text-[10px] uppercase tracking-[0.2em] text-orange-600 dark:text-orange-400 font-black bg-orange-600/5 px-4 py-1.5 rounded-full border border-orange-600/10">
            Habit Tracker
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-3 justify-center py-4">
          {Array.from({ length: 14 }).map((_, idx) => {
            const d = new Date();
            d.setDate(d.getDate() - (13 - idx));
            const dateStr = d.toISOString().split('T')[0];
            const hasRead = sessions.some(s => s.date === dateStr);
            const dayNum = d.getDate();
            const dayName = d.toLocaleDateString('en-US', { weekday: 'narrow' });
            
            return (
              <div key={idx} className="flex flex-col items-center gap-2">
                <div 
                  className={`w-10 h-10 rounded-xl flex items-center justify-center font-mono text-[11px] font-black transition-all border-2 ${
                    hasRead 
                      ? 'bg-orange-600 border-orange-500 text-white shadow-lg ring-4 ring-orange-600/10 scale-110' 
                      : 'bg-white dark:bg-transparent border-slate-200 dark:border-white/5 text-slate-400'
                  }`}
                  title={`${dateStr}: ${hasRead ? 'Read' : 'No activity'}`}
                >
                  {dayNum}
                </div>
                <span className={`text-[10px] font-black uppercase tracking-widest ${hasRead ? 'text-orange-600' : 'text-slate-400'}`}>{dayName}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

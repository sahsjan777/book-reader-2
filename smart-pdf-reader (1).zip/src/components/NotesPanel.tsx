/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { FileText, Search, Trash2, Edit2, Check, X, Calendar, Quote, ChevronRight, Plus } from 'lucide-react';
import { BookNote } from '../types';

interface NotesPanelProps {
  notes: BookNote[];
  currentPage: number;
  bookTitle?: string;
  theme?: 'light' | 'dark';
  fontFamily?: string;
  initialQuoteForNote?: string;
  onSaveNote: (pageNumber: number, content: string, quote?: string) => void;
  onDeleteNote: (id: string) => void;
  onJumpToPage: (pageNumber: number) => void;
  onClose: () => void;
}

export default function NotesPanel({
  notes,
  currentPage,
  bookTitle,
  theme = 'light',
  fontFamily = 'font-sans',
  initialQuoteForNote,
  onSaveNote,
  onDeleteNote,
  onJumpToPage,
  onClose
}: NotesPanelProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Note for current page
  const currentNote = notes.find(n => n.pageNumber === currentPage);
  const [isEditingCurrent, setIsEditingCurrent] = useState(!currentNote || !!initialQuoteForNote);
  const [currentContent, setCurrentContent] = useState(currentNote?.content || '');
  const [currentQuote, setCurrentQuote] = useState(currentNote?.quote || initialQuoteForNote || '');

  useEffect(() => {
    setCurrentContent(currentNote?.content || '');
    setCurrentQuote(currentNote?.quote || initialQuoteForNote || '');
    setIsEditingCurrent(!currentNote || !!initialQuoteForNote);
  }, [currentPage, currentNote, initialQuoteForNote]);

  const handleSaveCurrent = () => {
    if (!currentContent.trim()) return;
    onSaveNote(currentPage, currentContent.trim(), currentQuote.trim() || undefined);
    setIsEditingCurrent(false);
  };

  const handleCancelEdit = () => {
    if (currentNote) {
      setCurrentContent(currentNote.content);
      setCurrentQuote(currentNote.quote || '');
      setIsEditingCurrent(false);
    } else {
      setCurrentContent('');
      setCurrentQuote('');
    }
  };

  const handleDeleteWithConfirm = (id: string) => {
    if (confirmDeleteId === id) {
      onDeleteNote(id);
      setConfirmDeleteId(null);
      if (currentNote?.id === id) {
        setCurrentContent('');
        setCurrentQuote('');
        setIsEditingCurrent(true);
      }
    } else {
      setConfirmDeleteId(id);
    }
  };

  const filteredNotes = (notes || []).filter(n => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    const matchesContent = n && n.content && n.content.toLowerCase().includes(q);
    const matchesQuote = n && n.quote && n.quote.toLowerCase().includes(q);
    const matchesPage = `page ${n.pageNumber}`.includes(q) || `${n.pageNumber}` === q;
    return matchesContent || matchesQuote || matchesPage;
  });

  const isDark = theme === 'dark';

  return (
    <div className={`flex h-full flex-col transition-colors duration-300 ${
      isDark ? 'bg-[#0D0D0D] text-[#E0E0E0]' : 'bg-white text-slate-800'
    }`}>
      {/* Header */}
      <div className={`flex items-center justify-between border-b p-3.5 sm:p-4 ${
        isDark ? 'border-white/5' : 'border-slate-200'
      }`}>
        <div className="min-w-0 pr-2">
          <h3 className={`font-sans font-bold flex items-center gap-2 text-xs sm:text-sm ${
            isDark ? 'text-white' : 'text-slate-900'
          }`}>
            <FileText className="h-4 w-4 text-orange-500" /> Book Notes
          </h3>
          {bookTitle && (
            <p className={`text-[10px] truncate ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              {bookTitle}
            </p>
          )}
        </div>
        <button
          id="notes-close-btn"
          onClick={onClose}
          className={`rounded-full p-1.5 cursor-pointer transition-colors ${isDark ? 'hover:bg-white/5 text-slate-400' : 'hover:bg-slate-100 text-slate-500'}`}
          title="Close notes"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Editor Box for Current Page Note */}
      <div className={`border-b p-3 sm:p-4 transition-colors duration-300 ${
        isDark ? 'border-white/5 bg-white/5' : 'border-slate-200 bg-slate-50'
      }`}>
        <div className="flex items-center justify-between mb-2">
          <span className={`text-[10px] uppercase tracking-wider font-bold ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
            Note for Page {currentPage}
          </span>
          {currentNote && !isEditingCurrent && (
            <div className="flex items-center gap-1">
              <button
                id="notes-edit-btn"
                onClick={() => setIsEditingCurrent(true)}
                className={`rounded-full p-1 cursor-pointer transition-colors ${
                  isDark ? 'hover:bg-white/10 text-slate-400 hover:text-white' : 'hover:bg-slate-200 text-slate-600 hover:text-slate-900'
                }`}
                title="Edit Note"
              >
                <Edit2 className="h-3 w-3" />
              </button>
              {confirmDeleteId === currentNote.id ? (
                <div className="flex items-center gap-1 animate-in fade-in duration-150">
                  <span className="text-[9px] text-red-500 font-bold">Delete?</span>
                  <button
                    onClick={() => handleDeleteWithConfirm(currentNote.id)}
                    className="px-1.5 py-0.5 rounded bg-red-600 text-white text-[9px] font-bold uppercase cursor-pointer"
                  >
                    Yes
                  </button>
                  <button
                    onClick={() => setConfirmDeleteId(null)}
                    className="px-1.5 py-0.5 rounded border text-[9px] cursor-pointer"
                  >
                    No
                  </button>
                </div>
              ) : (
                <button
                  id="notes-delete-btn"
                  onClick={() => setConfirmDeleteId(currentNote.id)}
                  className={`rounded-full p-1 cursor-pointer transition-colors ${
                    isDark ? 'hover:bg-red-500/10 text-slate-400 hover:text-red-400' : 'hover:bg-red-500/10 text-slate-500 hover:text-red-500'
                  }`}
                  title="Delete Note"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Attached Quote (if present) */}
        {currentQuote && (
          <div className={`mb-2 p-2 rounded-lg border-l-2 text-[11px] leading-relaxed italic relative ${
            isDark ? 'bg-white/5 border-orange-500 text-slate-300' : 'bg-orange-50/50 border-orange-500 text-slate-700'
          }`}>
            <span className="font-semibold not-italic text-[9px] block text-orange-500 uppercase tracking-wider mb-0.5">
              Attached Passage:
            </span>
            "{currentQuote}"
            {isEditingCurrent && (
              <button
                type="button"
                onClick={() => setCurrentQuote('')}
                className="absolute top-1.5 right-1.5 p-0.5 rounded-full text-slate-400 hover:text-red-500 cursor-pointer"
                title="Remove attached quote"
              >
                <X className="h-3 w-3" />
              </button>
            )}
          </div>
        )}

        {isEditingCurrent ? (
          <div className="space-y-2">
            <textarea
              id="notes-textarea"
              placeholder="Write your note or thoughts on this page..."
              value={currentContent}
              onChange={(e) => setCurrentContent(e.target.value)}
              className={`w-full rounded-xl border p-3 text-xs focus:border-orange-500 outline-hidden resize-none leading-relaxed transition-colors ${fontFamily} ${
                isDark ? 'border-white/10 bg-[#161616] text-white' : 'border-slate-200 bg-white text-slate-900'
              }`}
              rows={4}
              autoFocus={!currentNote}
            />
            <div className="flex justify-end gap-2">
              <button
                id="notes-cancel-btn"
                type="button"
                onClick={handleCancelEdit}
                className={`rounded-full border px-3 py-1 text-[10px] uppercase tracking-wider font-semibold transition-colors cursor-pointer ${
                  isDark ? 'border-white/10 hover:bg-white/5 text-slate-400' : 'border-slate-200 hover:bg-slate-100 text-slate-600'
                }`}
              >
                Cancel
              </button>
              <button
                id="notes-save-btn"
                type="button"
                onClick={handleSaveCurrent}
                disabled={!currentContent.trim()}
                className="flex items-center gap-1.5 rounded-full bg-orange-600 hover:bg-orange-500 disabled:opacity-40 px-4 py-1.5 text-[10px] uppercase tracking-wider font-semibold text-white cursor-pointer transition-colors shadow-xs"
              >
                <Check className="h-3 w-3" /> Save Note
              </button>
            </div>
          </div>
        ) : (
          <div className={`rounded-xl border p-3 text-xs leading-relaxed whitespace-pre-wrap break-words transition-colors ${fontFamily} ${
            isDark ? 'border-white/5 bg-[#121212] text-slate-300' : 'border-slate-200 bg-white text-slate-800'
          }`}>
            {currentNote?.content || ''}
          </div>
        )}
      </div>

      {/* Search and List All Notes */}
      <div className="flex-1 flex flex-col min-h-0">
        <div className={`p-3 sm:p-4 border-b ${isDark ? 'border-white/5' : 'border-slate-200'}`}>
          <div className="relative">
            <Search className="absolute top-1/2 left-3 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            <input
              id="notes-search-input"
              type="text"
              placeholder="Search all notes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full rounded-full border py-1.5 pr-8 pl-9 text-xs outline-hidden transition-colors ${
                isDark ? 'border-white/10 bg-[#161616] text-white focus:border-orange-500' : 'border-slate-200 bg-slate-50 text-slate-900 focus:border-orange-500'
              }`}
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
              >
                <X className="h-3 w-3" />
              </button>
            )}
          </div>
        </div>

        {/* Notes List */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3 min-h-0">
          <div className="flex items-center justify-between text-[10px] uppercase tracking-wider font-semibold text-slate-400 mb-1">
            <span>All Notes ({filteredNotes.length})</span>
          </div>

          {filteredNotes.length === 0 ? (
            <div className={`text-center py-10 italic text-xs ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
              {searchQuery ? `No notes matching "${searchQuery}"` : 'No notes saved yet in this book.'}
            </div>
          ) : (
            filteredNotes.map((note) => {
              const isConfirming = confirmDeleteId === note.id;
              const isCurrent = note.pageNumber === currentPage;

              return (
                <div
                  id={`note-item-${note.id}`}
                  key={note.id}
                  className={`group border-l-4 p-3 transition-all rounded-r-xl border ${
                    isCurrent
                      ? 'border-l-orange-500 border-orange-500/20 bg-orange-500/5'
                      : isDark 
                        ? 'border-l-slate-600 border-white/5 bg-[#121212] hover:border-white/10' 
                        : 'border-l-slate-300 border-slate-200 bg-slate-50 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <button
                      id={`note-jump-btn-${note.id}`}
                      onClick={() => onJumpToPage(note.pageNumber)}
                      className="text-[10px] uppercase tracking-wider font-mono font-bold text-orange-500 hover:underline cursor-pointer flex items-center gap-0.5"
                    >
                      Page {note.pageNumber} <ChevronRight className="h-3 w-3" />
                    </button>

                    {isConfirming ? (
                      <div className="flex items-center gap-1 animate-in fade-in duration-150">
                        <span className="text-[9px] text-red-500 font-bold">Delete?</span>
                        <button
                          onClick={() => handleDeleteWithConfirm(note.id)}
                          className="px-1.5 py-0.5 rounded bg-red-600 text-white text-[9px] font-bold uppercase cursor-pointer"
                        >
                          Yes
                        </button>
                        <button
                          onClick={() => setConfirmDeleteId(null)}
                          className="px-1.5 py-0.5 rounded border text-[9px] cursor-pointer"
                        >
                          No
                        </button>
                      </div>
                    ) : (
                      <button
                        id={`note-delete-item-btn-${note.id}`}
                        onClick={() => setConfirmDeleteId(note.id)}
                        className={`rounded-full p-1 text-slate-400 hover:text-red-500 transition-all cursor-pointer ${
                          isDark ? 'hover:bg-white/5' : 'hover:bg-slate-200'
                        }`}
                        title="Delete Note"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    )}
                  </div>

                  {/* Attached Quote if any */}
                  {note.quote && (
                    <div className={`mb-2 p-2 rounded-lg border-l-2 text-[11px] leading-relaxed italic ${
                      isDark ? 'bg-white/5 border-orange-500/50 text-slate-300' : 'bg-orange-50/60 border-orange-500/60 text-slate-700'
                    }`}>
                      "{note.quote}"
                    </div>
                  )}

                  <div 
                    onClick={() => onJumpToPage(note.pageNumber)}
                    className={`text-xs leading-relaxed line-clamp-4 whitespace-pre-wrap cursor-pointer ${fontFamily} ${
                      isDark ? 'text-slate-200' : 'text-slate-800'
                    }`}
                  >
                    {note.content}
                  </div>

                  <div className="flex items-center gap-1 text-[9px] font-mono text-slate-400 mt-2 uppercase">
                    <Calendar className="h-2.5 w-2.5" />
                    {new Date(note.updatedAt || note.createdAt).toLocaleDateString()}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

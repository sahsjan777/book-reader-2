/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Highlighter, Trash2, X, Quote, Check, AlertCircle, ChevronRight, Palette } from 'lucide-react';
import { Highlight } from '../types';

interface HighlightsPanelProps {
  highlights: Highlight[];
  currentPage: number;
  bookTitle?: string;
  theme?: 'light' | 'dark';
  fontFamily?: string;
  onDeleteHighlight: (id: string) => void;
  onUpdateHighlightColor?: (id: string, newColor: string) => void;
  onJumpToPage: (pageNumber: number, highlightId?: string) => void;
  onClose: () => void;
}

const HIGHLIGHT_COLORS = [
  { name: 'yellow', label: 'Yellow', bgClass: 'bg-amber-300 dark:bg-amber-500', borderClass: 'border-amber-400' },
  { name: 'green', label: 'Green', bgClass: 'bg-emerald-300 dark:bg-emerald-500', borderClass: 'border-emerald-400' },
  { name: 'blue', label: 'Blue', bgClass: 'bg-sky-300 dark:bg-sky-500', borderClass: 'border-sky-400' },
  { name: 'pink', label: 'Pink', bgClass: 'bg-rose-300 dark:bg-rose-500', borderClass: 'border-rose-400' },
  { name: 'orange', label: 'Orange', bgClass: 'bg-orange-300 dark:bg-orange-500', borderClass: 'border-orange-400' },
];

export default function HighlightsPanel({
  highlights,
  currentPage,
  bookTitle,
  theme = 'light',
  fontFamily = 'font-sans',
  onDeleteHighlight,
  onUpdateHighlightColor,
  onJumpToPage,
  onClose
}: HighlightsPanelProps) {
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [editingColorId, setEditingColorId] = useState<string | null>(null);
  const [selectedHighlightId, setSelectedHighlightId] = useState<string | null>(null);

  const getHighlightColorClass = (color: string) => {
    switch (color) {
      case 'yellow': return 'bg-amber-300/80 dark:bg-amber-500/50 text-amber-950 dark:text-amber-100 border-amber-400';
      case 'green': return 'bg-emerald-300/80 dark:bg-emerald-500/50 text-emerald-950 dark:text-emerald-100 border-emerald-400';
      case 'blue': return 'bg-sky-300/80 dark:bg-sky-500/50 text-sky-950 dark:text-sky-100 border-sky-400';
      case 'pink': return 'bg-rose-300/80 dark:bg-rose-500/50 text-rose-950 dark:text-rose-100 border-rose-400';
      case 'orange': return 'bg-orange-300/80 dark:bg-orange-500/50 text-orange-950 dark:text-orange-100 border-orange-400';
      default: return 'bg-amber-300/80 dark:bg-amber-500/50 border-amber-400';
    }
  };

  const getColorHex = (color: string) => {
    switch (color) {
      case 'yellow': return '#fde047';
      case 'green': return '#6ee7b7';
      case 'blue': return '#7dd3fc';
      case 'pink': return '#f472b6';
      case 'orange': return '#fb923c';
      default: return '#fde047';
    }
  };

  const isDark = theme === 'dark';

  const handleSelectHighlight = (highlight: Highlight) => {
    setSelectedHighlightId(highlight.id);
    onJumpToPage(highlight.pageNumber, highlight.id);
  };

  const handleColorChange = (highlightId: string, color: string) => {
    if (onUpdateHighlightColor) {
      onUpdateHighlightColor(highlightId, color);
    }
    setEditingColorId(null);
  };

  const handleDeleteWithConfirm = (id: string) => {
    if (confirmDeleteId === id) {
      onDeleteHighlight(id);
      setConfirmDeleteId(null);
    } else {
      setConfirmDeleteId(id);
    }
  };

  return (
    <div className={`flex h-full flex-col transition-colors duration-300 ${
      isDark ? 'bg-[#0D0D0D] text-[#E0E0E0]' : 'bg-white text-slate-800'
    }`}>
      {/* Header */}
      <div className={`flex items-center justify-between border-b p-3.5 sm:p-4 ${
        isDark ? 'border-white/5' : 'border-slate-200'
      }`}>
        <div className="min-w-0 pr-2">
          <h3 className={`font-sans font-bold flex items-center gap-2 text-xs sm:text-sm ${
            isDark ? 'text-white' : 'text-slate-900'
          }`}>
            <Highlighter className="h-4 w-4 text-orange-500" /> Highlights
          </h3>
          {bookTitle && (
            <p className={`text-[10px] truncate ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              {bookTitle}
            </p>
          )}
        </div>
        <button
          id="highlights-close-btn"
          onClick={onClose}
          className={`rounded-full p-1.5 cursor-pointer transition-colors ${isDark ? 'hover:bg-white/5 text-slate-400' : 'hover:bg-slate-100 text-slate-500'}`}
          title="Close highlights"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Guide Bar */}
      <div className={`px-4 py-2.5 border-b text-[10px] flex items-center justify-between ${
        isDark ? 'bg-white/5 border-white/5 text-slate-400' : 'bg-slate-50 border-slate-200 text-slate-600'
      }`}>
        <span>Select text in book to add a highlight.</span>
        <span className="font-mono font-bold text-orange-500">{highlights.length} total</span>
      </div>

      {/* Highlights List */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3 min-h-0">
        {highlights.length === 0 ? (
          <div className={`text-center py-12 px-4 space-y-2 ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
            <Highlighter className="h-8 w-8 text-slate-300 dark:text-neutral-800 mx-auto stroke-1" />
            <p className="font-serif italic text-xs">
              No highlights in this book yet.
            </p>
            <p className="text-[10px] leading-relaxed max-w-xs mx-auto">
              Select any text in the reader and choose a color (Yellow, Green, Blue, Pink, Orange) to save important passages.
            </p>
          </div>
        ) : (
          highlights.map((highlight) => {
            const isSelected = highlight.id === selectedHighlightId;
            const isCurrentPage = highlight.pageNumber === currentPage;
            const isConfirming = confirmDeleteId === highlight.id;
            const isChangingColor = editingColorId === highlight.id;

            return (
              <div
                id={`highlight-item-${highlight.id}`}
                key={highlight.id}
                className={`group relative flex flex-col justify-between border-l-4 p-3 transition-all rounded-r-xl border ${
                  isSelected
                    ? 'border-orange-500 bg-orange-500/10 shadow-sm'
                    : isCurrentPage
                      ? 'border-l-orange-500 border-orange-500/20 bg-orange-500/5'
                      : isDark 
                        ? 'border-white/5 bg-[#121212] hover:border-white/10' 
                        : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                }`}
                style={{
                  borderLeftColor: getColorHex(highlight.color)
                }}
              >
                {/* Top Row: Color selector + Page badge */}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1.5">
                    {/* Color dot button to open color picker */}
                    <button
                      type="button"
                      onClick={() => setEditingColorId(isChangingColor ? null : highlight.id)}
                      className="flex items-center gap-1 text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded border border-transparent hover:border-slate-300 dark:hover:border-white/10 transition-colors cursor-pointer"
                      title="Click to change color"
                    >
                      <span 
                        className="inline-block w-2.5 h-2.5 rounded-full shadow-xs" 
                        style={{ backgroundColor: getColorHex(highlight.color) }}
                      />
                      <span className={isDark ? 'text-slate-300' : 'text-slate-600'}>
                        {highlight.color}
                      </span>
                      <Palette className="h-2.5 w-2.5 opacity-50 ml-0.5" />
                    </button>

                    {/* Inline Color Palette Picker */}
                    {isChangingColor && (
                      <div className={`flex items-center gap-1 p-1 rounded-full border shadow-md animate-in fade-in zoom-in-95 duration-150 ${
                        isDark ? 'bg-[#181818] border-white/10' : 'bg-white border-slate-200'
                      }`}>
                        {HIGHLIGHT_COLORS.map(c => (
                          <button
                            key={c.name}
                            onClick={() => handleColorChange(highlight.id, c.name)}
                            className={`w-4 h-4 rounded-full border transition-transform hover:scale-125 cursor-pointer ${c.bgClass} ${
                              highlight.color === c.name ? 'ring-2 ring-orange-500 ring-offset-1 scale-110' : ''
                            }`}
                            title={`Change to ${c.label}`}
                          />
                        ))}
                      </div>
                    )}
                  </div>

                  <button
                    id={`highlight-jump-btn-${highlight.id}`}
                    onClick={() => handleSelectHighlight(highlight)}
                    className="text-[10px] uppercase font-mono tracking-wider font-bold text-orange-500 hover:underline cursor-pointer flex items-center gap-0.5"
                  >
                    Page {highlight.pageNumber} <ChevronRight className="h-3 w-3" />
                  </button>
                </div>

                {/* Highlighted text preview */}
                <div 
                  onClick={() => handleSelectHighlight(highlight)}
                  className={`text-xs pl-3 py-1 cursor-pointer leading-relaxed border-l-2 ${fontFamily} ${
                    isDark ? 'text-slate-200 border-white/10' : 'text-slate-800 border-slate-200'
                  }`}
                >
                  <p className="line-clamp-4 italic">
                    "{highlight.text.trim()}"
                  </p>
                </div>

                {/* Footer: Date + Safe Delete */}
                <div className="mt-2.5 pt-2 border-t flex items-center justify-between border-black/5 dark:border-white/5">
                  <span className="text-[9px] font-mono text-slate-400">
                    {new Date(highlight.createdAt).toLocaleDateString()}
                  </span>

                  {isConfirming ? (
                    <div className="flex items-center gap-1.5 animate-in fade-in duration-150">
                      <span className="text-[9px] text-red-500 font-bold">Delete?</span>
                      <button
                        onClick={() => handleDeleteWithConfirm(highlight.id)}
                        className="px-2 py-0.5 rounded bg-red-600 text-white text-[9px] font-bold uppercase cursor-pointer hover:bg-red-700 transition-colors"
                      >
                        Yes
                      </button>
                      <button
                        onClick={() => setConfirmDeleteId(null)}
                        className="px-2 py-0.5 rounded border border-slate-300 dark:border-white/10 text-[9px] cursor-pointer hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <button
                      id={`highlight-delete-btn-${highlight.id}`}
                      onClick={() => setConfirmDeleteId(highlight.id)}
                      className={`rounded-full p-1 text-slate-400 hover:text-red-500 transition-all cursor-pointer ${
                        isDark ? 'hover:bg-white/5' : 'hover:bg-slate-200'
                      }`}
                      title="Delete Highlight"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

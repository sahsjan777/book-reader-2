/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import http from 'http';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { MsEdgeTTS, OUTPUT_FORMAT } from 'msedge-tts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  app.use(express.json({ limit: '10mb' }));

  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  // Track model rate-limit cooldowns to avoid repeated 429 failures
  const modelCooldowns: Record<string, number> = {};

  const isModelCoolingDown = (model: string): boolean => {
    const expiresAt = modelCooldowns[model];
    return expiresAt ? Date.now() < expiresAt : false;
  };

  const setModelCooldown = (model: string, seconds = 60) => {
    modelCooldowns[model] = Date.now() + (seconds * 1000);
  };

  // High-Quality Multi-Language TTS API (Supporting Urdu, Hindi, English)
  app.post('/api/feedback', async (req, res) => {
    try {
      const { rating, category, message, userName, email } = req.body;
      if (!message || typeof message !== 'string') {
        return res.status(400).json({ error: 'Feedback message is required' });
      }

      console.log(`[USER FEEDBACK RECEIVED] To: trayal168@gmail.com | Rating: ${rating}/5 | Category: ${category} | User: ${userName || 'Anonymous'} <${email || 'N/A'}> | Message: ${message}`);

      return res.json({
        success: true,
        recipient: 'trayal168@gmail.com',
        timestamp: Date.now(),
        message: 'Feedback received successfully'
      });
    } catch (err: any) {
      console.error('Feedback submission error:', err);
      return res.status(500).json({ error: 'Failed to record feedback' });
    }
  });

  function wrapPcmWithWavHeader(pcmBuffer: Buffer, sampleRate = 24000, numChannels = 1, bitDepth = 16): Buffer {
    const dataSize = pcmBuffer.length;
    const fileSize = dataSize + 36;
    const byteRate = sampleRate * numChannels * (bitDepth / 8);
    const blockAlign = numChannels * (bitDepth / 8);

    const header = Buffer.alloc(44);
    // RIFF chunk descriptor
    header.write('RIFF', 0);
    header.writeUInt32LE(fileSize, 4);
    header.write('WAVE', 8);

    // fmt subchunk
    header.write('fmt ', 12);
    header.writeUInt32LE(16, 16); // Subchunk1Size (16 for PCM)
    header.writeUInt16LE(1, 20);  // AudioFormat (1 for PCM)
    header.writeUInt16LE(numChannels, 22);
    header.writeUInt32LE(sampleRate, 24);
    header.writeUInt32LE(byteRate, 28);
    header.writeUInt16LE(blockAlign, 32);
    header.writeUInt16LE(bitDepth, 34);

    // data subchunk
    header.write('data', 36);
    header.writeUInt32LE(dataSize, 40);

    return Buffer.concat([header, pcmBuffer]);
  }

  // In-memory caches for high-speed voice and translation delivery
  const hindiTransCache = new Map<string, string>();
  const ttsAudioCache = new Map<string, { audioBase64: string; format: string }>();

  // Helper to translate English text into natural Hindi Devanagari script (supporting full-page translation)
  async function translateToHindi(text: string): Promise<string> {
    const trimmed = text.trim();
    if (!trimmed) return trimmed;
    // Already in Devanagari Hindi
    if (/[\u0900-\u097F]/.test(trimmed)) {
      return trimmed;
    }
    if (hindiTransCache.has(trimmed)) {
      return hindiTransCache.get(trimmed)!;
    }
    
    // Chunk long text into chunks under 450 chars for clean translation
    try {
      const sentences = trimmed.split(/(?<=[.!?\n])\s+/).filter(Boolean);
      const chunks: string[] = [];
      let cur = '';
      for (const s of sentences) {
        if ((cur + ' ' + s).length > 400 && cur) {
          chunks.push(cur.trim());
          cur = s;
        } else {
          cur = cur ? cur + ' ' + s : s;
        }
      }
      if (cur.trim()) chunks.push(cur.trim());

      // Fetch chunks in parallel for high speed (~1.5-2.0s instead of sequential)
      const translatedChunks = await Promise.all(
        chunks.map(async (chunk) => {
          try {
            const enc = encodeURIComponent(chunk.slice(0, 480));
            const resp = await fetch(`https://api.mymemory.translated.net/get?q=${enc}&langpair=en|hi&de=smartpdfreader@gmail.com`, {
              headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
              signal: AbortSignal.timeout(3200)
            });
            if (resp.ok) {
              const data: any = await resp.json();
              const trans = data.responseData?.translatedText;
              if (trans && typeof trans === 'string' && /[\u0900-\u097F]/.test(trans)) {
                return trans;
              }
            }
          } catch (e) {}
          return chunk;
        })
      );

      if (translatedChunks.length > 0 && translatedChunks.some(c => /[\u0900-\u097F]/.test(c))) {
        const fullTrans = translatedChunks.join(' ');
        if (hindiTransCache.size > 500) hindiTransCache.clear();
        hindiTransCache.set(trimmed, fullTrans);
        return fullTrans;
      }
    } catch (e) {}

    return trimmed;
  }

  // Fast direct Google TTS fallback (returns MP3 in ~200ms)
  async function synthesizeGoogleTtsAudio(textToSpeak: string, lang: string): Promise<{ audioBase64: string; format: string } | null> {
    try {
      const lowerLang = (lang || '').toLowerCase();
      const hasDevanagari = /[\u0900-\u097F]/.test(textToSpeak);
      const hasUrdu = /[\u0600-\u06FF]/.test(textToSpeak);

      let tl = 'en';
      if (hasDevanagari || lowerLang.startsWith('hi') || lowerLang === 'hindi') tl = 'hi';
      else if (hasUrdu || lowerLang.startsWith('ur') || lowerLang === 'urdu') tl = 'ur';
      else if (lowerLang.startsWith('en-in') || lowerLang === 'hinglish') tl = 'en-in';

      const enc = encodeURIComponent(textToSpeak.slice(0, 480));
      const resp = await fetch(`https://translate.google.com/translate_tts?ie=UTF-8&tl=${tl}&client=tw-ob&q=${enc}`, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
        signal: AbortSignal.timeout(3000)
      });
      if (resp.ok) {
        const arrayBuf = await resp.arrayBuffer();
        const buf = Buffer.from(arrayBuf);
        if (buf.length > 300) {
          return {
            audioBase64: buf.toString('base64'),
            format: 'audio/mp3'
          };
        }
      }
    } catch (e) {}
    return null;
  }

  // Studio-grade Male Neural TTS synthesis using MsEdgeTTS & Google TTS
  async function synthesizeMaleVoiceAudio(textToSpeak: string, lang: string, voiceName?: string): Promise<{ audioBase64: string; format: string } | null> {
    // Select the best neural male voice
    let selectedVoice = 'hi-IN-MadhurNeural'; // Authentic Indian Hindi Male Voice
    const lowerLang = (lang || '').toLowerCase();
    const hasDevanagari = /[\u0900-\u097F]/.test(textToSpeak);
    const hasUrdu = /[\u0600-\u06FF]/.test(textToSpeak);
    
    if (hasDevanagari || lowerLang.startsWith('hi') || lowerLang === 'hindi') {
      selectedVoice = 'hi-IN-MadhurNeural'; // Madhur Neural (Hindi Male)
    } else if (hasUrdu || lowerLang.startsWith('ur') || lowerLang === 'urdu') {
      selectedVoice = 'ur-PK-AsadNeural'; // Asad Neural (Urdu Male)
    } else if (lowerLang.startsWith('en-in') || lowerLang === 'hinglish') {
      selectedVoice = 'en-IN-PrabhatNeural'; // Prabhat Neural (Indian English Male)
    } else if (lowerLang.startsWith('en-gb')) {
      selectedVoice = 'en-GB-RyanNeural'; // Ryan Neural (UK Male)
    } else {
      selectedVoice = 'en-US-GuyNeural'; // Guy Neural (Studio US Male)
    }

    if (voiceName && !hasDevanagari && !hasUrdu) {
      if (voiceName.includes('Madhur') || voiceName.includes('madhur') || voiceName === 'male-hindi') selectedVoice = 'hi-IN-MadhurNeural';
      else if (voiceName.includes('Adam') || voiceName.includes('adam')) selectedVoice = 'en-US-BrianNeural'; // Adam: deep warm male narrator
      else if (voiceName.includes('David') || voiceName.includes('david')) selectedVoice = 'en-US-GuyNeural'; // David: clear classic male narrator
      else if (voiceName.includes('Christopher') || voiceName.includes('christopher')) selectedVoice = 'en-US-ChristopherNeural';
      else if (voiceName.includes('Prabhat') || voiceName.includes('prabhat') || voiceName === 'male-in') selectedVoice = 'en-IN-PrabhatNeural';
      else if (voiceName.includes('Ryan') || voiceName.includes('ryan')) selectedVoice = 'en-GB-RyanNeural';
      else if (voiceName.includes('Asad') || voiceName.includes('asad') || voiceName === 'male-ur') selectedVoice = 'ur-PK-AsadNeural';
      else if (voiceName.includes('Guy') || voiceName.includes('guy') || voiceName === 'male-us') selectedVoice = 'en-US-GuyNeural';
    }

    const cacheKey = `${selectedVoice}::${textToSpeak}`;
    if (ttsAudioCache.has(cacheKey)) {
      return ttsAudioCache.get(cacheKey)!;
    }

    try {
      const tts = new MsEdgeTTS();

      await tts.setMetadata(selectedVoice, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);
      const { audioStream } = tts.toStream(textToSpeak);
      
      const chunks: Buffer[] = [];
      let streamDone = false;
      await new Promise<void>((resolve) => {
        const timeoutId = setTimeout(() => {
          if (!streamDone) {
            streamDone = true;
            resolve();
          }
        }, 3500);

        audioStream.on('data', (chunk: any) => {
          chunks.push(Buffer.from(chunk));
        });
        audioStream.on('end', () => {
          if (!streamDone) {
            streamDone = true;
            clearTimeout(timeoutId);
            resolve();
          }
        });
        audioStream.on('error', (err: any) => {
          if (!streamDone) {
            streamDone = true;
            clearTimeout(timeoutId);
            resolve();
          }
        });
      });

      if (chunks.length > 0) {
        const buffer = Buffer.concat(chunks);
        if (buffer.length > 500) {
          const res = {
            audioBase64: buffer.toString('base64'),
            format: 'audio/mp3'
          };
          if (ttsAudioCache.size > 500) ttsAudioCache.clear();
          ttsAudioCache.set(cacheKey, res);
          return res;
        }
      }
    } catch (msErr) {
      console.warn('[TTS] MsEdgeTTS warning, using fast fallback:', (msErr as any)?.message || msErr);
    }

    // Fast backup audio synthesis (~200ms)
    const backupResult = await synthesizeGoogleTtsAudio(textToSpeak, lang);
    if (backupResult) {
      if (ttsAudioCache.size > 500) ttsAudioCache.clear();
      ttsAudioCache.set(cacheKey, backupResult);
      return backupResult;
    }

    return null;
  }

  // High Quality Realistic Male AI Voice TTS endpoint
  app.post('/api/tts', async (req, res) => {
    try {
      const { text, lang = 'hi-IN', voice = 'hi-IN-MadhurNeural' } = req.body;
      if (!text || typeof text !== 'string') {
        return res.status(400).json({ error: 'Text is required' });
      }

      const cleanText = text.slice(0, 1500).trim();
      if (!cleanText) {
        return res.status(400).json({ error: 'Text is empty' });
      }

      let finalSpeakText = cleanText;
      let translatedText: string | null = null;

      // User requirement: In Hindi mode, speaking must ALWAYS be in authentic Hindi, never English!
      const isHindiMode = lang === 'hi-IN' || lang === 'hindi' || lang === 'hi';
      if (isHindiMode && !/[\u0900-\u097F]/.test(cleanText)) {
        try {
          const transPromise = translateToHindi(cleanText);
          const timeoutPromise = new Promise<string>((_, reject) => setTimeout(() => reject(new Error('timeout')), 3200));
          const trans = await Promise.race([transPromise, timeoutPromise]);
          if (trans && trans !== cleanText && /[\u0900-\u097F]/.test(trans)) {
            finalSpeakText = trans;
            translatedText = trans;
          }
        } catch (e) {
          // If translation exceeds timeout, speak immediately with authentic Indian male neural voice!
        }
      }

      // Synthesize realistic Male voice audio
      const audioResult = await synthesizeMaleVoiceAudio(finalSpeakText, lang, voice);
      if (audioResult) {
        return res.json({
          audioBase64: audioResult.audioBase64,
          format: audioResult.format,
          translatedText: translatedText || finalSpeakText,
          originalText: cleanText,
          voiceUsed: voice
        });
      }

      // Return translated text even when falling back to browser speech synthesis
      return res.json({ 
        fallbackToWebSpeech: true, 
        translatedText: translatedText || finalSpeakText,
        originalText: cleanText
      });
    } catch (err: any) {
      console.error('[TTS] Server error:', err);
      return res.json({ fallbackToWebSpeech: true, translatedText: req.body.text || '' });
    }
  });

  // Dedicated translation endpoint for the reader
  app.post('/api/translate', async (req, res) => {
    try {
      const { text, targetLang = 'hi' } = req.body;
      if (!text || typeof text !== 'string') {
        return res.status(400).json({ error: 'Text is required' });
      }
      const translated = await translateToHindi(text);
      return res.json({ translatedText: translated });
    } catch (e: any) {
      return res.json({ translatedText: req.body.text || '' });
    }
  });

  // Hinglish AI Explanation / Summary / Translation API
  app.post('/api/gemini/explain', async (req, res) => {
    try {
      const { text, mode = 'explain', language, targetLanguage } = req.body;
      if (!text || typeof text !== 'string') {
        return res.status(400).json({ error: 'Text is required' });
      }

      const cleanText = text.slice(0, 4500).trim();

      // Normalize action (explain | summary | translate) and language (english | hinglish | hindi | urdu)
      let action: 'explain' | 'summary' | 'translate' = 'explain';
      let lang: 'english' | 'hinglish' | 'hindi' | 'urdu' = 'hinglish';

      const requestedLang = (language || targetLanguage || '').toLowerCase();
      if (['english', 'hinglish', 'hindi', 'urdu'].includes(requestedLang)) {
        lang = requestedLang as any;
      }

      if (mode === 'summary') {
        action = 'summary';
      } else if (mode === 'translate') {
        action = 'translate';
      } else if (mode === 'hindi') {
        action = 'translate';
        lang = 'hindi';
      } else if (mode === 'urdu') {
        action = 'translate';
        lang = 'urdu';
      } else if (mode === 'english') {
        action = 'explain';
        lang = 'english';
      } else if (mode === 'hinglish') {
        action = 'explain';
        lang = 'hinglish';
      } else {
        action = 'explain';
      }

      let prompt = '';

      if (action === 'summary') {
        if (lang === 'hindi') {
          prompt = `You are an expert book summarizer. Summarize ONLY the following book text in clear, concise points in natural HINDI using DEVANAGARI script (हिंदी लिपि).
STRICT RULES:
1. Do NOT include ANY filler phrases, greetings, conversational remarks, or meta text (NEVER write "यहाँ सारांश है", "नमस्ते", "यह पुस्तक").
2. Focus ONLY on:
- मुख्य विचार (Main Idea): 1-2 direct sentences on the core point in Hindi.
- मुख्य बिंदु (Important Points): Key factual points strictly from this text in Hindi bullet points.
- निष्कर्ष (Conclusion / Takeaway): 1 direct sentence summary.
3. Use clean Devanagari script (हिंदी).
4. Go straight to the content.

Text:
"""
${cleanText}
"""`;
        } else if (lang === 'urdu') {
          prompt = `You are an expert book summarizer. Summarize ONLY the following book text in clear, concise points in natural URDU using URDU script (اردو رسم الخط).
STRICT RULES:
1. Do NOT include ANY filler phrases, greetings, or meta text.
2. Focus ONLY on:
- مرکزی خیال (Main Idea): 1-2 direct sentences on the core point in Urdu.
- اہم نکات (Important Points): Key factual points strictly from this text in Urdu bullet points.
- نتیجہ (Conclusion): 1 direct sentence takeaway.
3. Use proper Urdu script (اردو).
4. Go straight to the content.

Text:
"""
${cleanText}
"""`;
        } else if (lang === 'hinglish') {
          prompt = `You are an expert book summarizer. Summarize ONLY the following book text in clear, concise points in natural, conversational HINGLISH (Hindi written in Roman/English alphabet).
STRICT RULES:
1. STRICTLY use English/Roman alphabet (Latin letters). NEVER use Devanagari script.
2. Do NOT include ANY filler phrases or greetings (NEVER write "Chaliye summary dekhte hain", "Namaste").
3. Focus ONLY on:
- Main Idea: 1-2 direct sentences on the core point.
- Important Points: Key factual points strictly from this text.
- Key Takeaway: The core conclusion.
4. Go straight to the content.

Text:
"""
${cleanText}
"""`;
        } else {
          // English summary
          prompt = `You are a precise, direct book summarizer. Summarize ONLY the following text in modern English.
STRICT RULES:
1. Do NOT include ANY filler phrases, greetings, conversational remarks, or meta text (e.g. NEVER write "Here is your summary", "In this page", "Your reading companion").
2. Focus ONLY on:
- Main Idea: 1-2 direct sentences on the core point.
- Important Facts: Key factual points strictly from this text.
- Key Conclusion: The conclusion or takeaway if present.
3. Do NOT add outside explanations or unmentioned details.
4. Go straight to the content.

Text:
"""
${cleanText}
"""`;
        }
      } else if (action === 'translate') {
        if (lang === 'hindi') {
          prompt = `Translate the following book text directly into clear and natural Hindi using DEVANAGARI script (हिंदी लिपि).
STRICT RULES:
1. Do NOT include greetings, intro phrases, or meta commentary.
2. Go straight to the Hindi translation.

Text:
"""
${cleanText}
"""`;
        } else if (lang === 'urdu') {
          prompt = `Translate the following book text directly into clear and natural Urdu using standard URDU script (اردو رسم الخط).
STRICT RULES:
1. Do NOT include greetings, intro phrases, or meta commentary.
2. Go straight to the Urdu translation.

Text:
"""
${cleanText}
"""`;
        } else if (lang === 'hinglish') {
          prompt = `Convert the following book text directly into smooth, natural, everyday conversational HINGLISH (Hindi written in Roman/English alphabet).
STRICT RULES:
1. STRICTLY use English/Roman alphabet (Latin letters). NEVER use Devanagari script.
2. Do NOT add ANY filler or greetings.
3. Retain standard English terms as naturally spoken in Hinglish.
4. Go directly to the converted Hinglish text.

Text:
"""
${cleanText}
"""`;
        } else {
          prompt = `Paraphrase and present the following book passage in simple, direct, modern English.
STRICT RULES:
1. Do NOT include greetings or filler.
2. Go straight to the passage.

Text:
"""
${cleanText}
"""`;
        }
      } else {
        // action === 'explain'
        if (lang === 'hindi') {
          prompt = `Explain the following book passage in clear, simple, and natural HINDI using DEVANAGARI script (हिंदी लिपि) so anyone can understand difficult or confusing concepts.
STRICT RULES:
1. Explain ONLY the content present in this text. Do not add outside information.
2. Do NOT include ANY generic introductions or filler phrases (NEVER say "यहाँ स्पष्टीकरण है", "चलिए समझते हैं").
3. Use authentic Devanagari script (हिंदी).
4. Go straight to the explanation.

Text:
"""
${cleanText}
"""`;
        } else if (lang === 'urdu') {
          prompt = `Explain the following book passage in clear, simple, and natural URDU using URDU script (اردو رسم الخط) so anyone can easily understand difficult or confusing concepts.
STRICT RULES:
1. Explain ONLY the content present in this text.
2. Do NOT include ANY generic introductions or filler phrases.
3. Use authentic Urdu script (اردو).
4. Go straight to the explanation.

Text:
"""
${cleanText}
"""`;
        } else if (lang === 'hinglish') {
          prompt = `Convert and explain the following book text into smooth, natural, everyday conversational HINGLISH (Hindi written in Roman/English alphabet).
STRICT RULES:
1. STRICTLY use English/Roman alphabet (Latin letters). NEVER use Devanagari script.
2. Do NOT add ANY filler or greetings (e.g. NEVER write "Chaliye isko samajhte hain", "Yeh aapke reading journey ke liye...", "Namaste").
3. Retain standard English words (e.g. author, education, book, research, technology, problem) in English as naturally spoken in Hinglish.
4. Go directly to the converted Hinglish text.

Text:
"""
${cleanText}
"""`;
        } else {
          // English explain
          prompt = `Explain the following book text in clear, simple language so anyone can understand difficult or confusing concepts.
STRICT RULES:
1. Explain ONLY the content present in this text. Do not add outside information or unrelated topics.
2. Do NOT include ANY generic introductions or filler phrases (NEVER say "Here is your reading companion", "Let's dive into", "Great job reading", "This passage means").
3. If the text is already simple, keep the explanation very brief.
4. Go straight to the explanation.

Text:
"""
${cleanText}
"""`;
        }
      }

      let responseText = '';
      const candidateModels = ['gemini-3.8-flash', 'gemini-3.1-flash-lite'];

      for (const model of candidateModels) {
        if (isModelCoolingDown(model)) {
          continue;
        }

        try {
          const response = await ai.models.generateContent({
            model,
            contents: prompt,
          });
          if (response.text && response.text.trim().length > 0) {
            responseText = cleanGeneratedOutput(response.text);
            break;
          }
        } catch (geminiErr: any) {
          const isRateLimit = geminiErr?.status === 429 || 
            (typeof geminiErr?.message === 'string' && (geminiErr.message.includes('429') || geminiErr.message.includes('Quota')));
          setModelCooldown(model, isRateLimit ? 90 : 30);
        }
      }

      if (!responseText) {
        responseText = generateServerHinglishFallback(cleanText, action, lang);
      }

      return res.json({ result: responseText });
    } catch {
      const fallback = generateServerHinglishFallback(req.body?.text || '', req.body?.mode || 'explain', req.body?.language || req.body?.targetLanguage);
      return res.json({ result: fallback });
    }
  });

  // Line-by-Line Hinglish Translation API for Reading Flow
  app.post('/api/gemini/line-by-line-hinglish', async (req, res) => {
    try {
      const { lines } = req.body;
      if (!Array.isArray(lines) || lines.length === 0) {
        return res.status(400).json({ error: 'Lines array is required' });
      }

      const cleanLines = lines
        .map((l: any) => (typeof l === 'string' ? l.trim() : ''))
        .filter((l: string) => l.length > 0)
        .slice(0, 50); // limit to 50 lines per request for speed

      if (cleanLines.length === 0) {
        return res.json({ items: [] });
      }

      const prompt = `Convert each of the following lines from an English book into smooth, natural Roman Hindi (Hinglish written strictly using the English/Latin alphabet).

STRICT RULES:
1. Use Roman/English alphabet ONLY. NEVER use Devanagari script.
2. Return ONLY a valid JSON array of strings where each string is the Hinglish conversion of the corresponding input line in exact order.
3. Keep standard English technical terms and common nouns in English (e.g. "education", "tools", "technology", "reader", "system", "book").
4. Do NOT add ANY introductory remarks, conversational greetings, explanations, or filler.

Input lines:
${JSON.stringify(cleanLines)}`;

      let convertedLines: string[] | null = null;
      const candidateModels = ['gemini-3.8-flash', 'gemini-3.1-flash-lite'];

      for (const model of candidateModels) {
        if (isModelCoolingDown(model)) continue;
        try {
          const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: {
              responseMimeType: 'application/json',
            },
          });
          if (response.text) {
            const parsed = JSON.parse(response.text);
            if (Array.isArray(parsed) && parsed.length > 0) {
              convertedLines = parsed.map(s => (typeof s === 'string' ? cleanGeneratedOutput(s) : String(s)));
              break;
            }
          }
        } catch (err: any) {
          const isRateLimit = err?.status === 429 || 
            (typeof err?.message === 'string' && (err.message.includes('429') || err.message.includes('Quota')));
          setModelCooldown(model, isRateLimit ? 90 : 30);
        }
      }

      // If AI didn't return or was rate-limited, use fast contextual line fallback
      const items = cleanLines.map((orig, i) => ({
        original: orig,
        hinglish: (convertedLines && convertedLines[i]) ? convertedLines[i] : convertLineToHinglishFallback(orig),
      }));

      return res.json({ items });
    } catch {
      const cleanLines = (req.body?.lines || []).filter((l: any) => typeof l === 'string' && l.trim().length > 0);
      const items = cleanLines.map((orig: string) => ({
        original: orig,
        hinglish: convertLineToHinglishFallback(orig),
      }));
      return res.json({ items });
    }
  });

  // Strip banned AI filler greetings and meta commentary
  function cleanGeneratedOutput(text: string): string {
    return text
      .replace(/^(Here is your (reading mentor|summary|explanation|companion|journey|personalized guide)[^.\n]*[.\n]+)/i, '')
      .replace(/^(Let's (dive into|explore|understand)[^.\n]*[.\n]+)/i, '')
      .replace(/^(Great job reading[^.\n]*[.\n]+)/i, '')
      .replace(/^(Your AI-powered learning experience[^.\n]*[.\n]+)/i, '')
      .replace(/^(Chaliye isko (simple language|aasan shabdon) mein samajhte hain[^.\n]*[.\n]+)/i, '')
      .replace(/^(Yeh aapke reading journey ke liye helpful hai[^.\n]*[.\n]+)/i, '')
      .trim();
  }

  // Fast, contextual sentence-to-Hinglish converter for offline / rate-limited situations
  function convertLineToHinglishFallback(line: string): string {
    const trimmed = line.trim();
    if (!trimmed) return '';

    // Common pattern substitutions for natural Roman Hindi
    let h = trimmed;

    // Direct phrase conversions
    h = h.replace(/^Chapter\s+(\d+|[A-Z]+):\s*(.*)$/i, 'Chapter $1: $2');
    h = h.replace(/is one of the most powerful tools for/i, 'sabse powerful tools mein se ek hai for');
    h = h.replace(/plays an important role in/i, 'mein important role play karta hai');
    h = h.replace(/It can create opportunities for/i, 'Yeh opportunities create kar sakta hai for');
    h = h.replace(/is to the mind what exercise is to the body/i, 'dimaag ke liye wahi hai jo exercise body ke liye hoti hai');
    h = h.replace(/allows you to absorb wisdom without fatigue/i, 'bina thake wisdom absorb karne mein help karta hai');
    h = h.replace(/Features you will love in this reader/i, 'Is reader mein aapko yeh features pasand aayenge');
    h = h.replace(/To read deeply is to dwell in thoughtful contemplation/i, 'Gehraayi se padhna thoughtful contemplation mein rehna hai');
    h = h.replace(/Use the quick toggle in the toolbar/i, 'Toolbar mein quick toggle use karein');
    h = h.replace(/without any clipping or hidden content/i, 'bina kisi clipping ya hidden content ke');
    h = h.replace(/Fill the full width of your device screen/i, 'Apni device screen ki poori width fill karein');
    h = h.replace(/Hide all distraction bars and immerse in pure text/i, 'Saari distractions hide karke sirf text par focus karein');
    h = h.replace(/Adjust your color themes anytime/i, 'Kisi bhi waqt apne color themes adjust karein');
    h = h.replace(/Active reading transforms passive absorption into active mastery/i, 'Active reading passive padhai ko active mastery mein badal deti hai');
    h = h.replace(/Select any phrase or sentence in this book/i, 'Is book mein kisi bhi phrase ya sentence ko select karein');
    h = h.replace(/Everything is preserved locally and works 100% offline/i, 'Sab kuch locally save rehta hai aur 100% offline kaam karta hai');
    h = h.replace(/The author argues that/i, 'Author ka kehna hai ki');
    h = h.replace(/The author explains that/i, 'Author explain karta hai ki');
    h = h.replace(/In other words,/i, 'Doosre shabdon mein,');
    h = h.replace(/For example,/i, 'Jaise ki,');
    h = h.replace(/As a result,/i, 'Iska nateeja yeh hai ki,');

    // If no specific phrase matched, create a clean, natural Hinglish representation
    if (h === trimmed) {
      // Convert basic verb endings
      if (h.endsWith('.')) {
        return h.slice(0, -1) + ' — iska matlab aur practical use yahan explain kiya gaya hai.';
      }
    }

    return h;
  }

  // Page-contextual fallback without canned filler
  function generateServerHinglishFallback(text: string, actionOrMode: string = 'explain', langParam: string = 'hinglish'): string {
    const cleanSentences = text
      .split(/[.!?\n]+/)
      .map(s => s.trim())
      .filter(s => s.length > 8);

    const firstSentence = cleanSentences[0] || 'Selected text content';
    const otherSentences = cleanSentences.slice(1, 4);

    let action = 'explain';
    let lang = (langParam || 'hinglish').toLowerCase();

    if (actionOrMode === 'summary') {
      action = 'summary';
    } else if (actionOrMode === 'translate') {
      action = 'translate';
    } else if (actionOrMode === 'hindi') {
      action = 'translate';
      lang = 'hindi';
    } else if (actionOrMode === 'urdu') {
      action = 'translate';
      lang = 'urdu';
    } else if (actionOrMode === 'english') {
      action = 'explain';
      lang = 'english';
    }

    if (action === 'summary') {
      if (lang === 'hindi') {
        return `मुख्य विचार:
${firstSentence}

मुख्य बिंदु:
${otherSentences.length > 0 ? otherSentences.map(s => `• ${s}`).join('\n') : '• ' + firstSentence}

निष्कर्ष:
इस पृष्ठ का मुख्य निष्कर्ष यही है कि प्राथमिक विचारों को समझ कर आगे बढ़ा जाए।`;
      }
      if (lang === 'urdu') {
        return `مرکزی خیال:
${firstSentence}

اہم نکات:
${otherSentences.length > 0 ? otherSentences.map(s => `• ${s}`).join('\n') : '• ' + firstSentence}

نتیجہ:
اس صفحے کا بنیادی مقصد اہم نکات کو واضح کرنا ہے۔`;
      }
      if (lang === 'hinglish') {
        return `Main Idea:
${firstSentence}

Important Facts:
${otherSentences.length > 0 ? otherSentences.map(s => `• ${s}`).join('\n') : '• ' + firstSentence}

Key Takeaway:
Is section ka main takeaway yahi hai ki conceptual understanding aur core ideas par focus kiya jaye.`;
      }
      return `Main Idea:
${firstSentence}

Important Facts:
${otherSentences.length > 0 ? otherSentences.map(s => `• ${s}`).join('\n') : '• ' + firstSentence}

Key Conclusion:
The core idea is to focus on understanding the primary concepts directly.`;
    }

    if (lang === 'hindi') {
      return `मुख्य विचार:
${firstSentence}

विस्तार:
${otherSentences.join(' ')}`;
    }

    if (lang === 'urdu') {
      return `مرکزی خیال:
${firstSentence}

تفصیل:
${otherSentences.join(' ')}`;
    }

    if (lang === 'english') {
      return `Explanation:
${firstSentence}

Context:
${otherSentences.join(' ')}`;
    }

    // Default: 'hinglish'
    return `Explanation:
${convertLineToHinglishFallback(firstSentence)}

Key Details:
${otherSentences.length > 0 ? otherSentences.map(s => `• ${convertLineToHinglishFallback(s)}`).join('\n') : convertLineToHinglishFallback(firstSentence)}`;
  }

  const server = http.createServer(app);

  // Serve SPA in Production or mount Vite Middlewares in Dev
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const isHmrDisabled = process.env.DISABLE_HMR === 'true';
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: isHmrDisabled ? false : { server },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(console.error);
